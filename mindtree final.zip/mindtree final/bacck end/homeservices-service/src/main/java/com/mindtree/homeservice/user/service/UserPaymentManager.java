package com.mindtree.homeservice.user.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.mindtree.homeservice.dto.PaymentDTO;
import com.mindtree.homeservice.exception.ServiceException;
import com.mindtree.homeservice.user.entity.Payment;

public interface UserPaymentManager {
	String setPaymentDetails(Payment payment, String token, int vendorId) throws ServiceException;
}
