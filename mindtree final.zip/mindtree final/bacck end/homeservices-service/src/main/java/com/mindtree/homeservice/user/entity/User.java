package com.mindtree.homeservice.user.entity;


import java.util.Arrays;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Lob;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.Generated;

import com.mindtree.homeservice.core.entity.RegistrationDetail;
import com.mindtree.homeservice.vendor.entity.Address;

import net.bytebuddy.dynamic.loading.ClassReloadingStrategy.Strategy;

@Entity
@Table(name = "user")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "userId")
	private int userId;
	
	@Column(name = "userFirstName")
	private String userFirstName;
	
	@Column(name = "userLastName")
	private String userLastName;
	
	@Column(name = "userEmail")
	private String userEmail;
	
	@Column(name = "userPhone")
	private long userPhone;
	
	@Column(name = "userGender")
	private String userGender;
	
	@Column(name = "userImage")
	@Lob
	private byte[] userImage;
	
	@OneToOne
	@JoinColumn
	private Address userAddress;
	
	@OneToOne
	@JoinColumn
	private RegistrationDetail userRegistrationDetail;
	
	@OneToMany(mappedBy = "userInvolved")
	private List<OrderHistory> userOrders;

	public User() {

	}

	public User(int userId, String userFirstName, String userLastName, String userEmail, long userPhone,
			String userGender, byte[] userImage, Address userAddress, RegistrationDetail userRegistrationDetail,
			List<OrderHistory> userOrders) {
		super();
		this.userId = userId;
		this.userFirstName = userFirstName;
		this.userLastName = userLastName;
		this.userEmail = userEmail;
		this.userPhone = userPhone;
		this.userGender = userGender;
		this.userImage = userImage;
		this.userAddress = userAddress;
		this.userRegistrationDetail = userRegistrationDetail;
		this.userOrders = userOrders;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public long getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}

	public String getUserGender() {
		return userGender;
	}

	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}

	public byte[] getUserImage() {
		return userImage;
	}

	public void setUserImage(byte[] userImage) {
		this.userImage = userImage;
	}

	public Address getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(Address userAddress) {
		this.userAddress = userAddress;
	}

	public RegistrationDetail getUserRegistrationDetail() {
		return userRegistrationDetail;
	}

	public void setUserRegistrationDetail(RegistrationDetail userRegistrationDetail) {
		this.userRegistrationDetail = userRegistrationDetail;
	}

	public List<OrderHistory> getUserOrders() {
		return userOrders;
	}

	public void setUserOrders(List<OrderHistory> userOrders) {
		this.userOrders = userOrders;
	}

	@Override
	public String toString() {
		return "User [userId=" + userId + ", userFirstName=" + userFirstName + ", userLastName=" + userLastName
				+ ", userEmail=" + userEmail + ", userPhone=" + userPhone + ", userGender=" + userGender
				+ ", userImage=" + Arrays.toString(userImage) + ", userAddress=" + userAddress
				+ ", userRegistrationDetail=" + userRegistrationDetail + ", userOrders=" + userOrders + "]";
	}

	
}
