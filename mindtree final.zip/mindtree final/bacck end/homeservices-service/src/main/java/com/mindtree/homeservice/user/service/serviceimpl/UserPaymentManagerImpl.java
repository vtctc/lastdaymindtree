package com.mindtree.homeservice.user.service.serviceimpl;

import java.time.LocalDate;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.homeservice.core.repository.RegistrationDetailsRepository;
import com.mindtree.homeservice.dto.PaymentDTO;
import com.mindtree.homeservice.exception.ServiceException;
import com.mindtree.homeservice.user.entity.Payment;
import com.mindtree.homeservice.user.entity.User;
import com.mindtree.homeservice.user.repository.PaymentRepository;
import com.mindtree.homeservice.user.repository.UserRepository;
import com.mindtree.homeservice.util.AES;
import com.mindtree.homeservice.util.ErrorConstants;
import com.mindtree.homeservice.vendor.entity.Vendor;
import com.mindtree.homeservice.vendor.repository.VendorRepository;

@Service
public class UserPaymentManagerImpl implements com.mindtree.homeservice.user.service.UserPaymentManager {

	@Autowired
	PaymentRepository paymentRepository;
	
	@Autowired
	RegistrationDetailsRepository registrationRepository;
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	VendorRepository vendorRepository;
	
	private JavaMailSender javaMailSender;
	
	@Autowired
	public UserPaymentManagerImpl(JavaMailSender javaMailSender) {
		this.javaMailSender = javaMailSender;
	}
	
	@Override
	public String setPaymentDetails(Payment payment,String token,int vendorId) throws ServiceException {
		boolean isPresent = false;
		if(payment==null)
		{
			throw new ServiceException(ErrorConstants.PAYMENTUNSUCCESSFULL);
		}
		else {
		payment.setDate(LocalDate.now());
		final String secretKey="ssshhhhhhhhhhh!!!!";
		String userName=AES.decrypt(token, secretKey);
		System.err.println(userName);
		
		List<User> userList=userRepository.findAll();
		User requiredUser = null;
		for (User user : userList) {
			if((user.getUserRegistrationDetail().getUsername()!=null) && (user.getUserRegistrationDetail().getUsername().equals(userName)))
			{
				payment.setUserInvolved(user);
				requiredUser=user;
				isPresent = true;
			}
		}
		if(!isPresent)
		{
			throw new ServiceException(ErrorConstants.USERNAMENOTFOUND);
		}
		System.err.println("passed some stage");
		Vendor vendor=vendorRepository.findById(vendorId).get();
				
		System.err.println(payment);
		payment.setVendorInvolved(vendor);
		paymentRepository.save(payment);
		
		SimpleMailMessage mail=new SimpleMailMessage();
		String email=requiredUser.getUserEmail();

		mail.setTo(email);
		mail.setSubject("Payment Done");
		mail.setText("Hi "+requiredUser.getUserFirstName()+","+
		"\n"+"Thank you for purchasing the service with us."+"\n"+"\n"+
				"Service Person Details :- "+"\n"+"Name:-"+vendor.getVendorFirstName()+
				" "+vendor.getVendorLastName()+"\n"+"Phone:-"+vendor.getVendorPhone()+
				"\n"+"Email:-"+vendor.getVendorEmail()+"\n"+"\n"+
				"Will be visiting your home after 5 days"+
				"\n"+"\n"+" BILLING INFORMATION:-"+"\n"+"\n"+
				"PAYMENT ID :- "+payment.getPaymentId()+"\n"+"MODE OF PAYMENT :- "+
				payment.getModeOfPayment()+"\n"+"TOTAL AMOUNT :- "+payment.getAmount()+
				"\nThanks for being the part of KALINGA HOME SERVICE.");
		if(mail==null) {
			System.err.println(mail.getText());
		}
		javaMailSender.send(mail);
		
		return "successfull";
		}
	}

}
