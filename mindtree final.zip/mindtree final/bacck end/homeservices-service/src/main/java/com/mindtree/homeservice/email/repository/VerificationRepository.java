package com.mindtree.homeservice.email.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.homeservice.email.entity.Verification;

@Repository
public interface VerificationRepository extends JpaRepository<Verification, Integer>{

	Verification findByVerificationTokenOne(String token);
}
