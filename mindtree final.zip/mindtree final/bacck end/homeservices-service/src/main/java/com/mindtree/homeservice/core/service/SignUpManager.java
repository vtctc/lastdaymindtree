package com.mindtree.homeservice.core.service;

import com.mindtree.homeservice.core.entity.RegistrationDetail;
import com.mindtree.homeservice.dto.RegistrationDetailDTO;

public interface SignUpManager {

	public String SignUp(RegistrationDetailDTO user);
}
