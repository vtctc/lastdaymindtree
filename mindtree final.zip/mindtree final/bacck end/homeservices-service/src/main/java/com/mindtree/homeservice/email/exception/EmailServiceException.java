package com.mindtree.homeservice.email.exception;

public class EmailServiceException extends SecurityException{

	private static final long serialVersionUID=1L;
	
	public EmailServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmailServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public EmailServiceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmailServiceException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
