package com.mindtree.homeservice.dto;

import java.util.Arrays;
import java.util.List;

import com.mindtree.homeservice.core.entity.RegistrationDetail;
import com.mindtree.homeservice.user.entity.OrderHistory;
import com.mindtree.homeservice.vendor.entity.Address;
import com.mindtree.homeservice.vendor.entity.Service;

public class VendorDTO {

	private int vendorId;
	private String vendorFirstName;
	private String vendorLastName;
	private long vendorPhone;
	private String vendorEmail;
	private String vendorGender;
	private byte[] vendorImage;
	private String vendorDescription;
	private int rating;
	private String shopName;
	private double pricePerHour;
	private double experience;

	private AddressDTO vendorAddress;

	private RegistrationDetailDTO vendorRegistrationDetail;

	private ServiceDTO vendorService;

	private List<OrderHistoryDTO> vendorServices;

	public VendorDTO() {
		super();
	}

	public VendorDTO(int vendorId, String vendorFirstName, String vendorLastName, long vendorPhone, String vendorEmail,
			String vendorGender, byte[] vendorImage, String vendorDescription, int rating, String shopName,
			double pricePerHour, double experience, AddressDTO vendorAddress,
			RegistrationDetailDTO vendorRegistrationDetail, ServiceDTO vendorService,
			List<OrderHistoryDTO> vendorServices) {
		super();
		this.vendorId = vendorId;
		this.vendorFirstName = vendorFirstName;
		this.vendorLastName = vendorLastName;
		this.vendorPhone = vendorPhone;
		this.vendorEmail = vendorEmail;
		this.vendorGender = vendorGender;
		this.vendorImage = vendorImage;
		this.vendorDescription = vendorDescription;
		this.rating = rating;
		this.shopName = shopName;
		this.pricePerHour = pricePerHour;
		this.experience = experience;
		this.vendorAddress = vendorAddress;
		this.vendorRegistrationDetail = vendorRegistrationDetail;
		this.vendorService = vendorService;
		this.vendorServices = vendorServices;
	}

	@Override
	public String toString() {
		return "VendorDTO [vendorId=" + vendorId + ", vendorFirstName=" + vendorFirstName + ", vendorLastName="
				+ vendorLastName + ", vendorPhone=" + vendorPhone + ", vendorEmail=" + vendorEmail + ", vendorGender="
				+ vendorGender + ", vendorImage=" + Arrays.toString(vendorImage) + ", vendorDescription="
				+ vendorDescription + ", rating=" + rating + ", shopName=" + shopName + ", pricePerHour=" + pricePerHour
				+ ", experience=" + experience + ", vendorAddress=" + vendorAddress + ", vendorRegistrationDetail="
				+ vendorRegistrationDetail + ", vendorService=" + vendorService + ", vendorServices=" + vendorServices
				+ "]";
	}

}
