package com.mindtree.homeservice.dto;

public class AddressDTO {
	
	private int addressId;
	private String buildingNo;
	private String street;
	private String landmark;
	private String city;
	private String state;
	private int zip;
	
	public AddressDTO() {
		super();
	}
	
	public AddressDTO(int addressId, String buildingNo, String street, String landmark, String city, String state,
			int zip) {
		super();
		this.addressId = addressId;
		this.buildingNo = buildingNo;
		this.street = street;
		this.landmark = landmark;
		this.city = city;
		this.state = state;
		this.zip = zip;
	}
	@Override
	public String toString() {
		return "AddressDTO [addressId=" + addressId + ", buildingNo=" + buildingNo + ", street=" + street
				+ ", landmark=" + landmark + ", city=" + city + ", state=" + state + ", zip=" + zip + "]";
	}
	

}
