package com.mindtree.homeservice.core.service.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.mindtree.homeservice.core.entity.RegistrationDetail;
import com.mindtree.homeservice.core.repository.RegistrationDetailsRepository;
import com.mindtree.homeservice.core.service.SignUpManager;
import com.mindtree.homeservice.dto.RegistrationDetailDTO;
import com.mindtree.homeservice.util.AES;

@Service
public class SignUpManagerImpl implements SignUpManager {

	@Autowired
	RegistrationDetailsRepository registrationRepository;
	
	@Autowired
	RegistrationDetailsRepository registrationDetailsRepository;
	ModelMapper mapper = new ModelMapper();
	
	final String secretKey = "ssshhhhhhhhhhh!!!!";	
	
	
	public String SignUp(RegistrationDetailDTO userdto) {
		
		String result = "";
		
		List<RegistrationDetail> details = registrationRepository.findAll();
		for (RegistrationDetail registrationDetail : details) {
			if(registrationDetail.getUsername().equals(userdto.getUsername())) {
				return result = "Username Already exists";
			}
		}
		
		RegistrationDetail userDetail = mapper.map(userdto , RegistrationDetail.class);
		
		String encryptedPassword = AES.encrypt(userdto.getPassword(), secretKey) ;
		userDetail.setPassword(encryptedPassword);
		
		registrationDetailsRepository.save(userDetail);
		result = "Successfully Signed In";
		return result;
	}
		
}
