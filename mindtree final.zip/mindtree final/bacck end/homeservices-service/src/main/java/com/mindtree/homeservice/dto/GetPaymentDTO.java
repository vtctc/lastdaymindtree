package com.mindtree.homeservice.dto;

import com.mindtree.homeservice.user.entity.Payment;

public class GetPaymentDTO {

	Payment payment;
	String token;
	int vendorId;

	public GetPaymentDTO() {

	}

	public GetPaymentDTO(Payment payment, String token, int vendorId) {
		super();
		this.payment = payment;
		this.token = token;
		this.vendorId = vendorId;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public int getVendorId() {
		return vendorId;
	}

	public void setVendorId(int vendorId) {
		this.vendorId = vendorId;
	}

	@Override
	public String toString() {
		return "GetPaymentDTO [payment=" + payment + ", token=" + token + ", vendorId=" + vendorId + "]";
	}

}
