package com.mindtree.homeservice.util;

public class ErrorConstants {
	
	public static final String VENDORNOTFOUND="Vendor Not Found";
	public static final String CITYNOTFOUND="City not found";
	public static final String SERVICENOTFOUND="Service not found";
	public static final String PAYMENTUNSUCCESSFULL="Payment unsuccessfull";
	public static final String USERNAMENOTFOUND="UserName not found";
}
