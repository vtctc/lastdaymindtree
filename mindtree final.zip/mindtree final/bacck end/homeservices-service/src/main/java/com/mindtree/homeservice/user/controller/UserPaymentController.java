package com.mindtree.homeservice.user.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.homeservice.dto.GetPaymentDTO;
import com.mindtree.homeservice.dto.PaymentDTO;
import com.mindtree.homeservice.exception.HomeServiceException;
import com.mindtree.homeservice.exception.ServiceException;
import com.mindtree.homeservice.user.entity.Payment;
import com.mindtree.homeservice.user.service.UserPaymentManager;

@CrossOrigin("*")
@RestController
public class UserPaymentController {
	
	@Autowired 
	UserPaymentManager userPaymentManager;
	
	@PostMapping("/payment")
	public String paymentDetails(@RequestBody GetPaymentDTO paymentdto) throws HomeServiceException
	{
		System.err.println(paymentdto);
		Payment payment = paymentdto.getPayment();
		String token = paymentdto.getToken();
		int vendorId = paymentdto.getVendorId();
		return userPaymentManager.setPaymentDetails(payment,token,vendorId);
	}
	
}
