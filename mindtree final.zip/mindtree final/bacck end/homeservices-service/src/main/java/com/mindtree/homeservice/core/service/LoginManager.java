package com.mindtree.homeservice.core.service;

import com.mindtree.homeservice.dto.RegistrationDetailDTO;

public interface LoginManager {

	public String Login(RegistrationDetailDTO user);
}
