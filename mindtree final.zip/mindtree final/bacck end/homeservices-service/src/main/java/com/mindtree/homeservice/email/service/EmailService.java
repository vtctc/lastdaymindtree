package com.mindtree.homeservice.email.service;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.homeservice.user.entity.User;

public interface EmailService {

	void sendMail(SimpleMailMessage mail);
	ModelAndView makePayment(User user);
	String verifyToken(String token);
}
