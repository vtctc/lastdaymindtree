package com.mindtree.homeservice.user.service;

public interface UserDisplayServicesManager {

}
