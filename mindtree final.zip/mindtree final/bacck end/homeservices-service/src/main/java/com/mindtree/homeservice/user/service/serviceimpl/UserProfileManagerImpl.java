package com.mindtree.homeservice.user.service.serviceimpl;

import java.io.IOException;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.mindtree.homeservice.core.entity.RegistrationDetail;
import com.mindtree.homeservice.core.repository.RegistrationDetailsRepository;
import com.mindtree.homeservice.dto.AddressDTO;
import com.mindtree.homeservice.dto.UpdateUserProfileDTO;
import com.mindtree.homeservice.dto.UserDTO;
import com.mindtree.homeservice.user.entity.User;
import com.mindtree.homeservice.user.repository.UserRepository;
import com.mindtree.homeservice.util.AES;
import com.mindtree.homeservice.vendor.entity.Address;
import com.mindtree.homeservice.vendor.repository.AddressRepository;

@Service
public class UserProfileManagerImpl implements com.mindtree.homeservice.user.service.UserProfileManager {


	@Autowired
	UserRepository userRepository;

	@Autowired
	AddressRepository addressRepository;

	final String secretKey = "ssshhhhhhhhhhh!!!!";

	@Autowired
	RegistrationDetailsRepository registrationRepository;

	ModelMapper mapper = new ModelMapper();

	@Override
	public UpdateUserProfileDTO getUserByUserName(String userName) {

		List<User> userList = userRepository.findAll();
		User selectedUser = null;
		Address selectedAddress = null;
		userName = AES.decrypt(userName, secretKey);
		for (User user : userList) {
			if (user.getUserRegistrationDetail().getUsername().equals(userName)) {
				selectedUser = user;
				int addressId = user.getUserAddress().getAddressId();
				System.err.println(addressId);
				selectedAddress = addressRepository.getOne(addressId);
				break;
			}
		}
		
		UpdateUserProfileDTO profileDTO = new UpdateUserProfileDTO();
		
		profileDTO.setUserFirstName(selectedUser.getUserFirstName());
		profileDTO.setUserLastName(selectedUser.getUserLastName());
		profileDTO.setUserEmail(selectedUser.getUserEmail());
		profileDTO.setUserPhone(selectedUser.getUserPhone());
		profileDTO.setUserGender(selectedUser.getUserGender());
		profileDTO.setUserImage(selectedUser.getUserImage());
		profileDTO.setBuildingNo(selectedAddress.getBuildingNo());
		profileDTO.setStreet(selectedAddress.getStreet());
		profileDTO.setLandmark(selectedAddress.getLandmark());
		profileDTO.setCity(selectedAddress.getCity());
		profileDTO.setState(selectedAddress.getState());
		profileDTO.setZip(selectedAddress.getZip());
		profileDTO.setUserName(selectedUser.getUserRegistrationDetail().getUsername());
		
		
		return profileDTO;

	}


	@Override
	public UserDTO insertUserDetails(UpdateUserProfileDTO userdto, MultipartFile file) {

		RegistrationDetail registrationDetail = registrationRepository.getOne(userdto.getUserName());
		Address tempAddress = new Address(0, userdto.getBuildingNo(), userdto.getStreet(), userdto.getLandmark(),
				userdto.getCity(), userdto.getState(), userdto.getZip());
		addressRepository.save(tempAddress);

		byte[] arr = null;
		try {
			arr = file.getBytes();
		} catch (IOException e) {
			e.printStackTrace();
		}

		User user = new User(0, userdto.getUserFirstName(), userdto.getUserLastName(), userdto.getUserEmail(),
				userdto.getUserPhone(), userdto.getUserGender(), arr, tempAddress, registrationDetail, null);
		userRepository.save(user);
		UserDTO tt = mapper.map(user, UserDTO.class);

		return tt;
	}

	@Override
	public String updatePassword(String userName, String password) {
		String resultString = "";
		RegistrationDetail registrationDetail = registrationRepository.getOne(userName);
		System.err.println(registrationDetail);
		if (registrationDetail == null) {
			resultString = "No such user found";
		} else {

			registrationDetail.setPassword(AES.encrypt(password, secretKey));
			registrationRepository.saveAndFlush(registrationDetail);
			resultString = "Password Updated";
		}
		return resultString;
	}

	@Override
	public AddressDTO getAddressByUserName(String userName) {
		List<User>userList = userRepository.findAll();
		Address address = null;
		for (User user : userList) {
			if(user.getUserRegistrationDetail().getUsername().equals(userName)) {
				int addressId = user.getUserAddress().getAddressId();
				address = addressRepository.findById(addressId).get();
			}
		}
		return mapper.map(address, AddressDTO.class);
	}
}
