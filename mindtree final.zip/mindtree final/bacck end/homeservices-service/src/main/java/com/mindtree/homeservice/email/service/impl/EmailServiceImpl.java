package com.mindtree.homeservice.email.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.mindtree.homeservice.email.entity.Verification;
import com.mindtree.homeservice.email.exception.EmailServiceException;
import com.mindtree.homeservice.email.repository.VerificationRepository;
import com.mindtree.homeservice.email.service.EmailService;
import com.mindtree.homeservice.user.entity.User;
import com.mindtree.homeservice.user.repository.UserRepository;

@Service
public class EmailServiceImpl implements EmailService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private VerificationRepository verificationRepository;
	
	@Autowired
	private EmailService emailService;

	@Autowired
	private JavaMailSender javaMailSender;
	
	public EmailServiceImpl(JavaMailSender javaMailSender)
	{
		this.javaMailSender=javaMailSender;
	}
	
	public void sendMail(SimpleMailMessage mail) {
		javaMailSender.send(mail);
	}

	@Override
	public ModelAndView makePayment(User user) {
		ModelAndView modelAndView=new ModelAndView();
		String email=user.getUserEmail();
		
		Verification verificationToken=new Verification();
		verificationRepository.save(verificationToken);
		
		SimpleMailMessage mail=new SimpleMailMessage();
		mail.setTo(email);
		mail.setSubject("Payment Done");
		mail.setFrom("vidyarao933@gmail.com");
		mail.setText("Hi"+user.getUserFirstName()+","+
		"\n"+"Thank you for purchasing the service with us."+"\n"+"\n"+
				"Service Person Details:-"+"\n"+"Name:-");
		modelAndView.addObject("mail", user.getUserEmail());
		modelAndView.setViewName("payment successful");
		return modelAndView;
	}

	@Override
	public String verifyToken(String token) {
		Verification verification=verificationRepository.findByVerificationTokenOne(token);
		if(verification!=null)
		{
			
		}
		else
		{
			throw new EmailServiceException("invalid token");
		}
		return null;
	}

	
}
