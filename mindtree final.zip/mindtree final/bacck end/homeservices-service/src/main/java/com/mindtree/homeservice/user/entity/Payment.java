package com.mindtree.homeservice.user.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.mindtree.homeservice.vendor.entity.Vendor;

@Entity
public class Payment {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int paymentId;
	
	@JsonFormat(pattern="yyyy-MM-dd")
	private LocalDate date;

	private int amount;

	private String modeOfPayment;
	private String nameOnCard;
	private long cardNumber;
	private String expiryMonth;
	private String expiryYear;
	@OneToOne
	@JoinColumn
	private User userInvolved;
	@OneToOne
	@JoinColumn
	private Vendor vendorInvolved;

	public Payment() {

	}

	public Payment(int paymentId, LocalDate date, int amount, String nameOnCard, long cardNumber, String expiryMonth,
			String expiryYear, User userInvolved, Vendor vendorInvolved) {
		super();
		this.paymentId = paymentId;
		this.date = date;
		this.amount = amount;
		this.nameOnCard = nameOnCard;
		this.cardNumber = cardNumber;
		this.expiryMonth = expiryMonth;
		this.expiryYear = expiryYear;
		this.userInvolved = userInvolved;
		this.vendorInvolved = vendorInvolved;
	}

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public LocalDate getDate() {
		return date;
	}	

	public String getModeOfPayment() {
		return modeOfPayment;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	public void setDate(LocalDate date) {
		this.date = LocalDate.now();
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getNameOnCard() {
		return nameOnCard;
	}

	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}

	public long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getExpiryMonth() {
		return expiryMonth;
	}

	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth = expiryMonth;
	}

	public String getExpiryYear() {
		return expiryYear;
	}

	public void setExpiryYear(String expiryYear) {
		this.expiryYear = expiryYear;
	}

	public User getUserInvolved() {
		return userInvolved;
	}

	public void setUserInvolved(User userInvolved) {
		this.userInvolved = userInvolved;
	}

	public Vendor getVendorInvolved() {
		return vendorInvolved;
	}

	public void setVendorInvolved(Vendor vendorInvolved) {
		this.vendorInvolved = vendorInvolved;
	}

	@Override
	public String toString() {
		return "Payment [paymentId=" + paymentId + ", date=" + date + ", amount=" + amount + ", modeOfPayment="
				+ modeOfPayment + ", nameOnCard=" + nameOnCard + ", cardNumber=" + cardNumber + ", expiryMonth="
				+ expiryMonth + ", expiryYear=" + expiryYear + ", userInvolved=" + userInvolved + ", vendorInvolved="
				+ vendorInvolved + "]";
	}

}
