package com.mindtree.homeservice.user.service;

import org.springframework.web.multipart.MultipartFile;

import com.mindtree.homeservice.dto.AddressDTO;
import com.mindtree.homeservice.dto.UpdateUserProfileDTO;
import com.mindtree.homeservice.dto.UserDTO;
import com.mindtree.homeservice.user.entity.User;

public interface UserProfileManager {

	public UpdateUserProfileDTO getUserByUserName(String userName);
	
	public AddressDTO getAddressByUserName(String userName);
	
	public UserDTO insertUserDetails(UpdateUserProfileDTO userdto, MultipartFile file);
	
	public String updatePassword(String userName , String password);
}
