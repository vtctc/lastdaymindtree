package com.mindtree.homeservice.dto;

import java.util.List;

import com.mindtree.homeservice.vendor.entity.Vendor;

public class ServiceDTO {
	
	private int serviceId;
	private String serviceName;

	private List<VendorDTO> vendors;

	public ServiceDTO() {
		super();
	}

	public ServiceDTO(int serviceId, String serviceName, List<VendorDTO> vendors) {
		super();
		this.serviceId = serviceId;
		this.serviceName = serviceName;
		this.vendors = vendors;
	}

	 
	
	


}
