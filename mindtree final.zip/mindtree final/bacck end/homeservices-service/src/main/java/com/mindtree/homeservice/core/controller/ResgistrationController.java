package com.mindtree.homeservice.core.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.homeservice.core.entity.RegistrationDetail;
import com.mindtree.homeservice.core.service.LoginManager;
import com.mindtree.homeservice.core.service.SignUpManager;
import com.mindtree.homeservice.core.service.serviceimpl.SignUpManagerImpl;
import com.mindtree.homeservice.dto.RegistrationDetailDTO;

@RestController
@CrossOrigin(origins = "*")
public class ResgistrationController {

	
	@Autowired
	SignUpManager signupManager;
	
	@PostMapping("/signUpUser")
	public ResponseEntity<RegistrationDetail> loginUser(@RequestBody RegistrationDetailDTO user) {
		String result = signupManager.SignUp(user);
		return ResponseEntity.status(HttpStatus.OK).body(new RegistrationDetail(user.getUsername(), result, "user"));
	}
}
