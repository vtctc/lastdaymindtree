package com.mindtree.homeservice;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;


@SpringBootApplication
public class HomeServiceApplication extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(HomeServiceApplication.class, args);
	}
@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder appliccation) {
		return appliccation.sources(HomeServiceApplication.class);
	}

}
