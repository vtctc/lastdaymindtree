package com.mindtree.homeservice.dto;

import java.util.Arrays;
import java.util.List;

import com.mindtree.homeservice.core.entity.RegistrationDetail;
import com.mindtree.homeservice.user.entity.OrderHistory;
import com.mindtree.homeservice.vendor.entity.Address;

public class UserDTO {

	private int userId;

	private String userFirstName;

	private String userLastName;

	private String userEmail;

	private long userPhone;

	private String userGender;

	private byte[] userImage;

	private AddressDTO userAddress;

	private RegistrationDetailDTO userRegistrationDetail;

	private List<OrderHistoryDTO> userOrders;

	public UserDTO() {
		super();
	}

	public UserDTO(int userId, String userFirstName, String userLastName, String userEmail, long userPhone,
			String userGender, byte[] userImage, AddressDTO userAddress, RegistrationDetailDTO userRegistrationDetail,
			List<OrderHistoryDTO> userOrders) {
		super();
		this.userId = userId;
		this.userFirstName = userFirstName;
		this.userLastName = userLastName;
		this.userEmail = userEmail;
		this.userPhone = userPhone;
		this.userGender = userGender;
		this.userImage = userImage;
		this.userAddress = userAddress;
		this.userRegistrationDetail = userRegistrationDetail;
		this.userOrders = userOrders;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public long getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}

	public String getUserGender() {
		return userGender;
	}

	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}

	public byte[] getUserImage() {
		return userImage;
	}

	public void setUserImage(byte[] userImage) {
		this.userImage = userImage;
	}

	public AddressDTO getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(AddressDTO userAddress) {
		this.userAddress = userAddress;
	}

	public RegistrationDetailDTO getUserRegistrationDetail() {
		return userRegistrationDetail;
	}

	public void setUserRegistrationDetail(RegistrationDetailDTO userRegistrationDetail) {
		this.userRegistrationDetail = userRegistrationDetail;
	}

	public List<OrderHistoryDTO> getUserOrders() {
		return userOrders;
	}

	public void setUserOrders(List<OrderHistoryDTO> userOrders) {
		this.userOrders = userOrders;
	}

	@Override
	public String toString() {
		return "UserDTO [userId=" + userId + ", userFirstName=" + userFirstName + ", userLastName=" + userLastName
				+ ", userEmail=" + userEmail + ", userPhone=" + userPhone + ", userGender=" + userGender
				+ ", userImage=" + Arrays.toString(userImage) + ", userAddress=" + userAddress
				+ ", userRegistrationDetail=" + userRegistrationDetail + ", userOrders=" + userOrders + "]";
	}

}
