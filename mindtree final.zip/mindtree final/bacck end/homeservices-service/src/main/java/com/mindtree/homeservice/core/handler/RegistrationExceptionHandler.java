package com.mindtree.homeservice.core.handler;

import java.util.LinkedHashMap;
import java.util.Map;

import org.hibernate.service.spi.ServiceException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.homeservice.core.controller.LoginController;

@RestControllerAdvice(assignableTypes = LoginController.class)
public class RegistrationExceptionHandler {

	@ExceptionHandler(ServiceException.class)
	public ResponseEntity<Map<String, Object>> serviceExceptionHander(Exception exception , Throwable cause) {
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("Header", "Home Services");
		response.put("Error", true);
		response.put("message", exception.getMessage());
		response.put("HttpStatus", HttpStatus.BAD_REQUEST);
		
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.BAD_REQUEST);
	}
}
