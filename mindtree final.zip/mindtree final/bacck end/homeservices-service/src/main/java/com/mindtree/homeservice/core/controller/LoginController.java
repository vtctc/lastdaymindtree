package com.mindtree.homeservice.core.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.homeservice.core.service.LoginManager;
import com.mindtree.homeservice.dto.RegistrationDetailDTO;

@RestController
@CrossOrigin(origins = "*")
public class LoginController {

	@Autowired
	LoginManager loginManager;

	@PostMapping("/loginUser")
	public ResponseEntity<Map<String, Object>> loginUser(@RequestBody RegistrationDetailDTO user) {
		String messageString = loginManager.Login(user);
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("Header", "Home Services");
		response.put("Error", false);
		response.put("message", loginManager.Login(user));
		response.put("HttpStatus", HttpStatus.ACCEPTED);

		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);

	}
}
