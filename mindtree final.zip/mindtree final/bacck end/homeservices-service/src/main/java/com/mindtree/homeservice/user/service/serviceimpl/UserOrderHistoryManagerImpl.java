
package com.mindtree.homeservice.user.service.serviceimpl;

public class UserOrderHistoryManagerImpl implements com.mindtree.homeservice.user.service.UserOrderHistoryManager {

}
