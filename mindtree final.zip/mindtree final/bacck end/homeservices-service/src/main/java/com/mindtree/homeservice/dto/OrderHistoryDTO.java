package com.mindtree.homeservice.dto;

import java.time.LocalDate;

import com.mindtree.homeservice.user.entity.Payment;
import com.mindtree.homeservice.user.entity.User;
import com.mindtree.homeservice.vendor.entity.Address;
import com.mindtree.homeservice.vendor.entity.Vendor;

public class OrderHistoryDTO {
	
	private int orderId;
	private LocalDate date;
	private int peopleCount;
	private int address;
	private String feedbackString;
	private String timeSlot;

	private AddressDTO userAddress;
	
	private UserDTO userInvolved;

	private VendorDTO vendorInvolved;

	private PaymentDTO payment;

	public OrderHistoryDTO() {
		super();
	}

	public OrderHistoryDTO(int orderId, LocalDate date, int peopleCount, int address, String feedbackString,
			String timeSlot, AddressDTO userAddress, UserDTO userInvolved, VendorDTO vendorInvolved,
			PaymentDTO payment) {
		super();
		this.orderId = orderId;
		this.date = date;
		this.peopleCount = peopleCount;
		this.address = address;
		this.feedbackString = feedbackString;
		this.timeSlot = timeSlot;
		this.userAddress = userAddress;
		this.userInvolved = userInvolved;
		this.vendorInvolved = vendorInvolved;
		this.payment = payment;
	}

	 
	

}
