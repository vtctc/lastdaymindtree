package com.mindtree.homeservice.exception;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ControlAdvisory {

	@ExceptionHandler(HomeServiceException.class)
	@ResponseStatus(value = HttpStatus.NOT_FOUND)
	public ExceptionResponse handleServiceException(final HomeServiceException exception,final HttpServletRequest request)
	{
		ExceptionResponse error=new ExceptionResponse();
		error.setErrorMessage(exception.getMessage());
		error.setRequestUrl(request.getRequestURI());
		return error;
	}	
}
