package com.mindtree.homeservice.user.service.serviceimpl;

import com.mindtree.homeservice.user.service.UserDisplayServicesManager;

public class UserDisplayServicesManagerImpl implements UserDisplayServicesManager {

}

