package com.mindtree.homeservice.user.service.serviceimpl;

import com.mindtree.homeservice.user.service.UserBookServiceManager;

public class UserBookServiceManagerImpl implements UserBookServiceManager {

}
