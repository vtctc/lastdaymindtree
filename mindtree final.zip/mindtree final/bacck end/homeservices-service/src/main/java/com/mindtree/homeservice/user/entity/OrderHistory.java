package com.mindtree.homeservice.user.entity;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.mindtree.homeservice.vendor.entity.Address;
import com.mindtree.homeservice.vendor.entity.Vendor;

@Entity
public class OrderHistory {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderId;
	private LocalDate date;
	private int peopleCount;
	private int address;
	private String feedbackString;
	private String timeSlot;
	@OneToOne
	@JoinColumn
	private Address userAddress;
	@ManyToOne
	private User userInvolved;
	@ManyToOne
	private Vendor vendorInvolved;
	@OneToOne
	@JoinColumn
	private Payment payment;

	public OrderHistory() {

	}

	public OrderHistory(int orderId, LocalDate date, int peopleCount, int address, String feedbackString,
			String timeSlot, Address userAddress, User userInvolved, Vendor vendorInvolved, Payment payment) {
		super();
		this.orderId = orderId;
		this.date = date;
		this.peopleCount = peopleCount;
		this.address = address;
		this.feedbackString = feedbackString;
		this.timeSlot = timeSlot;
		this.userAddress = userAddress;
		this.userInvolved = userInvolved;
		this.vendorInvolved = vendorInvolved;
		this.payment = payment;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public int getPeopleCount() {
		return peopleCount;
	}

	public void setPeopleCount(int peopleCount) {
		this.peopleCount = peopleCount;
	}

	public int getAddress() {
		return address;
	}

	public void setAddress(int address) {
		this.address = address;
	}

	public String getFeedbackString() {
		return feedbackString;
	}

	public void setFeedbackString(String feedbackString) {
		this.feedbackString = feedbackString;
	}

	public String getTimeSlot() {
		return timeSlot;
	}

	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}

	public Address getUserAddress() {
		return userAddress;
	}

	public void setUserAddress(Address userAddress) {
		this.userAddress = userAddress;
	}

	public User getUserInvolved() {
		return userInvolved;
	}

	public void setUserInvolved(User userInvolved) {
		this.userInvolved = userInvolved;
	}

	public Vendor getVendorInvolved() {
		return vendorInvolved;
	}

	public void setVendorInvolved(Vendor vendorInvolved) {
		this.vendorInvolved = vendorInvolved;
	}

	public Payment getPayment() {
		return payment;
	}

	public void setPayment(Payment payment) {
		this.payment = payment;
	}

}
