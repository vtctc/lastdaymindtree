package com.mindtree.homeservice.email.entity;

import java.sql.Date;
import java.util.UUID;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import com.mindtree.homeservice.core.entity.RegistrationDetail;
import com.mindtree.homeservice.user.entity.User;

@Entity
public class Verification {
	
	private static final int EXPIRATION=60*24;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	private String verificationTokenOne;
	
	@OneToOne(fetch=FetchType.EAGER)
	private User user;
	
	private Date expiryDateOne;

	public Verification(int id, String verificationTokenOne, User user, Date expiryDateOne) {
		super();
		this.id = id;
		this.verificationTokenOne = verificationTokenOne;
		this.user = user;
		this.expiryDateOne = expiryDateOne;
	}

	public Verification() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Verification(User user)
	{
		this.user=user;
		expiryDateOne=new Date(1L);
		verificationTokenOne=UUID.randomUUID().toString();
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getVerificationTokenOne() {
		return verificationTokenOne;
	}

	public void setVerificationTokenOne(String verificationTokenOne) {
		this.verificationTokenOne = verificationTokenOne;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Date getExpiryDateOne() {
		return expiryDateOne;
	}

	public void setExpiryDateOne(Date expiryDateOne) {
		this.expiryDateOne = expiryDateOne;
	}

	public static int getExpiration() {
		return EXPIRATION;
	}

	@Override
	public String toString() {
		return "Verification [id=" + id + ", verificationTokenOne=" + verificationTokenOne + ", user=" + user
				+ ", expiryDateOne=" + expiryDateOne + "]";
	}
}