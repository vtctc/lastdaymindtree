package com.mindtree.homeservice.core.service.serviceimpl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.homeservice.core.entity.RegistrationDetail;
import com.mindtree.homeservice.core.repository.RegistrationDetailsRepository;
import com.mindtree.homeservice.core.service.LoginManager;
import com.mindtree.homeservice.dto.RegistrationDetailDTO;
import com.mindtree.homeservice.util.AES;

@Service
public class LoginManagerImpl implements LoginManager {

	@Autowired
	RegistrationDetailsRepository registrationRepository;

	ModelMapper mapper = new ModelMapper();

	final String secretKey = "ssshhhhhhhhhhh!!!!";

	public String Login(RegistrationDetailDTO userdto) {
		// Initalize the result string as empty string
		String result = "";
		RegistrationDetail user = null;
		RegistrationDetail tempUser = mapper.map(userdto, RegistrationDetail.class);
		
		List<RegistrationDetail> userList = registrationRepository.findAll();

		for (RegistrationDetail temp : userList) {
			if (temp.getUsername().equals(tempUser.getUsername())) {
				user = temp;
			}
		}

		if (user == null) {
			result = "Username doesnot exists";
		}else {
			if (AES.decrypt(user.getPassword(), secretKey).equals(userdto.getPassword()))
				result = AES.encrypt(userdto.getUsername(), secretKey);
			else
				result = "Wrong Password";
		}
		return result;
	}

}
