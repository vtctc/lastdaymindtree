package com.mindtree.homeservice.user.controller;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mindtree.homeservice.dto.AddressDTO;
import com.mindtree.homeservice.dto.UpdateUserProfileDTO;
import com.mindtree.homeservice.dto.UserDTO;
import com.mindtree.homeservice.user.service.UserProfileManager;

@RestController
@CrossOrigin(origins = "*")
public class UserProfileController {
	
	@Autowired
	UserProfileManager manager;
	
	@PostMapping("/getUserByUserName")
	public ResponseEntity<Map<String, Object>> getUserByUserName(@RequestBody String userName) {
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("Header", "Home Services");
		response.put("Error", false);
		response.put("message", manager.getUserByUserName(userName));
		response.put("HttpStatus", HttpStatus.ACCEPTED);

		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	}
	
	@GetMapping("/getUserAddress")
	public ResponseEntity<Map<String, Object>> getUserAddress(@RequestBody String userName) {
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("Header", "Home Services");
		response.put("Error", false);
		response.put("message", manager.getAddressByUserName(userName));
		response.put("HttpStatus", HttpStatus.ACCEPTED);

		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	}
	
	@PostMapping("/insertDetails/{file}")
	public UserDTO insertUserDetails(@RequestBody UpdateUserProfileDTO userdto , @PathVariable MultipartFile file) {
		return manager.insertUserDetails(userdto,file);
	}
	
	@PostMapping("/updatePassword/{userName}/{password}")
	public ResponseEntity<Map<String,Object>> insertUserDetails(@PathVariable String userName , @PathVariable String password) {
		Map<String, Object> response = new LinkedHashMap<String, Object>();
		response.put("Header", "Home Services");
		response.put("Error", false);
		response.put("message", manager.updatePassword(userName, password));
		response.put("HttpStatus", HttpStatus.ACCEPTED);

		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
	}
}
