package com.mindtree.homeservice.dto;

import java.time.LocalDate;

import com.mindtree.homeservice.user.entity.User;
import com.mindtree.homeservice.vendor.entity.Vendor;

public class PaymentDTO {
	
	private int paymentId;
	
	private LocalDate date;

	private int amount;

	private UserDTO userInvolved;

	private VendorDTO vendorInvolved;

	public PaymentDTO() {
		super();
	}

	public PaymentDTO(int paymentId, LocalDate date, int amount, UserDTO userInvolved, VendorDTO vendorInvolved) {
		super();
		this.paymentId = paymentId;
		this.date = date;
		this.amount = amount;
		this.userInvolved = userInvolved;
		this.vendorInvolved = vendorInvolved;
	}

 


}
