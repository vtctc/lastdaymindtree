import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DisplayvendorComponent } from './displayvendor/displayvendor.component';
import { CityService } from './city.service';
import { HomeComponent } from './home/home.component';
import { LoginuserComponent } from './loginuser/loginuser.component';
import { RegistrationComponent } from './registration/registration.component';
import { LoginComponent } from './login/login.component';
import{PriceFilterPipe} from './price-filter.pipe';
import{ExperienceFilterPipe} from './experience-filter.pipe';
import{RatingFilterPipe} from './rating-filter.pipe';
import { LoginguardGuard } from './guard/loginguard.guard';
import { PaymentComponent } from './payment/payment.component';
import {Payment} from './payment';
import { NgxSpinnerModule } from "ngx-spinner";
import { BookServiceComponent } from './book-service/book-service.component';
import { OrderHistoryComponent } from './order-history/order-history.component';
import { ServicesComponent } from './services/services.component';
import { UserComponent } from './user/user.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { VendorComponent } from './vendor/vendor.component';
import { EditUserProfileComponent } from './edit-user-profile/edit-user-profile.component';
@NgModule({
  declarations: [
    AppComponent,
    DisplayvendorComponent,
    HomeComponent,
    LoginuserComponent,
    PaymentComponent,
    LoginComponent,
    
    RegistrationComponent,
    OrderHistoryComponent,
    PriceFilterPipe,
    ExperienceFilterPipe,
    RatingFilterPipe,
    BookServiceComponent,
    PaymentComponent,
    ServicesComponent,
    UserComponent,
    UserProfileComponent,
    VendorComponent,
    EditUserProfileComponent
  ],
  imports: [
    BrowserModule,
    NgxSpinnerModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  providers: [CityService,LoginguardGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
