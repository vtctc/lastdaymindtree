import { AlluserData } from './alluser-data';

describe('AlluserData', () => {
  it('should create an instance', () => {
    expect(new AlluserData()).toBeTruthy();
  });
});
