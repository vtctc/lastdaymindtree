export class UserRegistration {
    userName : string;
    password : string;
    role : string;
}
