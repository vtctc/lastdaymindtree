import { Paymentdto } from './paymentdto';

describe('Paymentdto', () => {
  it('should create an instance', () => {
    expect(new Paymentdto()).toBeTruthy();
  });
});
