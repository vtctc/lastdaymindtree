import { Payment } from '../payment';

export class Paymentdto {
    payment : Payment;
    token : String;
    vendorId : number;

    constructor() {}
}

