import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Api} from '../Api';

@Injectable({
  providedIn: 'root'
})
export class ViewProfileService {

  constructor(private http : HttpClient) { }
  api=new Api()
  getUserDataByUserName(userName) : Observable<any>{
    return this.http.post<any>(this.api.baseUrl+'/getUserByUserName',userName);
  }
}
