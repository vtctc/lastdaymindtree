import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import {Api} from '../Api';
@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  role : string;

  constructor(private http : HttpClient) { }
  api=new Api()
  
  public loginUser(user : any) : Observable<any> {

    
    // return this.http.post<any>('http://localhost:8080/loginUser',user);

    return this.http.post<any>(this.api.baseUrl+'/loginUser',user);
  }

  setUserRole(userRole : string) {
    this.role=userRole;
  }

  getUserRole() {
    return this.role;
  }
}
