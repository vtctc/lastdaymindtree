import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Api } from '../Api';
import { Payment } from '../payment';
import { Paymentdto } from '../entity/paymentdto';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  constructor(private http:HttpClient) { }

  api = new Api();
  paymentObj : Paymentdto = new Paymentdto();
  public paymentDetails(token,vendorId,payment)
  {
    this.paymentObj.payment = payment;
    this.paymentObj.token = token;
    this.paymentObj.vendorId = vendorId;  
    return this.http.post(this.api.baseUrl+'/payment',this.paymentObj,{responseType : "text" as "json"}).subscribe(success=>{alert(success)},error=>{console.log(error)});
  }
}
