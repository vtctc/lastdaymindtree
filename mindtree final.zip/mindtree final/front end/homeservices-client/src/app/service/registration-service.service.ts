import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import {Api} from '../Api';
@Injectable({
  providedIn: 'root'
})
export class RegistrationServiceService {

  constructor(private http : HttpClient) { }
  api=new Api()
  public signUp(user : any) : Observable<any> {
    return this.http.post<any>(this.api.baseUrl+'/signUpUser',user);
  }
}
