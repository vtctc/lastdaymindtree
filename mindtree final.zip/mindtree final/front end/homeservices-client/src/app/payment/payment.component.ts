import { Component, OnInit, HostListener } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { PaymentService } from '../service/payment.service';
import {Payment} from '../payment'
import { CityService } from '../city.service';
import { BookServiceComponent } from '../book-service/book-service.component';
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',

  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {
paymentForm :FormGroup;
  constructor(private router : Router , private fb: FormBuilder,private paymentService:PaymentService,private cityService:CityService) { }
  paymentObj:Payment;
  payment:any;
  token:any;
  vendorId:any;

  ngOnInit() {

    if(!!localStorage.getItem('token')==false) {
      this.router.navigate(['login']);
    }
    this.payment=this.cityService.setTotalAmount();

    this.paymentForm = this.fb.group({
      Pay:['credit',Validators.required],
      nameOnCard:['',Validators.required],
      cardNumber:['',[Validators.required,Validators.min(1000000000000000),Validators.max(9999999999999999)]],
      expiryMonth:['',Validators.required],
      expiryYear:['',Validators.required],
      cvv:['',[Validators.required,Validators.min(100),Validators.max(999)]]
           
    });
    this.token=localStorage.getItem('token');
    // console.log(this.token);
  }
  
onSubmit()
{
  if (this.paymentForm.invalid) {
    return;
}

  this.paymentObj = new Payment();
  this.paymentObj.cardNumber=this.paymentForm.value.cardNumber;
  this.paymentObj.nameOnCard=this.paymentForm.value.nameOnCard;
  this.paymentObj.modeOfPayment=this.paymentForm.value.Pay;
  this.paymentObj.expiryMonth=this.paymentForm.value.expiryMonth;
  this.paymentObj.expiryYear=this.paymentForm.value.expiryYear;
   this.vendorId=this.cityService.setVendorId();
  console.log(this.vendorId);
   this.paymentObj.amount=this.cityService.setTotalAmount();
  
  console.log(this.paymentObj.amount);
  this.paymentService.paymentDetails(this.token,this.vendorId,this.paymentObj);
  alert("Payment Successfull");
  this.router.navigate(['/home']);
}
}
