import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayvendorComponent } from './displayvendor/displayvendor.component';
import { HomeComponent } from './home/home.component';

import { LoginuserComponent } from './loginuser/loginuser.component';
import { RegistrationComponent } from './registration/registration.component';
import { BookServiceComponent } from './book-service/book-service.component';
import { PaymentComponent } from './payment/payment.component';
import { LoginguardGuard } from './guard/loginguard.guard';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { EditUserProfileComponent } from './edit-user-profile/edit-user-profile.component';
const routes: Routes = [{ path: "", component: HomeComponent },
{ path: 'display', component: DisplayvendorComponent },
{ path: 'home', component: HomeComponent },
{ path: 'login', component: LoginuserComponent },
{ path: 'signup', component: RegistrationComponent },
{ path: 'userprofile', component: UserProfileComponent },
{ path: 'payment', component: PaymentComponent },
{ path: 'detail/vendorId/:id', component: BookServiceComponent },
{ path: 'editUserProfile', component: EditUserProfileComponent },
{ 
  path: 'payment',
  component: PaymentComponent,
  canActivate:[LoginguardGuard]
}
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes , { useHash: true })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
