import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators, MaxLengthValidator } from '@angular/forms';
import { MustMatch } from './registration.validator';
import { RegistrationServiceService } from '../service/registration-service.service';
import { UserRegistration } from '../entity/user-registration';
import { LoginServiceService } from '../service/login-service.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {
  
submitted = false;
constructor(private router : Router, private loginService : LoginServiceService, private formBuilder : FormBuilder , private registrationService:RegistrationServiceService) { }

user :any;
message : UserRegistration;
errorMessage : string;
successMesssage : string;
passwordValue : string;
confirmPasswordValue : string;
userValue : string;

signupForm = this.formBuilder.group({
  userName : ['',[Validators.required,Validators.maxLength(30)]],
  password : ['',[Validators.required,Validators.minLength(8),Validators.maxLength(30),Validators.maxLength(30)]],
  confirmPassword : ['',[Validators.required,Validators.minLength(8),Validators.maxLength(30)]]
},{
  validator: MustMatch('password', 'confirmPassword')
});

ngOnInit() {
}

get f() { return this.signupForm.controls; }

onSubmit() {
  this.userValue = this.signupForm.value.userName;
  this.passwordValue = this.signupForm.value.password;
  this.confirmPasswordValue = this.signupForm.value.confirmPassword;
  if(this.passwordValue === "") {
    this.errorMessage = "Enter all the details";
  }
  else if(this.confirmPasswordValue === "") {
    this.errorMessage = "Enter all the details";
  }
  else if(this.userValue === "") {
    this.errorMessage = "Enter all the details";
  }
  
  this.submitted = true;
  if (this.signupForm.invalid) {
      return;
  }
  this.user = new UserRegistration ();
  this.user.username = this.signupForm.value.userName;
  this.user.password = this.signupForm.value.password;
  this.user.role = "user";

  this.registrationService.signUp(this.user).subscribe(data=>{
    this.message=data;
    
    if(this.message.password.match("Successfully Signed In")===null) {
        this.errorMessage=this.message.password;
        this.successMesssage=null;
    }
    else {
      this.router.navigate(['/home']);
    }
  })
  
}

}
