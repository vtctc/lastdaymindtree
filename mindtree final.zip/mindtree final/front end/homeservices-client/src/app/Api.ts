export class Api{
baseUrl:string="https://eswar-home-services-api-dev.azurewebsites.net";
}
//https://eswar-home-services-api-dev.azurewebsites.net