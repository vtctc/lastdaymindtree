import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { UserRegistration } from '../entity/user-registration';
import { LoginServiceService } from '../service/login-service.service';
import { CanActivate, Router } from '@angular/router';
import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: 'app-loginuser',
  templateUrl: './loginuser.component.html',
  styleUrls: ['./loginuser.component.scss']
})


export class LoginuserComponent implements OnInit {

  submitted = false;
  constructor(private formBuilder: FormBuilder, private spinner: NgxSpinnerService, private loginService: LoginServiceService, private router: Router) { }

  loginForm = this.formBuilder.group({
    userName: ['', [Validators.required, Validators.maxLength(30)]],
    password: ['', [Validators.required, Validators.minLength(8), Validators.maxLength(30)]]
  });

  user: any;
  role: any;
  ngOnInit() {
    if (!!localStorage.getItem('token')) {
      this.router.navigate(['home']);
    }
  }


  get f() { return this.loginForm.controls; }
  errorMessage: any;

  onSubmit() {
    this.spinner.show();
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }

    this.user = new UserRegistration();
    this.user.username = this.loginForm.value.userName;
    this.user.password = this.loginForm.value.password;
    this.user.role = this.loginService.getUserRole();

    this.loginService.loginUser(this.user).subscribe(data => {
      this.user = data.message;
      this.errorMessage = this.user;
      this.spinner.hide();
      if (this.errorMessage.match("Wrong Password") === null) {
        if (this.errorMessage.match("Username doesnot exists") === null) {
          localStorage.setItem('token', data.message);
          this.router.navigate(['/editUserProfile']);
          this.errorMessage = null;
        }
      }
    })


  }

}
