export class Payment {
    amount:number;
    modeOfPayment:any;
    nameOnCard:any;
    cardNumber:any;
    expiryMonth:any;
    expiryYear:any;
    

}
