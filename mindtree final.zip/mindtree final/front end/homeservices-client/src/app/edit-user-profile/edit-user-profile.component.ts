import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators } from '@angular/forms';
import { MustMatch } from '../registration/registration.validator';
import { ViewProfileService } from '../service/view-profile.service';
import { count } from 'rxjs/operators';
import { RegistrationComponent } from '../registration/registration.component';
import { UserRegistration } from '../entity/user-registration';
  
@Component({
  selector: 'app-edit-user-profile',
  templateUrl: './edit-user-profile.component.html',
  styleUrls: ['./edit-user-profile.component.scss']
})
export class EditUserProfileComponent implements OnInit {

  constructor(private formBuilder : FormBuilder , private view_service : ViewProfileService) { }

  editProfileForm= this.formBuilder.group({
    firstName : ['',Validators.required],
    lastName : ['',Validators.required],
    email : ['',[Validators.required,Validators.email]],
    phone : ['',[Validators.required,Validators.min(1000000000),Validators.max(9999999999)]],
    gender : ['male',Validators.required],
    buildingNo : ['',Validators.required],
    street : ['',Validators.required],
    landmark : ['',Validators.required],
    city : ['',Validators.required],
    state : ['',Validators.required],
    zip : ['',[Validators.required,Validators.min(1000000),Validators.max(9999999)]],
    isPasswordChanged : ['true',[Validators.required]],
    password : ['',[Validators.required,Validators.minLength(8)]],
    confirmPassword : ['',[Validators.required,Validators.minLength(8)]]
  },{
    validator: MustMatch('password', 'confirmPassword')
  });

  temp : any;
  userDetails : any ;
  file :any;
  fileMessage : any = "No File Choosen.";
  isChecked : boolean;

  public selectedFile;
  public event1;
  imgURL: any;
  receivedImageData: any;
  base64Data: any;
  convertedImage: any;
  ngOnInit() {

    this.view_service.getUserDataByUserName(localStorage.getItem('token')).subscribe(
      data => { 
       this.temp = data.message;
       this.userDetails = this.temp;
      }
    );
  }

  public  onFileChanged(event) {
    console.log(event);
    this.selectedFile = event.target.files[0];

    // Below part is used to display the selected image
    let reader = new FileReader();
    reader.readAsDataURL(event.target.files[0]);
    reader.onload = (event2) => {
      this.imgURL = reader.result;
  }
}

  

  isPasswordEnabled() {
    return this.editProfileForm.value.isPasswordChanged;
  }

}
