import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';
import { CityService } from '../city.service';
import { ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import {HttpErrorResponse} from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  homeserviceForm: FormGroup;
  cityName: String;
  serviceName: String;
  city: any;
  service: any;
  date: any;
  filteredData: any;
  cities: any;
  isCityNameValid : any;
  servicedata:any;
  isValid : boolean = true;

  constructor(private fb: FormBuilder, private serviceObj: CityService,private router : Router) { }

  ngOnInit() {
    this.homeserviceForm = this.fb.group({
      cityName: ['',[Validators.required]],
      serviceName: ['',Validators.required],
      Date: ['']
    });

    this.serviceObj.getCities().subscribe(
     
      data => { 

        this.cities = data
      }
      );

      this.serviceObj.getServices().subscribe(
        success=>{this.servicedata=success}
      );
    
  }
  onsubmit() {
    if(this.homeserviceForm.get('cityName').value =='') {
      this.isValid=false; 
      return;
    }
    if(this.homeserviceForm.get('serviceName').value =='') {
      this.isValid=false;
      return;
    }
    else {      
      this.cityName = this.homeserviceForm.value.cityName;
      this.serviceName = this.homeserviceForm.value.serviceName;
      this.date = this.homeserviceForm.value.Date;
    
    this.serviceObj.filterData(this.serviceName, this.cityName).
    subscribe(success => { this.service = success,this.serviceObj.setVendorDetails(this.service) },
    (error: HttpErrorResponse) => {});  
    }
      this.router.navigate(['/display']);
  } 
  

}
