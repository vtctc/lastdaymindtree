import { PipeTransform, Pipe } from '@angular/core';
@Pipe({
    name: 'priceFilter'
})
export class PriceFilterPipe implements PipeTransform {
    transform(vendors: any[], price: any): any[] {
        let filteredVendors: any[] = [];
        if (!vendors || !price) {
            return vendors;
        }

        vendors.forEach(vendor => {
            if (vendor.pricePerHour >= price) {
                filteredVendors.push(vendor);
            }
        })
        return filteredVendors;
    }
}

