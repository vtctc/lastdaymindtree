import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CityService } from '../city.service';
import { Location } from '@angular/common';
import { NgxSpinnerService } from "ngx-spinner";
// import { Injectable } from '@angular/core';

@Component({
  selector: 'app-book-service',
  templateUrl: './book-service.component.html',
  styleUrls: ['./book-service.component.scss']
})
// @Injectable()
export class BookServiceComponent implements OnInit {

  constructor(private route:ActivatedRoute, private spinner: NgxSpinnerService, private cityService:CityService,private location:Location) { }
num:number=1;
  vendor:any;
  path:String;
  bool=true;
  count=1;
  exception:any;
  vendorPrice:any;
  totalPrice:any;
  vendorId:any;
  checkTotal : number;
  ngOnInit(): void {
   

    this.getVendorOnId();
    // this.totalPrice=this.num*this.vendorPrice;
    // console.log(this.totalPrice); 
  }
  
  getVendorOnId():void {
    let id = +this.route.snapshot.paramMap.get('id');
    this.cityService.getVendorOnId(id).subscribe(vendor => {
      this.vendor = vendor,this.vendorPrice=vendor.pricePerHour,this.vendorId=vendor.vendorId;
      this.cityService.getVendorId(this.vendorId);
    },
  error=>{
    this.exception=error.message;
  });
  }
  goBack():void
  {
    this.location.back();
  }
  setBillAmount() {
    this.cityService.getTotalAmount(this.vendorPrice*this.num);
  }
  onSubmit():void
  {
    if(this.count==0)
    {
      this.bool=true;
    }
    else
    {
      this.bool=false;
    }
  }
  add():void
  {
    if(this.num<10)
    this.num++;
  }
  sub():void
  {
    if(this.num>1)
    {
      this.num--;
    }
  }
  totalAmount():void{
    this.totalPrice=this.num*this.vendorPrice; 

    this.cityService.getTotalAmount(this.totalPrice);
    return this.totalPrice;
  }

  setVendorId():void{
    return this.vendorId;
  }
}
