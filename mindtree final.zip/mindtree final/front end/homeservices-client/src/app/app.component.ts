import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CityService } from './city.service';
import { ReactiveFormsModule } from '@angular/forms';
import { LoginServiceService } from './service/login-service.service';
import { LoginuserComponent } from './loginuser/loginuser.component';
import { AuthServiceService } from './service/auth-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  isUserloggedIn : any;
  title = 'homeservicesproject';
  homeserviceForm: FormGroup;
  cityName: String;
  serviceName: String;
  city: any;
  service: any;
  date: any;
  filteredData: any;
  cities: any;
  constructor(private fb: FormBuilder, private serviceObj: CityService, private authService : AuthServiceService) { }

  ngOnInit() {
    this.isUserloggedIn = !this.authService.isloggedIn();
    
    this.homeserviceForm = this.fb.group({
      cityName: '',
      serviceName: '',
      Date: ''
    });

    this.serviceObj.getCities().subscribe(
      data => { 
        this.cities = data;
      }
      );

    }
    isTokenPresent() {
      return !!localStorage.getItem('token');
      
    }
    logout() {
      localStorage.removeItem('token');
      console.log("called ng on it again");
      
      this.ngOnInit();
    }
  onsubmit() {
    this.cityName = this.homeserviceForm.value.cityName;
    console.log(this.cityName);
    this.serviceName = this.homeserviceForm.value.serviceName;
    console.log(this.serviceName);
    this.date = this.homeserviceForm.value.Date;
   
   this.serviceObj.filterData(this.serviceName, this.cityName).
   subscribe(success => { this.service = success,this.serviceObj.setVendorDetails(this.service) },
    error => { console.log("error", error); });    
  }
  
}
