import { Component, OnInit } from '@angular/core';
import { ViewProfileService } from '../service/view-profile.service';
import { NgxSpinnerService } from "ngx-spinner";
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {

  public selectedFiles;
  userDetails: any;
  temp: any;
  constructor(private profileService: ViewProfileService, private spinner: NgxSpinnerService) { }

  ngOnInit() {

    this.getProfile();
  }
  getProfile() {
    this.spinner.show();
    this.profileService.getUserDataByUserName(localStorage.getItem('token')).subscribe(
      data => {
        this.spinner.hide();
        this.temp = data.message;
        this.userDetails = this.temp;
        this.spinner.hide();
      }
    );
  }

  turnSpinnerOn() {
    this.spinner.show();
  }

  public onFileChanged(event) {
    console.log(event);
    this.selectedFiles = event.target.files[0];
  }
}
