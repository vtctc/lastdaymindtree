import { Component, OnInit, Input } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CityService } from '../city.service';
import { HttpErrorResponse } from '@angular/common/http';
import { NgxSpinnerService } from '../../../node_modules/ngx-spinner';
@Component({
  selector: 'app-displayvendor',
  templateUrl: './displayvendor.component.html',
  styleUrls: ['./displayvendor.component.css']
})

export class DisplayvendorComponent implements OnInit {
  @Input() msg: any;
  vendordata: any;
  temp: any;
  price: any;
  experience: any;
  rating: any;
  errorMessage: any;

  bool = true;

  errors: any;
  constructor(
    private serviceObj: CityService,
    private spinner: NgxSpinnerService
  ) {

  }

  ngOnInit() {
    this.spinner.show();
    this.serviceObj.getVendorDetails().subscribe(
      data => {
        this.myGridOptions = data;
      }, (error: HttpErrorResponse) => {
        if (error.status === 404) { this.errors = error.error.errorMessage; this.errorMessage = this.errors; console.log(this.errorMessage) }
      }
    );
    this.spinner.hide();

  }
  myGridOptions: any;
  onsubmit() {
    this.bool = false;
  }
  onChange(event) {
    this.price = event;

  }
  onExperience(event) {
    this.experience = event;

  }

  onRating(event) {
    this.rating = event;

  }

}
