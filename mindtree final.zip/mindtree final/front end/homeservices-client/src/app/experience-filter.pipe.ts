import { PipeTransform, Pipe } from '@angular/core';
@Pipe({
    name: 'experienceFilter'
})
export class ExperienceFilterPipe implements PipeTransform {
    transform(vendors: any[], experience: any): any[] {
        let filteredVendors: any[] = [];
        if (!vendors || !experience) {
            return vendors;
        }

        vendors.forEach(vendor => {
            if (vendor.experience >= experience) {
                filteredVendors.push(vendor);
            }
        })
        return filteredVendors;
    }
}

