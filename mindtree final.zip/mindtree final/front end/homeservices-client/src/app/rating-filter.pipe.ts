import { PipeTransform, Pipe } from '@angular/core';
@Pipe({
    name: 'ratingFilter'
})
export class RatingFilterPipe implements PipeTransform {
    transform(vendors: any[], rating: any): any[] {
        let filteredVendors: any[] = [];
        if (!vendors || !rating) {
            return vendors;
        }

        vendors.forEach(vendor => {
            if (vendor.rating >= rating) {
                filteredVendors.push(vendor);
            }
        })
        return filteredVendors;
    }
}

