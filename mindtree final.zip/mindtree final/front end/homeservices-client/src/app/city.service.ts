import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { throwError, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Api } from './Api';
@Injectable({
  providedIn: 'root'
})
export class CityService {

  data: any;
  vendordetails: any;
  total: any;
  vendorId: any;

  constructor(private http: HttpClient) { }
  api = new Api()
  getCities(): Observable<any> {
    return this.http.get("https://indian-cities-api-nocbegfhqg.now.sh/cities");
  }

  filterData(serviceName, cityName): Observable<any> {
    this.data = this.http.get(this.api.baseUrl + "/filter/" + serviceName + "/" + cityName
    )
    this.vendordetails = this.data;
    console.log("in filterdata");
    console.log(this.data);
    console.log(this.vendordetails);
    return this.data;

  }

  getServices(): Observable<any> {
    return this.http.get(this.api.baseUrl + "/serviceDetails");
  }

  setVendorDetails(vendorDetails) {
    console.log(this.vendordetails);

  }
  getVendorDetails(): Observable<any> {

    // console.log("HIIII");

    console.log(this.vendordetails);

    return this.vendordetails;
  }
  getVendorOnId(id: number): any {
    return this.http.get(this.api.baseUrl + "/getvendor/" + id);
  }

  getTotalAmount(totalPrice) {
    this.total = totalPrice;
    return totalPrice;
  }

  setTotalAmount() {
    return this.total;
  }
  getVendorId(vendorId1) {
    this.vendorId = vendorId1;
    console.log(vendorId1);
    return vendorId1;
  }
  vid: any;
  setVendorId() {
    return this.vendorId;
  }

}
