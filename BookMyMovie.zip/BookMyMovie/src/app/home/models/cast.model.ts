export interface Cast {
    name: string;
    profile_path: string;
    character: string;
    id: string;
    credit_id: string;
}
