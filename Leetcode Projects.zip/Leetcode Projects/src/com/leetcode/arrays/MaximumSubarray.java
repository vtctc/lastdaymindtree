package com.leetcode.arrays;

import java.util.Scanner;

public class MaximumSubarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of nums");
		int size = sc.nextInt();
		int[] nums = new int[size];
		System.out.println("Enter nums");
		for (int i = 0; i < nums.length; i++) {
			nums[i] = sc.nextInt();
		}
		System.out.println(maxSubArray(nums));
	}

	public static int maxSubArray(int[] nums) {
		int currentSum=nums[0];
		int overallSum=nums[0];
		for (int i = 1; i < nums.length; i++) {
			if(currentSum>=0)
			{
				currentSum=currentSum+nums[i];
			}
			else
			{
				currentSum=nums[i];
			}
			if(currentSum>overallSum)
			{
				overallSum=currentSum;
			}
		}
		return overallSum;
	}

}
