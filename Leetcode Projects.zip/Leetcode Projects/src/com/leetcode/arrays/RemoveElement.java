package com.leetcode.arrays;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class RemoveElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of nums");
		int size = sc.nextInt();
		int[] nums = new int[size];
		System.out.println("Enter nums");
		for (int i = 0; i < nums.length; i++) {
			nums[i] = sc.nextInt();
		}
		System.out.println("Enter value");
		int val = sc.nextInt();
		System.out.println(removeElement(nums, val));
	}

	public static int removeElement(int[] nums, int val) {
		Integer[] what = Arrays.stream( nums ).boxed().toArray( Integer[]::new );
		List<Integer> integerList=Arrays.asList(what).stream().filter(i->i!=val).collect(Collectors.toList());
		int k=0;
		for (Integer i:integerList) {
			nums[k]=i;
			k++;
		}
		return integerList.size();
	}
}
