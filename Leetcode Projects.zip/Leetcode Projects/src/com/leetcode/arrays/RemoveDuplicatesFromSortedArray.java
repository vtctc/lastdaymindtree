package com.leetcode.arrays;

import java.util.Arrays;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class RemoveDuplicatesFromSortedArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of nums");
		int size = sc.nextInt();
		int[] nums = new int[size];
		System.out.println("Enter nums");
		for (int i = 0; i < nums.length; i++) {
			nums[i] = sc.nextInt();
		}
		System.out.println(removeDuplicates(nums));
	}

	public static int removeDuplicates(int[] nums) {
		Set<Integer> treeset=new TreeSet<>();
		for (int i = 0; i < nums.length; i++) {
			treeset.add(nums[i]);
		}
		int k=0;
		for (Integer i:treeset) {
			nums[k]=i;
			k++;
		}
		return treeset.size();
	}
}
