package com.leetcode.arrays;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Scanner;
import java.util.stream.IntStream;

public class SearchInsertPosition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of nums");
		int size = sc.nextInt();
		int[] nums = new int[size];
		System.out.println("Enter nums");
		for (int i = 0; i < nums.length; i++) {
			nums[i] = sc.nextInt();
		}
		System.out.println("Enter value");
		int target = sc.nextInt();
		System.out.println(searchInsert1(nums, target));
	}

	public static int searchInsert(int[] nums, int target) {
		Integer[] what = Arrays.stream( nums ).boxed().toArray( Integer[]::new );
		Optional<Integer> optional = Arrays.stream(what).filter(x -> x==target).findFirst();
		if(optional.isPresent())
		{
			Integer a=optional.get();
			return IntStream.range(0, what.length).filter(i -> a == what[i]).findFirst().getAsInt();
		}
		else
		{
			Integer optionalElement = Arrays.stream(what).filter(x -> x<target).sorted((o1,o2)->o2-o1).findFirst().get();
			return IntStream.range(0, what.length).filter(i -> optionalElement == what[i]).findFirst().getAsInt()+1;
		}
	}
	public static int searchInsert1(int[] nums, int target) {
		Integer[] what = Arrays.stream( nums ).boxed().toArray( Integer[]::new );
		try
		{
			Integer a=Arrays.stream(what).filter(x -> x==target).findFirst().get();
			return IntStream.range(0, what.length).filter(i -> a == what[i]).findFirst().getAsInt();
		}
		catch(Exception e)
		{
			java.util.Optional<Integer> optionalElement = Arrays.stream(what).filter(x -> x<target).sorted((o1,o2)->o2-o1).findFirst();
			if(optionalElement.isPresent())
			{
				return IntStream.range(0, what.length).filter(i -> optionalElement.get() == what[i]).findFirst().getAsInt()+1;
			}
			return 0;
		}
	}
}
