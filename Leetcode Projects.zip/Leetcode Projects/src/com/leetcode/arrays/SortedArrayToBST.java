package com.leetcode.arrays;

import java.util.Scanner;

public class SortedArrayToBST {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of m and n");
		int m = sc.nextInt();
		int[] nums = new int[m];
		System.out.println("Enter nums elements");
		for (int i = 0; i < m; i++) {
			nums[i] = sc.nextInt();
		}
		System.out.println(sortedArrayToBST(nums));
	}

	public static TreeNode sortedArrayToBST(int[] nums) {
		if (nums.length == 0) {
			return null;
		}
		return constructTreeFromSortedArray(nums, 0, nums.length-1);
	}

	public static TreeNode constructTreeFromSortedArray(int[] nums, int low, int high)
	{
		if(low>high)
		{
			return null;
		}
		int mid=(low+high)/2;
		TreeNode treenode=new TreeNode(nums[mid]);
		treenode.left=constructTreeFromSortedArray(nums, low, mid-1);
		treenode.right=constructTreeFromSortedArray(nums, mid+1, high);
		return treenode;
	}
}

class TreeNode {
	int val;
	TreeNode left;
	TreeNode right;

	TreeNode() {
	}

	TreeNode(int val) {
		this.val = val;
	}

	TreeNode(int val, TreeNode left, TreeNode right) {
		this.val = val;
		this.left = left;
		this.right = right;
	}

	@Override
	public String toString() {
		return "TreeNode [val=" + val + ", left=" + left + ", right=" + right + "]";
	}
}
