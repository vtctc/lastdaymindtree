package com.leetcode.arrays;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class PlusOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of digits");
		int size = sc.nextInt();
		int[] digits = new int[size];
		System.out.println("Enter digits");
		for (int i = 0; i < digits.length; i++) {
			digits[i] = sc.nextInt();
		}
		digits=plusOne(digits);
		for (int i = 0; i < digits.length; i++) {
			System.out.println(digits[i]);
		}
	}

	public static int[] plusOne(int[] digits) {
		Integer[] what = Arrays.stream(digits).boxed().toArray(Integer[]::new);
		List<Integer> list = Arrays.asList(what);
		BigInteger value=new BigInteger(list.stream().map(i -> Integer.toString(i)).reduce("", String::concat));
		value=value.add(BigInteger.ONE);
		return value.toString().chars().map(c -> c-'0').toArray();
	}

}
