package com.leetcode.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MergeSortedArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter size of m and n");
		int m = sc.nextInt();
		int n = sc.nextInt();
		int[] nums1 = new int[m + n];
		int[] nums2 = new int[n];
		System.out.println("Enter nums1 elements");
		for (int i = 0; i < m; i++) {
			nums1[i] = sc.nextInt();
		}
		if(n>0)
		{
			System.out.println("Enter nums2 elements");
			for (int i = 0; i < n; i++) {
				nums2[i] = sc.nextInt();
			}
		}
		merge(nums1, m, nums2, n);
	}

	public static void merge(int[] nums1, int m, int[] nums2, int n) {
		Integer[] what = Arrays.stream( nums1 ).boxed().toArray( Integer[]::new );
		Integer[] what1 = Arrays.stream( nums2 ).boxed().toArray( Integer[]::new );
		List<Integer> filteredList=Stream.of(what,what1).flatMap(Stream::of).filter(i->i!=0).sorted().collect(Collectors.toList());
		nums1 = filteredList.stream().mapToInt(i->i).toArray();
		for (int j = 0; j < nums1.length; j++) {
			nums1[j]=filteredList.get(j);
		}
		for (int j = 0; j < nums1.length; j++) {
			System.out.print(nums1[j]+" ");
		}
	}

}
