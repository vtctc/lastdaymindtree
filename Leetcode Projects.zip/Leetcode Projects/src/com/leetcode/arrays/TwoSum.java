package com.leetcode.arrays;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.IntStream;

public class TwoSum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter nums size");
		int size = sc.nextInt();
		int[] nums = new int[size];
		System.out.println("Enter nums elements");
		for (int i = 0; i < nums.length; i++) {
			nums[i]=sc.nextInt();
		}
		System.out.println("Enter target");
		int target = sc.nextInt();
		int[] result=twoSum(nums, target);
		for (int i = 0; i < result.length; i++) {
			System.out.println(result[i]);
		}
	}

	public static int[] twoSum(int[] nums, int target) {
		List<Integer> sumList = new ArrayList<>();
		int[] arr = new int[2];
		for (int i = 0; i < nums.length; i++) {
			int a = target - nums[i];
			if (sumList.contains(a)) {
				arr[0] = i;
				arr[1] = a;
			} else {
				sumList.add(nums[i]);
			}
		}
		arr[1] = IntStream.range(0, nums.length).filter(i -> arr[1] == nums[i]).findFirst().orElse(-1);
		Arrays.sort(arr);
		return arr;
	}
}
