package com.leetcode.arrays;

import java.util.Scanner;

public class ConsecutiveCharacters {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string");
		String str = sc.next();
		System.out.println(maxPower(str));
	}

	public static int maxPower(String s) {
		int max = 1;
		int temp = 1;
		for (int i = 1; i < s.length(); i++) {
			if (s.charAt(i) == s.charAt(i - 1)) {
				temp++;
				max=(int) Math.max(temp, max);
			} else {
				temp = 1;
			}
		}
		return max;
	}
}
