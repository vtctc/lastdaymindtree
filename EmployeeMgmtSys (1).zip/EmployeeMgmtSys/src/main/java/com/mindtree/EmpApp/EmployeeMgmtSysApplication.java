package com.mindtree.EmpApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeMgmtSysApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeMgmtSysApplication.class, args);
	}

}
