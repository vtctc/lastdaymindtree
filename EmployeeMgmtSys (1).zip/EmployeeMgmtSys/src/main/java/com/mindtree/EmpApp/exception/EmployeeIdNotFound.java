package com.mindtree.EmpApp.exception;

public class EmployeeIdNotFound extends ServiceException {


	public EmployeeIdNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
