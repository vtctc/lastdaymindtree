package com.mindtree.EmpApp.exception;

public class ServiceException extends Exception {


	public ServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
