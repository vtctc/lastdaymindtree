#include<iostream>
#include<string>
using namespace std;
int main()
{ string s,scount=0,scount2=0,scount3=0;
int i;
  cout<<" enter the string in a array";
  getline(cin,s);
  for(i=0;i<s.length();i++)
   {
   	 if(s[i]>='A' || s[i]<='Z')
   	  { 
   	    
      }
      for(i=0;i<s.length();i++)
      cout<<" upper case:"<<
  }
  for(i=0;i<s.lenght();i++)
  {  if( s[i]>='a' || s[i]<='z')\
	   { 
	    
	   }
	   for( i=0;i<s.length();i++)
   	     cout<<" lower case: "<<

   }
   for(i=0;i<s.length();i++)
   {
   	 if(s[i]>='A' || s[i]<='Z'&& s[i]>='a'&& s[i]>='z')
   	   {
   	   	 
		}
		for(i=0;i<s.length();i++)
		 cout<<" Mixed: "<<
	}
	return 0;
}
