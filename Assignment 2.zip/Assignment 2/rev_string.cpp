#include<bits/stdc++.h>
using namespace std;
void rev(string s)
{
	int i=0;
	string s1="";
	for(i=0;i<s.length();i++)
	{
	   if(s[i]!=' ')
		s1+=s[i];
		else
		{
			reverse(s1.begin(),s1.end());
			cout<<s<<" ";
			s1="";
			
		}
	}
	cout<< s1 <<" ";
}
int main()
{
	string s2=" a cup of tea";
	rev(s2);
	return 0;
}

