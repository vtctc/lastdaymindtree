#include<iostream>
using namespace std;
int main()
{
	int a[10][10],b[10][10],i,j,n,ch,k=0,c[10],flag=0,t,n1,d[10],s=0;
	cout<<" enter the size of element:"<<endl;
	cin>>n;
	cout<<"first array:";
	for(i=0;i<n;i++)
	  {
	  	for(j=0;j<n;j++)
	  	{
	  		cin>>a[i][j];
		  }
	  }
	  cout<<"second array:";
     for(i=0;i<n;i++)
	  {
	  	for(j=0;j<n;j++)
	  	{
	  		cin>>b[i][j];
		  }
	  }
	  do{ 
	      cout<<" **menu drive**"<<endl;
	      cout<<" 1.duplicate elements"<<endl;
	      cout<<" 2.sort left diagonal"<<endl;
	      cout<<" 3.store 2d and found"<<endl;
	      cout<<"4. exit"<<endl;
	      cout<<" enter your choice"<<endl;
	      cin>>ch;
	      switch(ch)
	      {
	      	case 1: 
	      	          for(i=0;i<n;i++)
	                      {
	  	                      for(j=i+1;j<n;j++)
	  	                      {
	  		                        if(a[i][j]==b[i][j])
	  		                        {
									  k++;
								    }    
		                      }
	      		          }
	                 for(k=0;k<n;k++)
	                 cout<<c[k]<<" ";
	                 break;
	             
	  	    case 2: for(i=0;i<n;i++)
	  	              {
	  	              	for(j=i;j<(n-i)-1;j++)
	  	              	{
	  	              		if(a[i][i]>a[i+1][i+1])
	  	              		{
	  	              			t=a[i][i];
	  	              			a[i][i]=a[i+1][i+1];
	  	              			a[i+1][i+1]=t;
								}
						}
					  }
					  for(i=0;i<n;i++)
	  	              {
	  	              	for(j=i;j<n;j++)
	  	              	{
	  	              		cout<<a[i][j]<<" ";
							}
						}
						
						for(i=0;i<n;i++)
	  	              {
	  	              	for(j=i;j<(n-i)-1;j++)
	  	              	{
	  	              		if(b[i][i]>b[i+1][i+1])
	  	              		{
	  	              			t=a[i][i];
	  	              			b[i][i]=b[i+1][i+1];
	  	              			b[i+1][i+1]=t;
								}
						}
					  }
					  for(i=0;i<n;i++)
	  	              {
	  	              	for(j=i;j<n;j++)
	  	              	{
	  	              		cout<<b[i][j]<<" ";
							}
						}
						break;
				
				case 3: for(i=0;i<n;i++)
							 d[s]=b[i][j];       
                        {  
                            int f,l,mid,i;
                            f=0;
                            l=n-1;
                           mid=(f+l)/2;
                           while(f<=l)
                         {  
                            if(d[mid]==n1)
 	                        {
	                          cout<<"element is"<<mid;
	                        }
	                           else if(d[mid]<n1)
	                        {
	 	                      f=mid+1;
	                        }
	                         else
	                       {
	                        	l=mid-1;
	                          }
	                          mid=(f+l)/2;
                            }
                           cout<<" not found";

                    }
                    break;
                    case 4:
                    	exit(0);
                    	break;
                  }
				
				}while(ch!=4);
            
            return 0;
			}
					
						
	  	    	
	  	
	  	
	
	  

