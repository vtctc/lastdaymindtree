#include<iostream>
using namespace std;
int main()
{int n,a[20][20],i,j,sum[20]={0};
cout<<"enter the size";
cin>>n;
cout<<"enter array:\n";
for(i=0;i<n;i++)
        {for(j=0;j<n;j++)
            {   cin>>a[i][j];
            }
        }
          for(i=0;i<n;i++)
          
            { for(j=0;j<n;j++)
             
                {
				 sum[i]=sum[i]+a[i][j];
			    }
	         } 
	         int ifRowMagic=0;
	         for(i=0;i<n;i++)
	            {
	            	cout<<i<<"th  ith row sum is"<<sum[i]<<"\n";
				 for(j=0;j<n;j++)
	                {  if(sum[i]!=sum[j])
	                     	  ifRowMagic=1;            
			     	
				    }
				}
				if(ifRowMagic==1)
				{
					cout<<"Not A Row Magic";
				}
				else
				{
					cout<<"A Row Magic";
				}
return 0;
}


 
