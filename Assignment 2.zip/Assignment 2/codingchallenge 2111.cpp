#include<iostream>
using namespace std;
int main()
{ int i,j,k;
for(i=1;i<=4;i++)
   for(k=3;k>=i;k--)
    {
    	cout<<" ";
    	
	}
	for( j=1;j<=i;j++)
	{
		cout<<j<<" ";
		
	}
	cout<<" ";
	return 0;
}
