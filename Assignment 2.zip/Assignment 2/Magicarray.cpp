#include<iostream>
using namespace std;
 bool Magic_array(int a[20][20],int);
int main()
{int n,a[20][20],i,j;
cout<<"enter the size";
cin>>n;
cout<<"enter  array:\n";
for(i=0;i<n;i++)
        {for(j=0;j<n;j++)
            {   cin>>a[i][j];
            }
        }
       if( Magic_array(a,n))
       cout<<" magic square";
       else
       cout<<" not square";
return 0;
}
bool Magic_array(int a[20][20],int n1)
{
  int rowsum[20]={0},column[20]={0},diagonal1[20]={0},diagonal2[20]={0},i,j;
	
	for(i=0;i<n1;i++)
	    { for(j=0;j<n1;j++)
	         {rowsum[i]=rowsum[i]+a[i][j];
	          column[i]=column[i]+a[j][i];
	          diagonal1[i]=diagonal1[i]+a[i][i];
	          diagonal2[i]=diagonal2[i]+a[i][n1-i-1];
			 }
	    }
		for(i=0;i<n1;i++)
		   { for(j=0;j<n1;j++)
		     if(rowsum[i]!=diagonal1[j])
		     return false;
		     else if(column[i]!=diagonal2[j])
		     return false;
		     else if(diagonal1[i]!=diagonal2[j])
		     return false;
			 else
		     return true;
		   }
}
