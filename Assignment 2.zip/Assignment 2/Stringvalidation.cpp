#include<iostream>
#include<string>
using namespace std;
int main()
  {  string s;
   int l;
     cout<<" enter the USN which must be 10 length character: ";
	   getline(cin,s);
	   l=s.length();
	if(l==10)
	   {if((s[0]=='1')||(s[0]=='2')) 
	      {  if( (s[1]>=65&& s[1]<=90)&&(s[2]>=65&&s[2]<=90))
	          {  if( (s[3]>=48&& s[3]<=57)&&(s[4]>=48&&s[4]<=57))
	              {  if((s[5]>=65&&s[5]<=90)&&(s[6]>=65&&s[6]<=90))
	                       {  if((s[7]>=48&&s[7]<=57)&&(s[8]>=48&&s[8]<=57))
	                          {  if((s[9]>=48&& s[9]<=57))
	                                 cout<<" success ";
	                          }
	                       }
	                  }
	             }
	          }
	     } 
     
    else
    cout<<" failure";
  return 0;
}
