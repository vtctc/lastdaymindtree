#include<iostream>
using namespace std;
int main()
{int n,a[20][20],b[20][20],c[20][20],i,j,k;
cout<<"enter the size";
cin>>n;
cout<<"enter first array:\n";
for(i=0;i<n;i++)
{for(j=0;j<n;j++)
{cin>>a[i][j];
}
}
cout<<"enter second array:\n";
for(i=0;i<n;i++)
{for(j=0;j<n;j++)
{cin>>b[i][j];
}
}
for(i=0;i<n;i++)
{for(j=0;j<n;j++)
{c[i][j]=a[i][j]+b[i][j];
}
}
cout<<" sum of matrix \n";
for(i=0;i<n;i++)
{ for(j=0;j<n;j++)
  { cout<<c[i][j]<<" ";
}
cout<<endl;
}
return 0;
}
