#include<iostream>
using namespace std;

int main()
{ int a[10],n;

int newArr[10];
int flag = 0,k=0,i,j;
cout<<" enter the size: ";
cin>>n;
cout<<"enter the array: ";
for(i=0;i<n;i++)
{cin>>a[i];
}
for(i=0;i<n;i++)
{

	flag=0;
    for(j=i+1;j<n;j++)
    {
       if(a[i]<a[j])
       {
       	flag = 1;
       	break;	
	   }
       
    }
      if(flag==0)
   {
	  newArr[k] = a[i];
	k++;
   }
}
      for(i=0;i<k;i++)
      cout<<newArr[i]<<" ";

return 0;
}

