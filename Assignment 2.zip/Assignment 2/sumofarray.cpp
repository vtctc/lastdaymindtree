#include<iostream>
using namespace std;
int main()
{int a[20],i,n,sum=0;
cout<<"enter the size of array";
cin>>n;
for(i=0;i<n;i++)
{
cin>>a[i];
}
for(i=0;i<n;i++)
{sum=sum+a[i];
}
cout<<"sum="<<sum;
return 0;
}
