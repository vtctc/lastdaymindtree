#include<iostream>
using namespace std;

int main()
{
	int a[10][10],b[10][10],i,j,n,ch,k=0,c[10];
	cout<<" enter the size of element:"<<endl;
	cin>>n;
	cout<<"first array:";
	for(i=0;i<n;i++)
	  {
	  	for(j=0;j<n;j++)
	  	{
	  		cin>>a[i][j];
		  }
	  }
	  cout<<"second array:";
        for(i=0;i<n;i++)
	  {
	  	for(j=0;j<n;j++)
	  	{
	  		cin>>b[i][j];
		  }
	  }
	  for(i=0;i<n;i++)
	        {
	  	        for(j=0;j<n;j++)
	  	      {
	  		      if(a[i][j]==b[i][j])
	  		        {
					c[k]=a[i][j];
					k++;
					 }
		       } 
		    }
	      	     
			for(i=0;i<k;i++)
	          cout<<c[i]<<" ";
	          return 0;
	}
	         
