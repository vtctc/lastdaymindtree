#include<iostream>
#include<string>
using namespace std;
int main()
{
 string name;
 getline(cin,name);
 int age;
 cin>>age;
 cout<<name[0];
 string ch;
 for(int i=0;i<name.length();i++)
  if(name.at(i)==' ')
  {
  	ch=ch+name[i+1];
  }
  string s=to_string(age);
  string password=name[0]+ch+s;
  cout<<password;
}	
	
