#include<iostream>
using namespace std;
int main()
{ int a1[20],a2[20],i,j,k[20],n;
int uniqueElement[20];
cout<<" enter the size of array: ";
cin>>n;
    cout<<" enter the 1st array: ";
       for(i=0;i<n;i++)
          {cin>>a1[i];
		  }
        cout<<" enter the 2nd array ";
        for(i=0;j<n;i++)
           {
			cin>>a2[i];
           } 
		
		for(i=0;i<n;i++)
		{ for(j=0;j<n;j++)
		         if(a[i]==a[j]     
		 }
		    
	return 0;
}  
		
