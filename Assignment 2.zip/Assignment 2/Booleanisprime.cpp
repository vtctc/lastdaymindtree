#include<iostream>
using namespace std;
bool isPrime(int n)
{ bool b=true;
  for(int i=2;i<n;i++)
  {if(n%2==0)
   b=false;
   break;
  }
  return b;
}
int main()
{int n1;
bool b;
cout<<"enter the number:";
cin>>n1;
b=isPrime(n1);
if(b==true)
{cout<<" True ";
}
else
{cout<<" False ";
}
return 0;
}
