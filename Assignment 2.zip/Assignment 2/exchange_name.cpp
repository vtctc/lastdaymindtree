#include<iostream>
using namespace std;
s(string s3, string s4)
{
	int i=0,j=0,index1=0,index2=0;
	string s1=" ",s2=" ";
	while(s3[i]!=' ')
	{
		index1++;
		i++;
	}
	while( s4[j]!=' ')
	{
		index2++;
		j++;
	}
	for(i=0;i<index1;i++)
	{
		s1=s1+s3[i];
	}
	for(i=0;i<index2;i++)
	{
		s2=s2+s4[i];
	}
	for(i=index1;s3[i]!='\0';i++)
	{
		s2=s2+s3[i];
	}
	for(i=index2;s4[i]!='\0';i++)
	{
		s1=s1+s4[i];
	}
	cout<<"\n"<<s1<<"\n";
	cout<<s2;
}
int main()
{
	string s1,s2;
	cout<<" enter two names "<<endl;
	getline(cin,s1);
	getline(cin,s2);
	s(s1,s2);
	return 0;
}
