#include<iostream>
using namespace std;
int main()
{int n,rev,n1;
cout<<" enter the number\n";
cin>>n;
while(n!=0)
{n1=n%10;
rev=(rev*10)+n1;
n=n/10;
}
cout<<" reverse no: "<<rev;

}
