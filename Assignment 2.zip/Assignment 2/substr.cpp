#include<iostream>
#include<string>
using namespace std;
int main()
{string s1("hello world");
string  s2("world is big ");
cout<<s1.substr(6,10)<<" "<<s2.substr(9,11);
return 0;
}
