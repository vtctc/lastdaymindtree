#include<iostream>
using namespace std;

int main()
{ 
       int a[20][20],b[20][20],i,j,n, c[20],count=0;
	cout<<" enter the size of array:";
	cin>>n;
	cout<<" enter 1st array:";
	for(i=0;i<n;i++)
	 {
	 for(j=0;j<n;j++)
	      {
	      	cin>>a[i][j];
	      }
       }  
       cout<<"enter 2nd array:";
	   for(i=0;i<n;i++)
	      {
		      for(j=0;j<n;j++)
	         {
	   	           cin>>b[i][j];
	          }
	      }
		
        	
              for(i=0;i<n;i++)
              {
              	for(j=0;j<n;j++)
              	{
              		c[count++]=a[i][j]*b[i][j];
				  }
			  }
        for(i=0;i<n+n;i++)
          cout<<c[i]<<" ";
          return 0;
      }
