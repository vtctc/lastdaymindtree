#include<iostream>
using namespace std;
bool Magic_array(int a[20][20],int n)
 { int i,j,s1=0,s2=0;
     for(i=0;i<n;i++)
	   { s1=s1+a[i][i];
	   }
	   for(i=0;i<n;i++)
	   { s2=s2+a[i][n-i-1];
	   } 
	   if(s1!=s2)
	   return false;
	       for(i=0;i<n;i++)
	         {  int rsum=0; 
			    for(j=0;j<n;j++)
	               { 
				     rsum=rsum+a[i][j]; 
					}
					if(rsum!=s1)
			        return false;
			 }
             for(i=0;i<n;i++)
             { int csum=0;
                 for(j=0;j<n;j++)
                 { csum=csum+a[j][i];
				 }
			 
			 if(s1!=csum)
			 return false;
             }
             return true;
}
int main()
{int a[20][20],n;
cout<<" enter array size";
cin>>n;
cout<<"enter array element:"<<endl;
for(int i=0;i<n;i++)
  {
      for(int j=0;j<n;j++)
       {   cin>>a[i][j];
	   }
  }
  if(Magic_array(a,n))
  cout<<" magic array";
  else
  cout<<" not magic ";
  return 0;
}

