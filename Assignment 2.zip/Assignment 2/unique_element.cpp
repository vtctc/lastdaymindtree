#include<iostream>
using namespace std;
int uniqElements(int arr1[],int arr2[],int n1,int n2) 
{ int x,y;
for(x=0;x<n1;x++)
{
int dot=0;
	for(y=0;y<n2;y++)
	{   if(arr1[x]==arr2[y])
		{dot=1;}	
	}
	if(dot==0)
	cout<<" "<<arr1[x];}
for(y=0;y<n2;y++)
{int dot=0;
	for(x=0;x<n1;x++)
	{		if(arr1[x]==arr2[y])
		{		dot=1;}
	}
	if(dot==0)
	cout<<" "<<arr2[y];
}
}
int main() 
{ 
int *p;
    int arr1[] = {10,5,20,15,25,30}; 
    int arr2[] = {50,12,5,30,15,70}; 
    int n1 = sizeof(arr1) / sizeof(arr1[0]); 
    int n2 = sizeof(arr2) / sizeof(arr2[0]); 
    uniqElements(arr1, arr2, n1, n2); 
    return 0; 
} 
