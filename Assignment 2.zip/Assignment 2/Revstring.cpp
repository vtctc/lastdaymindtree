 #include<iostream>
 using namespace std;
 int main()
 {char b[50],ch;
int i,l;
  cout<<"enter character";
   cin.getline(b,20);
       for(l=0;b[l]!='\0';l++);
          for(i=0;i<l/2;i++)
        {
           ch=b[i];
           b[i]=b[l-1-i];
           b[l-1-i]=ch;
        }
           cout<<b;
           return 0;
}
