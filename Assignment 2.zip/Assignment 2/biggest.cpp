#include<iostream>
using namespace std;
int GetMax(int,int,int);
int GetMax(int a,int b,int c)
{ if(a>b&&a>b)
  return a;
  else if(b>c)
  return b;
  else
  return c;
}
int main()
{ int x,y,z,s;
  cout<<"enter the value of a,b and c";
  cin>>x>>y>>z;
  s=GetMax(x,y,z);
  cout<<"biggest number is:"<<s;
  return 0;
}
