#include<iostream>
using namespace std;
int main()
{ int a[100],n=10,c1=0,c2=0,c3=0,c4=0,c5=0,i;
cout<<" enter the marks of student: "<<endl;
  for(i=0;i<n;i++)
    { cin>>a[i];
	}
	 for(i=0;i<n;i++)
	 { if(a[i]>=0 && a[i]<5)
	    c1++;
	        if(a[i]>=5 && a[i]<10)
	        c2++;
	            if(a[i]>=10 && a[i]<15)
	            c3++;
	                 if(a[i]>=15 && a[i]<20)
	                 c4++;
	                    if(a[i]>=20 && a[i]<=25)
	                    c5++;
	 }
	 cout<<" number of student who scored between 0 to 4 is"<<c1<<endl;
	 cout<< "number of student who scored between 5  to 9 is"<<c2<<endl;
    cout<<" number of student who scored between 10 to 14 is"<<c3<<endl;
     cout<<" number of student who scored between 15 to 20 is"<<c4<<endl;
	 cout<<"number of student who scored between 20 to 25 is"<<c5<<endl;
return 0;	 
}
