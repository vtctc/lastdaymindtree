#include<iostream>
#include<string>
using namespace std;
void compression(string );
int main()
     { string s1;
       cout<<" enter the string :\n";
        getline(cin,s1);
        compression(s1);
        return 0;
}
void compression(string s2)
{int n,i;
 n=s2.length();
 for(i=0;i<n;i++)
{int count=1;
  while(i<n-1 && s2[i]==s2[i+1])
 {
 count ++;include<iostream>
using namespace std;
int uniqElements(int arr1[],int arr2[],int n1,int n2) 
{ int x,y;
for(x=0;x<n1;x++)
{
int dot=0;
	for(y=0;y<n2;y++)
	{   if(arr1[x]==arr2[y])
		{dot=1;}	
	}
	if(dot==0)
	cout<<" "<<arr1[x];}
for(y=0;y<n2;y++)
{int dot=0;
	for(x=0;x<n1;x++)
	{		if(arr1[x]==arr2[y])
		{		dot=1;}
	}
	if(dot==0)
	cout<<" "<<arr2[y];
}
}
int main() 
{ 
int *p;
    int arr1[] = {10,5,20,15,25,30}; 
    int arr2[] = {50,12,5,30,15,70}; 
    int n1 = sizeof(arr1) / sizeof(arr1[0]); 
    int n2 = sizeof(arr2) / sizeof(arr2[0]); 
    uniqElements(arr1, arr2, n1, n2); 
    return 0; 
} 
 i++;
 }
 cout<<s2[i]<<count;
 }
}
