#include<iostream>
using namespace std;
void sumarray(int a[20][20],int b[20][20],int n);
int main()
{
 int a[20][20],b[20][20],sum=0;
  int i,j,n;
   cout<<" enter the size of array: ";
   cin>>n;
    cout<<" enter 1st array:\n ";
      for(i=0;i<n;i++)
	     { for(j=0;j<n;j++)
	        { cin>>a[i][j];
			}
	    }
        cout<<" enter 2nd array:\n ";
	   for(i=0;i<n;i++)
	     { for(j=0;j<n;j++)
	        { cin>>b[i][j];	
		    }
		}
		sumarray(a,b,n);
		return 0;
}
void sumarray(int a[20][20],int b[20][20],int n)
{int  c[20][20],i,j,sum=0;
 for(i=0;i<n;i++)
 { for(j=0;j<n;j++) 
    {
    	c[i][j]=a[i][j]+b[i][j];
    	
	}
	for(i=0;i<n;i++)
     { for(j=0;j<n;j++)
        {
        	 cout<<c[i][j]<<" ";
        	 if( j==n-1)
        	 cout<<"\n";
		}
     }
}
}
