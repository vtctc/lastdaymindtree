#include<iostream>
using namespace std;
int main()
{double a1[20],a2[20];
int i,j,a3[20],k,n1,n2,n3;
cout<<" enter the size of 1st array: ";
cin>>n1;
cout<<"enter the 1st array \n";
for(i=0;i<n1;i++)
{cin>>a1[i];
}
cout<<"enter the size of 2nd array: ";
cin>>n2;
cout<<" enter the 2nd array \n";
for(j=0;j<n2;j++)
{cin>>a2[j];
}
for(k=0;k<n2;k++)
 {
	 a3[k]=a1[k]+a2[k];    
}
for(k=0;k<n2;k++)
cout<<" sum array is:"<<a3[k]<<endl;
return 0;
}
