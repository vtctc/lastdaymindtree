#include<iostream>
#include<string>
using namespace std;
int main()
{ string s; 
  int n,n1;
  cout<<" enter wether CM/MR: ";
  getline(cin,s);
  cout<<"enter floor(0/1/2): ";
  cin>>n;
  cout<<" enter room number: ";
  cin>>n1;
  cout<<"The generated meeting room number is:"<<"MTK-"<<s<<"-"<<"LC1-"<<n<<"F-"<<n1;
 return 0;
}

