#include<iostream>
using namespace std;
void intials(const string& );
int main()
{char b[20];

cout<<" enter the name:  ";
cin.getline(b,20);
intials(b);

return 0;
}
void intials(const string& b1)
{ if(b1.length()==0)
    return ;
    cout<<b1[0];
    for(int i=1;i<b1.length()-1;i++)
    if(b1[i] == ' ')
    cout<<" "<<b1[i+1]; 
}
