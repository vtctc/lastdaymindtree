import { BrowserModule } from '@angular/platform-browser'
import { NgModule } from '@angular/core'
import {
  SocialLoginModule,
  SocialAuthServiceConfig,
} from 'angularx-social-login'
import { GoogleLoginProvider } from 'angularx-social-login'

import { CommonModule }  from '@angular/common';
import { Routes, RouterModule }  from '@angular/router';
import { AppRoutingModule } from './app-routing.module'
import { AppComponent } from './app.component'
import { MaterialModule } from './Material/material.module'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule} from '@angular/material/button';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { FilterPipe } from './Admin/passenger-data/FilterPipe';
import { FlightBookingComponent } from './flight-booking/flight-booking.component'
import { FormsModule } from '@angular/forms'
import { ReactiveFormsModule } from '@angular/forms';
import { SocialLoginComponent } from './social-login/social-login.component'
import { SeatMappingComponent } from './seat-mapping/seat-mapping.component'
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'
import { PassengerDetailsComponent } from './passenger-details/passenger-details.component'
import { environment } from '../environments/environment'
import { EffectsModule } from '@ngrx/effects'
import { StoreModule} from '@ngrx/store';
import { FlighReducer} from './store/reducers/flights.reducer';
import {PassengerReducer} from './store/reducers/passengers.reducer'
import { FlightsEffects} from './store/effects/flights.effects'
import { PassengersEffects} from './store/effects/passengers.effects'
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { StoreRouterConnectingModule } from '@ngrx/router-store';
import { StaffComponent } from './staff/staff.component';
import { CheckInPageComponent } from './check-in-page/check-in-page.component';
import { AdminLoginComponent } from './Admin/admin-login/admin-login.component';
import { PassengerAdminComponent } from './Admin/passenger-admin/passenger-admin.component';
import { FlightDetailsComponent } from './Admin/flight-details/flight-details.component';
import { PassengerAddComponent } from './Admin/passenger-add/passenger-add.component';
import { PassengerDataComponent } from './Admin/passenger-data/passenger-data.component';
import { PassengerDataUpadateComponent } from './Admin/passenger-data-upadate/passenger-data-upadate.component';
import { FlightAddUpdateComponent } from './Admin/flight-add-update/flight-add-update.component';
import { DashboardComponent } from './Admin/dashboard/dashboard.component';
import { HeaderComponent } from './header/header.component';
import { AlertComponent } from './alert/alert.component';


@NgModule({
  declarations: [
    AppComponent,
    FilterPipe,
    FlightBookingComponent,
    SocialLoginComponent,
    SeatMappingComponent,
    PassengerDetailsComponent,
    StaffComponent,
    CheckInPageComponent,
    AdminLoginComponent,
    PassengerAdminComponent,
    FlightDetailsComponent,
    PassengerAddComponent,
    PassengerDataComponent,
    PassengerDataUpadateComponent,
    FlightAddUpdateComponent,
    DashboardComponent,
    HeaderComponent,
    AlertComponent,
    
   

  ],
  imports: [
    BrowserModule,
    CommonModule,
    RouterModule ,
    MatButtonModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    SocialLoginModule,
    MaterialModule,
    BrowserAnimationsModule,
    HttpClientModule,
    StoreModule.forRoot({}),
    StoreModule.forFeature('flights', FlighReducer),
    StoreModule.forFeature('passengers', PassengerReducer),
    EffectsModule.forRoot([FlightsEffects, PassengersEffects]),
    StoreRouterConnectingModule.forRoot(),
    
  ],
  providers: [
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: false,
        providers: [
          {
            id: GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider(
              '768886577002-5tibearbqba1811fp2dm6h04sos72lk7.apps.googleusercontent.com',
            ),
          },
        ],
      } as SocialAuthServiceConfig,
    },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
