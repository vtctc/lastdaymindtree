import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FlightBookingComponent } from './flight-booking/flight-booking.component';
import { SocialLoginComponent } from './social-login/social-login.component';
import { SeatMappingComponent } from './seat-mapping/seat-mapping.component';
import { PassengerDetailsComponent } from './passenger-details/passenger-details.component';
import { StaffComponent } from './staff/staff.component';
import { CheckInPageComponent } from './check-in-page/check-in-page.component';
import { AdminLoginComponent } from './Admin/admin-login/admin-login.component';
import { PassengerAdminComponent} from './Admin/passenger-admin/passenger-admin.component'
import{ DashboardComponent} from './Admin/dashboard/dashboard.component'
import { FlightDetailsComponent} from './Admin/flight-details/flight-details.component'
import{PassengerAddComponent} from './Admin/passenger-add/passenger-add.component'
import { PassengerDataComponent} from './Admin/passenger-data/passenger-data.component'
import {PassengerDataUpadateComponent} from './Admin/passenger-data-upadate/passenger-data-upadate.component'
import { FlightAddUpdateComponent} from './Admin/flight-add-update/flight-add-update.component'
const routes: Routes = [
  { 
    path: 'social', component: SocialLoginComponent
  },
  {
    path: 'staff' , component:StaffComponent
  },
  {
    path:'Admin/admin-login', component:AdminLoginComponent
  },
  {
    path:'dashboard', component:DashboardComponent
  },
  {
    path: 'FlightDetails', component:FlightDetailsComponent
  },
  {
    path:'passengerAdmin', component: PassengerAdminComponent
  },
  {
    path:'PassengerdataUpadate/:id',component:PassengerDataUpadateComponent
  },
  {
    path:'passengeradd/:flightId', component:PassengerAddComponent
  },
  {
  path:'passengerdata', component:PassengerDataComponent
  },
  {
    path:'flightbooking', component:FlightBookingComponent
  },
  {
    path:'passengerDetals/:flightId', component:PassengerDetailsComponent
  },
  {
    path:'seat/:pid', component:SeatMappingComponent
  },
  {
    path: 'check/:pid', component:CheckInPageComponent
  },
  {
   path:'flightadd/:flightId', component:FlightAddUpdateComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
