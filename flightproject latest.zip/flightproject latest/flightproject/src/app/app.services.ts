import { Injectable } from '@angular/core'
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { Observable, of } from 'rxjs'
import { catchError, tap } from 'rxjs/operators'
import { Flights } from './models/flights.model'
import { Passengers } from './models/passengers.model'

const httpOptions = {
    headers: new HttpHeaders({ 'content-Type': 'application/json' })
};

@Injectable({
    providedIn: 'root',
})
export class FlightsServices {
    private flight_url = 'http://localhost:5000/flights';
    private passenger_url = 'http://localhost:5000/passenger';
    constructor(private http: HttpClient) {}

    httpOptions = {
        headers: new HttpHeaders({ 'content-Type': 'application/json' }),
    };

    getFlights(): Observable < any > {
        return this.http.get < Flights[] > (this.flight_url).pipe(
            tap((flights) => {
                return flights;
            }),
            // catchError(this.handleError('getFlights', []))
        );
    }
    getByFlightId(id: any): any {

        return this.http.get('http://localhost:5000/passenger/?flightId=' + id);
    }

    getByFlightAdd(id: any): any {
        return this.http.get('http://localhost:5000/flights/?flightId=' + id);
    }

    getByPassengerId(id: any): any {

        return this.http.get('http://localhost:5000/passenger/?pid=' + id);
    }


    getByNormalID(id: any): any {
        return this.http.get('http://localhost:5000/passenger/?id=' + id);
    }

    getPassengers(): Observable < any > {
        return this.http.get < any > (this.passenger_url).pipe(
            tap((passengers) => {
                return passengers;
            }),
            //catchError(this.handleError('getPassengers', []))
        );
    }

    ediPassengers(passenger: Passengers): Observable < Passengers > {
        return this.http.put < any > (`${this.passenger_url}/${passenger.pid}`, passenger).pipe(
            tap((passengers) => {
                console.log('SEAT DONE', passenger);

            })
        );
    }

    createPassengers(payload: Passengers): Observable < Passengers > {
        return this.http.post < any > (this.passenger_url, payload);
    }

    updatePassengers(passengers: Passengers): Observable < Passengers > {
        return this.http.put < any > (
            `${this.passenger_url}/${passengers.id}`,
            passengers
        );

    }

      updateFlights(flights: Flights): Observable<Flights> {
        return this.http.put<any>(
          `${this.flight_url}/${flights.id}`,
          flights
        );
      }

    // updateFlights(flight: Flights) {
    //     return this.http.put("http://localhost:5000/flights/" + flight.id, flight.id);

    // }
}