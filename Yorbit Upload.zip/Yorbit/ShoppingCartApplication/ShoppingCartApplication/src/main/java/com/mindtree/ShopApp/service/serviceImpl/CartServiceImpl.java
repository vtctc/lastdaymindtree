package com.mindtree.ShopApp.service.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.ShopApp.common.PriceProduct;
import com.mindtree.ShopApp.exception.ProductNotFoundException;
import com.mindtree.ShopApp.exception.QuantityShouldNotNegative;
import com.mindtree.ShopApp.exception.UserIdNotFound;
import com.mindtree.ShopApp.model.Cart;
import com.mindtree.ShopApp.model.Product;
import com.mindtree.ShopApp.model.User;
import com.mindtree.ShopApp.modelDto.ProductDto;
import com.mindtree.ShopApp.repository.CartRepository;
import com.mindtree.ShopApp.repository.ProductRepository;
import com.mindtree.ShopApp.repository.UserRepository;
import com.mindtree.ShopApp.service.CartService;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	CartRepository cartRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	ProductRepository productRepository;
	private ModelMapper modelMapper = new ModelMapper();

	@Override
	public String addProductToCart(int userId, ProductDto productdto) throws UserIdNotFound {
		Product product = convertDtoToEntity(productdto);
		User user = userRepository.findById(userId).orElseThrow(() -> new UserIdNotFound("User not found"));
		Cart cart = user.getUserCart();
		int count = 0;
		for (int i = 0; i < cart.getCartProducts().size(); i++) {
			if (product.getProductName().equals(cart.getCartProducts().get(i).getProductName())) {
				count = 1;
				cart.getCartProducts().get(i)
						.setProductquantity(cart.getCartProducts().get(i).getProductquantity() + 1);
			}
		}
		if (count == 0) {
			product.setProductquantity(1);
			cart.getCartProducts().add(product);
		}
		product.setProductCart(cart);
		cartRepository.saveAndFlush(cart);
		return "saved successfully";
	}

	public Product convertDtoToEntity(ProductDto productdto) {

		return modelMapper.map(productdto, Product.class);
	}

	public ProductDto convertEntityToDto(Product product) {

		return modelMapper.map(product, ProductDto.class);
	}

	@Override
	public PriceProduct getUserTotalAmount(int userId) throws UserIdNotFound {
		PriceProduct priceproduct = new PriceProduct();
		User user = userRepository.findById(userId).orElseThrow(() -> new UserIdNotFound("User not found"));
		Cart cart = user.getUserCart();
		double total = 0;
		for (Product product : cart.getCartProducts()) {
			total += product.getProductPrice() * product.getProductquantity();
		}
		priceproduct.setPrice(total);
		priceproduct.setProductDto(
				cart.getCartProducts().stream().map(i -> convertEntityToDto(i)).collect(Collectors.toList()));
		return priceproduct;
	}

	@Override
	public String updateTheQuantity(int userId, int quantity, int productId)
			throws UserIdNotFound, QuantityShouldNotNegative, ProductNotFoundException {
		if (quantity < 0) {
			throw new QuantityShouldNotNegative("product quantity cant be set as negative");
		}
		User user = userRepository.findById(userId).orElseThrow(() -> new UserIdNotFound("User not found"));

		Cart cart = user.getUserCart();
		int count = 0;
		for (Product p : cart.getCartProducts()) {
			if (p.getProductId() == productId) {
				count = 1;
				break;
			}
		}
		if (count == 0) {
			throw new ProductNotFoundException("Sorry!!! The given product is not available in the cart for this user");
		}

		for (int i = 0; i < cart.getCartProducts().size(); i++) {
			if (cart.getCartProducts().get(i).getProductId() == productId) {
				if (quantity == 0) {
					cart.getCartProducts().remove(i);
					productRepository.deleteById(productId);

				} else {
					cart.getCartProducts().get(i).setProductquantity(quantity);
				}
			}
		}

		cartRepository.saveAndFlush(cart);
		return "updated successfully";
	}

	@Override
	public String deleteProduct(List<Integer> productIds, int userId) throws UserIdNotFound, ProductNotFoundException {
		User user = userRepository.findById(userId).orElseThrow(() -> new UserIdNotFound("id not found"));
		Cart cart = user.getUserCart();

		List<Integer> integerlist = new ArrayList<>();
		for (Integer id : productIds) {
			int count = 0;
			for (Product p : cart.getCartProducts()) {
				if (p.getProductId() == id) {
					count = 1;
					productRepository.delete(p);
					break;
				}
			}
			if (count == 0) {
				throw new ProductNotFoundException("Sorry!!! This product is not in this user cart");
			}
			integerlist.add(id);
		}

		return "successFully deleted";
	}

	@Override
	public String deleteAllProducts(int userId) throws UserIdNotFound {
		User user = userRepository.findById(userId).orElseThrow(() -> new UserIdNotFound("id not found"));
		Cart cart = user.getUserCart();
		for (Product p : cart.getCartProducts()) {
			productRepository.deleteById(p.getProductId());
		}
		return "deleted successfully!!!";
	}

	@Override
	public ProductDto getProductOnProductName(String productName) throws ProductNotFoundException {
		Product product = null;
		int count = 0;
		List<Product> productlist = productRepository.getAllProducts();
		for (Product p : productlist) {
			if (p.getProductName().equalsIgnoreCase(productName)) {
				product = p;
				count = 1;
				break;
			}
		}
		if (count == 0) {
			throw new ProductNotFoundException("Product with the given name is not available");
		}
		ProductDto productdto = convertEntityToDto(product);
		return productdto;
	}

	@Override
	public ProductDto getProductById(int productId) throws ProductNotFoundException {
		Product product = productRepository.findById(productId)
				.orElseThrow(() -> new ProductNotFoundException("Product with given id is not found"));
		ProductDto productdto = convertEntityToDto(product);
		return productdto;
	}

	@Override
	public List<ProductDto> getProductsByCategory(String productCategory) throws ProductNotFoundException {
		List<Product> product = productRepository.findByproductCategory(productCategory);
		if (product.size() == 0) {
			throw new ProductNotFoundException("Product with given category is not availabke");
		}
		List<ProductDto> productdtolist = product.stream().map(i -> convertEntityToDto(i)).collect(Collectors.toList());
		return productdtolist;
	}
}
