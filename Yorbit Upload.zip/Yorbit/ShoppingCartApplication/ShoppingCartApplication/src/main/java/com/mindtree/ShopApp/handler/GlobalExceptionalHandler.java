package com.mindtree.ShopApp.handler;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.ShopApp.common.ApiResponse;
import com.mindtree.ShopApp.controller.ControllerShop;
import com.mindtree.ShopApp.exception.ProductNotFoundException;
import com.mindtree.ShopApp.exception.QuantityShouldNotNegative;
import com.mindtree.ShopApp.exception.UserIdNotFound;

@RestControllerAdvice(assignableTypes = { ControllerShop.class })
public class GlobalExceptionalHandler {

	@ExceptionHandler(UserIdNotFound.class)
	public ResponseEntity<ApiResponse> GlobalUserExceptionHandler(Exception e) {

		ApiResponse apiResponse = new ApiResponse();

		apiResponse.setBody(e.getMessage());
		apiResponse.setMessage("Search Unsuccessfull");
		apiResponse.setError(true);
		apiResponse.setStatus(HttpStatus.NOT_FOUND);
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(apiResponse);

	}

	@ExceptionHandler(QuantityShouldNotNegative.class)
	public ResponseEntity<ApiResponse> GlobalNegQuanExceptionHandler(Exception e) {

		ApiResponse apiResponse = new ApiResponse();

		apiResponse.setBody(e.getMessage());
		apiResponse.setMessage(e.getLocalizedMessage());
		apiResponse.setError(true);
		apiResponse.setStatus(HttpStatus.BAD_REQUEST);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiResponse);

	}

	@ExceptionHandler(ProductNotFoundException.class)
	public ResponseEntity<ApiResponse> GlobalProductNotFoundExceptionHandler(Exception e) {

		ApiResponse apiResponse = new ApiResponse();

		apiResponse.setBody(e.getMessage());
		apiResponse.setMessage(e.getLocalizedMessage());
		apiResponse.setError(true);
		apiResponse.setStatus(HttpStatus.BAD_REQUEST);
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(apiResponse);

	}
}
