#include<iostream>
using namespace std;
int Linear_search(int a[],int n,int n1);
int Linear_search(int a[],int n,int n1)
{int i,j,check=0;
 for(i=0;i<n;i++)
     {
	   if(a[i]==n1)
         { check=1;
           return check;
           break;
         }
     }
     return check;
}
int main()
{int a[20],n,n1,i;
    cout<<" enter the size of array: ";
    cin>>n;
    cout<<" enter the array";
    for(i=0;i<n;i++)
    {cin>>a[i];
    }
    cout<<" enter the element you want to search: ";
    cin>>n1;
   int rel=Linear_search(a,n,n1);
   if(rel==1)
          cout<<" True ";
		  else
		  cout<<" false ";
    
    return 0;
}
