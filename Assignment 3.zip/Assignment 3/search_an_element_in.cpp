#include<iostream>
using namespace std;
void Binary_search( int a[20],int n,int n1);
int main()
{
    int a[20],n,n1,i,j;

        cout<<" enter the size of array: ";
        cin>>n;
        cout<<" enter the array";
        for(i=0;i<n;i++)
      {
	     cin>>a[i];
      }
      for(i=0;i<n;i++)
      {
      	 for(j=i+1;j<n;j++)
      	  { 
      	  	if(a[i]==a[j])
      	      {
				cout<<" ERROR ";
                exit(0);
              }
	      }
	  }
	  
	cout<<" enter the element you want to search: ";
    cin>>n1;
    Binary_search(a,n,n1);
    return 0;
}
    
void Binary_search(int a[20],int n,int n1)
 {  
  int f,l,mid,i;
   f=0;
   l=n-1;
   mid=(f+l)/2;
   while(f<=l)
   {  
         if(a[mid]==n1)
 	  {
	    cout<<n1<<" is found at "<<mid<<endl;
	    break;
	  }
	    else if(a[mid]<n1)
	  {
	 	f=mid+1;
	  }
	     else
	  {
	 	l=mid-1;
	  }
	  mid=(f+l)/2;
   }
   if( f>l)
   {
   	cout<<" not found ";
   	
   }
}
