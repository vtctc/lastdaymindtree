#include<iostream>
using namespace std;

int Max_element(int a[20],int n)
{ int i,j,t;
   cout<<" enter the index 1: ";
   cin>>i;
     cout<<"enter the index 2: ";
     cin>>j;
        if(i<=n&&j<=n)
          { 
              t=1;
          }
          if(t==0)
          {
          	cout<<" element not found ";
          	exit(0);
		  }
		  else
		  cout<<" max element";
		  
		  
		  if(i>=j)
		    return a[i];
	       else
		    return a[j];
	          
	    
	}
int main()
{ int a[20],n,i;
    cout<<" enter the size: ";
    cin>>n;
     cout<<" enter the array: ";
      for(i=0;i<n;i++)
     {
     	cin>>a[i];
     }  
     int r=Max_element(a,n);
     cout<<" greater value is "<<r;
     
	 return 0;
}
