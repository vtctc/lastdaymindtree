#include<iostream>
using namespace std;
int* bubble_sort(int a[],int size);
int* bubble_sort(int a[20],int size)
 { int t,i,j;
 for(i=0;i<size;i++)
     {for(j=0;j<size-i-1;j++)
        {if(a[j]>a[j+1])
           { t=a[j];
             a[j]=a[j+1];
             a[j+1]=t;
		   }
	   }  
    } 
	return a;    
}
int main()
{int a1[20],n,i;
cout<<" enter the number of elements you want to sort: ";
cin>>n;
cout<<" elements of array ";
for( i=0;i<n;i++)
     {cin>>a1[i];
	 }   
	 int*rel=bubble_sort(a1,n);
	 cout<<" sorted array: ";
	   for(i=0;i<n;i++)
	      {
		    cout<<*(rel+i)<<" ";
	      }
 return 0;
}
