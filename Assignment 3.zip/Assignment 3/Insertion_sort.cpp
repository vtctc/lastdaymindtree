#include<iostream>
using namespace std;
int* Insertion_sort(int a[],int n);
int main()
{  int a[20],n,i;

        cout<<" enter the size of array: ";
        cin>>n;
        cout<<" enter the array";
        for(i=0;i<n;i++)
      {
	     cin>>a[i];
      } 
     int*rel=Insertion_sort(a,n);
     cout<<" sorted array: ";
       for(i=0;i<n;i++)
        cout<<*(rel+i)<<" ";
	   
	    return 0;
}
int* Insertion_sort(int a[20],int n)
{
	 int i,j,t;
	 for( i=1;i<n;i++)
	  {
	  	t=a[i];
	  	j=i-1;
	  	while(t<a[j]&&j!=-1)
	  	 { a[j+1]=a[j];
	  	   j=j-1;
	  	 }
	  	 a[j+1]=t;
	  }
	  return a;

}
