#include<iostream>
using namespace std;
int main()
{
	int a1[20],a2[20],i,j,k,b[20],n;
	cout<<"enter the size of size of array ";
	cin>>n;
	cout<<" enter the first sorted array: ";
		for(i=0;i<n;i++)
	   {
		  cin>>a1[i];
	   } 
	 cout<<" enter the second sorted array: ";
	    for(i=0;i<n;i++)
	   {
	  	 cin>>a2[i];
       }
    i=0,j=0,k=0;
    while(i<n&&j<n)
   {
	 if(a1[i]<=a2[j])
        {  b[k]=a1[i];
            k++;
            i++;
       	}
       	else
       	{
       		b[k]=a2[j];
       		k++;
       		j++;
        }
   
    }
         while(i<n)
         {
         	b[k]=a1[i];
         	k++;
         	i++;
		 }

		 while(j<n)
		 {
		 	b[k]=a2[j];
		 	k++;
		 	i++;
		}
   
      cout<<" merge array is ";
      for(i=0;i<n+n;i++)
       cout<<b[i]<<" ";
	  return 0;
}



