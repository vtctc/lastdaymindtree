#include<iostream>
using namespace std;
bool Binary_search(int a[20],int n,int n1);
int main()
{   int a[20],n,n1,i;

        cout<<" enter the size of array: ";
        cin>>n;
        cout<<" enter the array";
        for(i=0;i<n;i++)
      {
	     cin>>a[i];
      }
        cout<<" enter the element you want to search: ";
        cin>>n1;
      bool x=Binary_search(a,n,n1);
      if(x==1)
      	cout<<" true";
	   else
	     cout<<"false";
	  return 0;
}
bool Binary_search(int a[20],int n,int n1)
 {  
  int f,l,mid,i;
   f=0;
   l=n-1;
   mid=(f+l)/2;
   while(f<=l)
   {  
         if(a[mid]==n1)
 	  {
	    return true;
	  }
	    else if(a[mid]<n1)
	  {
	 	f=mid+1;
	  }
	     else
	  {
	 	l=mid-1;
	  }
	  mid=(f+l)/2;
   }
   return false;

}
    
