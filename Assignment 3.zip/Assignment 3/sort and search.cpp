#include<iostream>
using namespace std;
void bubble_sort(int a[20],int size);
void Insertion_sort(int a[20],int n);
void bubble_sort(int a[20],int size)
 {
   int t,i,j;
 for(i=0;i<size;i++)
     {for(j=0;j<size-i-1;j++)
        {if(a[j]>a[j+1])
           { t=a[j];
             a[j]=a[j+1];
             a[j+1]=t;
		   }
	   }  
    }  
   for(i=0;i<size;i++)
   cout<<a[i]<<" ";
	
}
void Insertion_sort(int a[20],int n)
{
	 int i,j,t;
	 for( i=1;i<n;i++)
	  {
	  	t=a[i];
	  	j=i-1;
	  	while(t<a[j]&&j!=-1)
	  	 { a[j+1]=a[j];
	  	   j=j-1;
	  	 }
	  	 a[j+1]=t;
	  }
	  for(i=0;i<n;i++)
	  cout<<a[i]<<" ";
}
int main()
{
	int a[20],n,n1,i,ch;
    cout<<" enter the size of array: ";
    cin>>n;
    cout<<" enter the array";
    for(i=0;i<n;i++)
    {
	   cin>>a[i];
    }
    
	 
do {
	 cout<<" ***MENU***\n ";
	 cout<<"1. bubble_sort \n";
	 cout<<"2. sort using insertion sort \n ";
	 cout<<"3. exit \n";
	 cout<<" enter choice:";
	 cin>>ch;
	switch(ch)
	 {
		case 1:
	 	       bubble_sort(a,n);
	 	       
				 
	 	       break;
	    case 2:
	    	   Insertion_sort(a,n);
	    	   
			   
	    	   break;
	    case 3:	break;
	    	default: cout<<" invalid choice "<<endl;
	  }
	}while(ch!=3);
  
  return 0;	  

}
