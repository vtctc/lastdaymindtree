package com.mindtree.adminService.models;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "screen")
public class Screen {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int screenId;
	private String screenName;
	private int capacity;
	
	@ManyToOne
	@JoinColumn(name = "theater_id")
	private Theater screenTheater;

	@OneToMany(mappedBy = "screen")
	private Set<ShowScreenDetails> showScreenDetails;
	
}
