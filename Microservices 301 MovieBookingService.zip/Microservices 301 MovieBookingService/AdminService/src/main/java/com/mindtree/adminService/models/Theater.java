package com.mindtree.adminService.models;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "theater")
public class Theater {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int theaterId;
	private String theaterName;
	private String restrictions;
	@OneToOne
	@JoinColumn(name = "address_id")
	private Address address;

	@OneToMany
	private Set<Screen> screens;
	
	@OneToMany(mappedBy = "screen")
	private Set<ShowScreenDetails> showScreenDetails;
}
