package com.mindtree.adminService.controllers;

public class AdminController {

}
