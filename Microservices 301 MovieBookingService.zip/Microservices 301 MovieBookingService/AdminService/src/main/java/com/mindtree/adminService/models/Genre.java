package com.mindtree.adminService.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "genre")
public class Genre {

	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int genreId;
	
	private String genreType;
	
	@ManyToOne
	@JoinColumn(name = "movie_id")
	private Movie genreMovie;
	
	
}
