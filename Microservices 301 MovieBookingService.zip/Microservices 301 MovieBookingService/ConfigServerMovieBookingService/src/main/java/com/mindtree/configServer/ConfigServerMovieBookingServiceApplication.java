package com.mindtree.configServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigServerMovieBookingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigServerMovieBookingServiceApplication.class, args);
	}

}
