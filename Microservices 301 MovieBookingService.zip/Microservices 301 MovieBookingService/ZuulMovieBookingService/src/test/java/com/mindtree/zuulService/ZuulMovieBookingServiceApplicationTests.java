package com.mindtree.zuulService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulMovieBookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
