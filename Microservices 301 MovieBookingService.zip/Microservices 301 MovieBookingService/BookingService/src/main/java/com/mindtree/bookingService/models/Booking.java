package com.mindtree.bookingService.models;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "preference")
public class Booking {

	private int bookingId;
	private int userId;
	private String bookingType;
	private String bookingDate;
	private double amount;
	private String theatreName;
	private String movieName;
	private int noOfBookedSeats;
	private String modeOfPayment;
	private int show_screenId;

}
