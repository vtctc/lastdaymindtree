package com.mindtree.eurekaServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaServerMovieBookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
