package com.mindtree.seatService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeatServicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeatServicesApplication.class, args);
	}

}
