package com.eatza.restaurantsearch;

import static org.junit.Assert.*;

import org.junit.Test;

public class RestaurantsearchserviceApplicationTest {

	@Test
	public void testMain() {
	
	}

	@Test
	public void testJwtFilter() {
		
	}

}
