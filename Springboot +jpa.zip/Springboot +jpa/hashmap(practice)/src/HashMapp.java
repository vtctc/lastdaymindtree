import java.util.Map;
import java.util.TreeMap;

public class HashMapp {
	
	public static void main(String[] args) {
		
		
		Map<String,String> check=new TreeMap<>();
		
		check.put("jack","y" );
		check.put("ab","s");
		check.put("d","tk");
		
		System.out.println(check);
		
	}

}
