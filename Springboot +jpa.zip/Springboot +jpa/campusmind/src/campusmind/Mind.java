package campusmind;

public class Mind {

	private String  mindId;
	
	private String mindName;
	
	private int mindAge;

	public Mind() {
		super();
	}

	public Mind(String mindId, String mindName, int mindAge) {
		super();
		this.mindId = mindId;
		this.mindName = mindName;
		this.mindAge = mindAge;
	}

	public String getMindId() {
		return mindId;
	}

	public void setMindId(String mindId) {
		this.mindId = mindId;
	}

	public String getMindName() {
		return mindName;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((mindId == null) ? 0 : mindId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Mind other = (Mind) obj;
		if (mindId == null) {
			if (other.mindId != null)
				return false;
		} else if (!mindId.equals(other.mindId))
			return false;
		return true;
	}

	public void setMindName(String mindName) {
		this.mindName = mindName;
	}

	public int getMindAge() {
		return mindAge;
	}

	public void setMindAge(int mindAge) {
		this.mindAge = mindAge;
	}

	@Override
	public String toString() {
		return "Mind [mindId=" + mindId + ", mindName=" + mindName + ", mindAge=" + mindAge + "]";
	}
	
	
}
