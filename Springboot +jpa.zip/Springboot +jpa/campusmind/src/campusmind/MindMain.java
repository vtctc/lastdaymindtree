package campusmind;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class MindMain {

	public static void main(String[] args) {

		HashMap<Lead, List<Mind>> map = new HashMap<Lead, List<Mind>>();

		List<Mind> minds1 = new ArrayList<Mind>();

		Mind mind1 = new Mind("m105", "shailendra", 22);
		Mind mind2 = new Mind("m107", "sayan", 23);
		minds1.add(mind1);
		minds1.add(mind2);

		List<Mind> minds2 = new ArrayList<Mind>();

		Mind minds3 = new Mind("m106", "ayush", 24);
		Mind minds4 = new Mind("m108", "samira", 25);
		minds2.add(minds3);
		minds2.add(minds4);

		List<Mind> minds8 = new ArrayList<Mind>();

		Mind minds5 = new Mind("m109", "raj", 28);
		Mind minds6 = new Mind("m1010", "shubham", 22);
		minds8.add(minds5);
		minds8.add(minds6);

		List<Lead> leads = new ArrayList<Lead>();

		Lead lead1 = new Lead("m1091", "eswar");
		Lead lead2 = new Lead("m1092", "ankit");
		Lead lead3 = new Lead("m1092", "arpit");
		leads.add(lead1);
		leads.add(lead2);
		leads.add(lead3);

		map.put(lead1, minds1);

		map.put(lead2, minds2);

		map.put(lead3, minds8);

//		for (Entry<Lead, List<Mind>> entry : map.entrySet()) {
//
//			Lead key = entry.getKey();
//			List<Mind> values = entry.getValue();
//			System.out.println(key.toString());
//
//			for (Mind mind : values) {
//				System.out.println(mind);
//			}
//
//		}

		map.forEach((k, v) -> System.out.println(k + " : " + (v)));

	}

}
