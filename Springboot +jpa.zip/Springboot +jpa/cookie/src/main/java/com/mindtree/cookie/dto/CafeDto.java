package com.mindtree.cookie.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class CafeDto {
	
private int cafeId;
	
	private String cafeName;
	
	@JsonIgnoreProperties("cafe")
    List<CookieDto> cookie;

	public CafeDto() {
		super();
	}

	public CafeDto(int cafeId, String cafeName, List<CookieDto> cookie) {
		super();
		this.cafeId = cafeId;
		this.cafeName = cafeName;
		this.cookie = cookie;
	}

	public int getCafeId() {
		return cafeId;
	}

	public void setCafeId(int cafeId) {
		this.cafeId = cafeId;
	}

	public String getCafeName() {
		return cafeName;
	}

	public void setCafeName(String cafeName) {
		this.cafeName = cafeName;
	}

	public List<CookieDto> getCookie() {
		return cookie;
	}

	public void setCookie(List<CookieDto> cookie) {
		this.cookie = cookie;
	}
    

}
