package com.mindtree.cookie.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.cookie.dto.CafeDto;
import com.mindtree.cookie.dto.CookieDto;
import com.mindtree.cookie.entity.Cafe;
import com.mindtree.cookie.entity.Cookie;
import com.mindtree.cookie.exception.serviceexception.CookieServiceException;
import com.mindtree.cookie.exception.serviceexception.NoSuchCafeFound;
import com.mindtree.cookie.repository.CafeRepository;
import com.mindtree.cookie.repository.CookieRepository;
import com.mindtree.cookie.service.CookieService;

@Service
public class CookieServiceImpl implements CookieService {

	@Autowired
	CafeRepository cafeRepository;

	@Autowired
	CookieRepository cookieRepository;

	ModelMapper modelMapper = new ModelMapper();

	public CookieDto convertCookieEntityToDto(Cookie cookie) {
		return modelMapper.map(cookie, CookieDto.class);

	}

	public CafeDto convertCafeEntityToDto(Cafe cafe) {
		return modelMapper.map(cafe, CafeDto.class);

	}

	@Override
	public List<CafeDto> getAllCafeName() {

		List<Cafe> cafe = cafeRepository.findAll();

		List<CafeDto> cafeDto = new ArrayList<CafeDto>();

		cafe.forEach(cafes -> cafeDto.add(modelMapper.map(cafes, CafeDto.class)));

		return cafeDto;
	}

	@Override
	public List<CookieDto> getAllCookieNames() {

		List<Cookie> cookie = cookieRepository.findAll();

		List<CookieDto> cookieDto = new ArrayList<CookieDto>();

		cookie.forEach(cookiess -> cookieDto.add(modelMapper.map(cookiess, CookieDto.class)));
		return cookieDto;
	}

	@Override
	public String addCookie(CookieDto cookie, int cafeId) throws CookieServiceException {

		Optional<Cafe> cafes = cafeRepository.findById(cafeId);

		try {
			cafes.orElseThrow(() -> new NoSuchCafeFound("no such cafe id is found"));
		} catch (NoSuchCafeFound e) {
			throw new CookieServiceException(e.getMessage(), e);
		}

		Cafe cafess = cafes.get();

		Cookie cookiess = modelMapper.map(cookie, Cookie.class);
		cookiess.setCafe(cafess);
		cookieRepository.save(cookiess);

		return "inserted successfully";
	}

	@Override
	public String deleteAllCafe(int cafeId, int cookieId) {

		Optional<Cafe> cafe = cafeRepository.deleteBycafeId(cafeId);
		Cafe cafes = cafe.get();

		List<Cookie> cookieList = cafes.getCookie();

		cookieList.forEach(i -> {
			if (i.getCookieId() == cookieId) {
				cookieRepository.deleteById(i.getCookieId());
			}

		});
		return "deleted successfully";
	}
	

	// @Override
//	public List<CafeDto> getAllCafeName() {
//
//		List<Cafe> cafe = cafeRepository.findAll();
//
//		List<CafeDto> cafeDto = new ArrayList<CafeDto>();
//
//		cafe.forEach(i -> cafeDto.add(modelMapper.map(i, CafeDto.class)));
//
//		return cafeDto;
//	}
//
//	@Override
//	public List<CookieDto> getAllCookieNames() {
//		
//		List<Cookie> cookie=cookieRepository.findAll();
//		
//		List<CookieDto> cookies=new ArrayList<CookieDto>();
//		
//		cookie.forEach(i->cookies.add(modelMapper.map(i, CookieDto.class)));
//		 
//		return cookies;
//	}

//	@Override
//	public String addCookie(CookieDto cookie, int cafeId) throws CookieServiceException {
//
//		Optional<Cafe> cafe = cafeRepository.findById(cafeId);
//
//		try {
//			cafe.orElseThrow(() -> new NoSuchCafeFound("no such cafe found"));
//		} catch (NoSuchCafeFound e) {
//			throw new CookieServiceException(e.getMessage(), e);
//		}
//		Cafe cafes = cafe.get();
//
//		Cookie cookies = modelMapper.map(cookie, Cookie.class);
//
//		List<Cookie> cookiess = new ArrayList<Cookie>();
//
//		cookiess.add(cookies);
////
////		 if(cafes.getCookie()==null)
////		 {
////			 cafes.setCookie(cookiess);
////		 }else
////		 {
////			 cafes.getCookie().add(cookies);
////		 }
//		 cookies.setCafe(cafes);
//		 cookieRepository.save(cookies);
//		 
//		return "inserted successfully";
//	}

}
