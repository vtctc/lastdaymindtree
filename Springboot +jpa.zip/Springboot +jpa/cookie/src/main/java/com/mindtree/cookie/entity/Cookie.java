package com.mindtree.cookie.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Cookie {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int CookieId;
	
	private String cookieName;
	
	private float cookiePrice;
	
	@ManyToOne(fetch = FetchType.EAGER)
	Cafe cafe;

	public Cookie() {
		super();
	}

	public Cookie(int cookieId, String cookieName, float cookiePrice, Cafe cafe) {
		super();
		CookieId = cookieId;
		this.cookieName = cookieName;
		this.cookiePrice = cookiePrice;
		this.cafe = cafe;
	}

	public int getCookieId() {
		return CookieId;
	}

	public void setCookieId(int cookieId) {
		CookieId = cookieId;
	}

	public String getCookieName() {
		return cookieName;
	}

	public void setCookieName(String cookieName) {
		this.cookieName = cookieName;
	}

	public float getCookiePrice() {
		return cookiePrice;
	}

	public void setCookiePrice(float cookiePrice) {
		this.cookiePrice = cookiePrice;
	}

	public Cafe getCafe() {
		return cafe;
	}

	public void setCafe(Cafe cafe) {
		this.cafe = cafe;
	}
	
	

}
