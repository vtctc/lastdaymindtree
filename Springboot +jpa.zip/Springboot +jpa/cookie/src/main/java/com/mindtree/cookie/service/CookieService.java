package com.mindtree.cookie.service;

import java.util.List;

import com.mindtree.cookie.dto.CafeDto;
import com.mindtree.cookie.dto.CookieDto;
import com.mindtree.cookie.exception.serviceexception.CookieServiceException;

public interface CookieService {

	List<CafeDto> getAllCafeName();

	List<CookieDto> getAllCookieNames();

	String addCookie(CookieDto cookie, int cafeId) throws CookieServiceException;

	String deleteAllCafe(int cafeId, int cookieId); 

	//List<CafeDto> getAllCafeName();

	//String addCookie(CookieDto cookie, int cafeId) throws CookieServiceException;

	//List<CookieDto> getAllCookieNames();

}
