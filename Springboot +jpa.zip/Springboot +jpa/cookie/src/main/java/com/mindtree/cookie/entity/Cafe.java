package com.mindtree.cookie.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Cafe {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cafeId;
	
	private String cafeName;
	
	@OneToMany(cascade = CascadeType.PERSIST,fetch = FetchType.LAZY,mappedBy = "cafe")
    List<Cookie> cookie;

	public Cafe() {
		super();
	}

	public Cafe(int cafeId, String cafeName, List<Cookie> cookie) {
		super();
		this.cafeId = cafeId;
		this.cafeName = cafeName;
		this.cookie = cookie;
	}

	public int getCafeId() {
		return cafeId;
	}

	public void setCafeId(int cafeId) {
		this.cafeId = cafeId;
	}

	public String getCafeName() {
		return cafeName;
	}

	public void setCafeName(String cafeName) {
		this.cafeName = cafeName;
	}

	public List<Cookie> getCookie() {
		return cookie;
	}

	public void setCookie(List<Cookie> cookie) {
		this.cookie = cookie;
	}
	
	
	
   
	
	

}
