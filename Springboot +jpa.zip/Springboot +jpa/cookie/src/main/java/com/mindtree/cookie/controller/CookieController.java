package com.mindtree.cookie.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.cookie.dto.CookieDto;
import com.mindtree.cookie.exception.controllerexception.CookieControllerException;
import com.mindtree.cookie.exception.serviceexception.CookieServiceException;
import com.mindtree.cookie.service.CookieService;
import com.mindtree.cookie.service.serviceimpl.CookieServiceImpl;

@RestController
public class CookieController {
	
	@Autowired
	CookieService service;
	

	@GetMapping("/getAllCafeName")
	public ResponseEntity<Map<String, Object>> getallCafeName() {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all cafe name");
		response.put("Error : ", false);
		response.put("body : ", service.getAllCafeName());
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	 }
	
	@GetMapping("/getAllCookieName")
 	public ResponseEntity<Map<String, Object>> getAllCookieName() {
 		Map<String, Object> response = new HashMap<String, Object>();

 		response.put("Headers : ", "get all cafe name");
 		response.put("Error : ", false);
 		response.put("body : ", service.getAllCookieNames());
 		response.put("Http Status : ", HttpStatus.OK);

 		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

 	 }
	
	@PostMapping("/addCookie/{cafeId}")
	public ResponseEntity<Map<String, Object>> addCookie(@RequestBody CookieDto cookie,@PathVariable int cafeId) throws CookieControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all cafe name");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.addCookie(cookie,cafeId));
		} catch (CookieServiceException e) {
			 throw new CookieControllerException(e.getMessage(),e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	 }
	@DeleteMapping("/delete/{cafeId}/{cookieId}")
	public ResponseEntity<Map<String, Object>> deleteCafe(@PathVariable int cafeId,int cookieId) {
 		Map<String, Object> response = new HashMap<String, Object>();

 		response.put("Headers : ", "get all cafe name");
 		response.put("Error : ", false);
 		response.put("body : ", service.deleteAllCafe(cafeId,cookieId));
 		response.put("Http Status : ", HttpStatus.OK);

 		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

 	 }
	
	
	
	
	
	
//     @PostMapping("/addCookie/{cafeId}")
//	 public ResponseEntity<Map<String, Object>> addCookie(@RequestBody CookieDto cookie,@PathVariable int cafeId) throws CookieControllerException {
//		Map<String, Object> response = new HashMap<String, Object>();
//
//		response.put("Headers : ", "add cookie");
//		response.put("Error : ", false);
//		try {
//			response.put("body : ", service.addCookie(cookie,cafeId));
//		} catch (CookieServiceException e) {
//			 throw new CookieControllerException(e.getMessage(),e);
//		}
//		response.put("Http Status : ", HttpStatus.OK);
//
//		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
//
//	}

 	 


}
