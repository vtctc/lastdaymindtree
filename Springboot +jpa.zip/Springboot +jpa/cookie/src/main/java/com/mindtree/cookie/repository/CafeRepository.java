package com.mindtree.cookie.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.cookie.entity.Cafe;

@Repository
public interface CafeRepository extends JpaRepository<Cafe, Integer> {
	
	
	Optional<Cafe> deleteBycafeId(int cafeId);

}
