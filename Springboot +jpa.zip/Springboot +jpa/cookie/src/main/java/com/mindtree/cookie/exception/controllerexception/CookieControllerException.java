package com.mindtree.cookie.exception.controllerexception;

import com.mindtree.cookie.exception.CookieException;

public class CookieControllerException extends CookieException {

	public CookieControllerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CookieControllerException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public CookieControllerException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public CookieControllerException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public CookieControllerException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	

}
