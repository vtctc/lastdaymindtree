package com.mindtree.cricket.exception.cricketserviceexception;

public class NoSuchTeamIdIsFound extends CricketServiceException {

	public NoSuchTeamIdIsFound() {
		// TODO Auto-generated constructor stub
	}

	public NoSuchTeamIdIsFound(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public NoSuchTeamIdIsFound(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchTeamIdIsFound(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public NoSuchTeamIdIsFound(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
