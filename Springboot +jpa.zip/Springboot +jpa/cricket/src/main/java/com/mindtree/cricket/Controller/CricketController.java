package com.mindtree.cricket.Controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.cricket.exception.cricketcontrollerexception.CricketControllerException;
import com.mindtree.cricket.exception.cricketserviceexception.CricketServiceException;
import com.mindtree.cricket.service.CricketService;

@RestController
public class CricketController {

	@Autowired
	CricketService service;

	@PostMapping("/getAvg/{batsmanId}")
	public ResponseEntity<Map<String, Object>> getAvg(@PathVariable int batsmanId) throws CricketControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get avg");
		response.put("Error", false);
		try {
			response.put("body", service.getAvg(batsmanId));
		} catch (CricketServiceException e) {
			throw new CricketControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@PostMapping("/getIncome/{batsmanId}")
	public ResponseEntity<Map<String, Object>> getIncome(@PathVariable int batsmanId)
			throws CricketControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get income");
		response.put("Error", false);
		try {
			response.put("body", service.getIncome(batsmanId));
		} catch (CricketServiceException e) {
			throw new CricketControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/getAllBatsman/{teamid}")
	public ResponseEntity<Map<String, Object>> getAllBatsman(@PathVariable int teamid)
			throws CricketControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all batsman");
		response.put("Error", false);

		try {
			response.put("body", service.getAllBatsman(teamid));
		} catch (CricketServiceException e) {
			throw new CricketControllerException(e.getMessage(), e);
		}

		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

}
