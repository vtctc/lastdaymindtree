package com.mindtree.cricket.exception;

public class CricketException extends Exception {

	public CricketException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CricketException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public CricketException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public CricketException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public CricketException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	

	 
	

}
