

package com.mindtree.cricket.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Batsman {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int batsmanId;
	private String batsmanName;
	private int batsmanTotalRuns;
	private int batsmanTotalinnings;
	private int batsmanTotalOut;
	
	@ManyToOne(fetch = FetchType.EAGER)
    Team team;
	
	@OneToOne(fetch = FetchType.EAGER,mappedBy = "batsman")
	 Statistic statistic;

	public Batsman() {
		super();
	}

	public Batsman(int batsmanId, String batsmanName, int batsmanTotalRuns, int batsmanTotalinnings,
			int batsmanTotalOut, Team team, Statistic statistic) {
		super();
		this.batsmanId = batsmanId;
		this.batsmanName = batsmanName;
		this.batsmanTotalRuns = batsmanTotalRuns;
		this.batsmanTotalinnings = batsmanTotalinnings;
		this.batsmanTotalOut = batsmanTotalOut;
		this.team = team;
		this.statistic = statistic;
	}

	public int getBatsmanId() {
		return batsmanId;
	}

	public void setBatsmanId(int batsmanId) {
		this.batsmanId = batsmanId;
	}

	public String getBatsmanName() {
		return batsmanName;
	}

	public void setBatsmanName(String batsmanName) {
		this.batsmanName = batsmanName;
	}

	public int getBatsmanTotalRuns() {
		return batsmanTotalRuns;
	}

	public void setBatsmanTotalRuns(int batsmanTotalRuns) {
		this.batsmanTotalRuns = batsmanTotalRuns;
	}

	public int getBatsmanTotalinnings() {
		return batsmanTotalinnings;
	}

	public void setBatsmanTotalinnings(int batsmanTotalinnings) {
		this.batsmanTotalinnings = batsmanTotalinnings;
	}

	public int getBatsmanTotalOut() {
		return batsmanTotalOut;
	}

	public void setBatsmanTotalOut(int batsmanTotalOut) {
		this.batsmanTotalOut = batsmanTotalOut;
	}

	public Team getTeam() {
		return team;
	}

	public void setTeam(Team team) {
		this.team = team;
	}

	public Statistic getStatistic() {
		return statistic;
	}

	public void setStatistic(Statistic statistic) {
		this.statistic = statistic;
	}
	
	
	 

}
