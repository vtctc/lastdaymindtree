package com.mindtree.cricket.exception.cricketcontrollerexception;

import com.mindtree.cricket.exception.CricketException;

public class CricketControllerException extends CricketException {

	public CricketControllerException() {
		// TODO Auto-generated constructor stub
	}

	public CricketControllerException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public CricketControllerException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public CricketControllerException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public CricketControllerException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
