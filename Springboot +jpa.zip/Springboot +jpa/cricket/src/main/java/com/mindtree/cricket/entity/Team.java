package com.mindtree.cricket.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Team {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int teamId;
    private String teamName;
    private double teamPricePerMatch;
    
    @OneToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER,mappedBy = "team")
    List<Batsman> batsman;

	public Team() {
		super();
	}

	public Team(int teamId, String teamName, double teamPricePerMatch, List<Batsman> batsman) {
		super();
		this.teamId = teamId;
		this.teamName = teamName;
		this.teamPricePerMatch = teamPricePerMatch;
		this.batsman = batsman;
	}

	public int getTeamId() {
		return teamId;
	}

	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public double getTeamPricePerMatch() {
		return teamPricePerMatch;
	}

	public void setTeamPricePerMatch(double teamPricePerMatch) {
		this.teamPricePerMatch = teamPricePerMatch;
	}

	public List<Batsman> getBatsman() {
		return batsman;
	}

	public void setBatsman(List<Batsman> batsman) {
		this.batsman = batsman;
	}

    
	 
	

}
