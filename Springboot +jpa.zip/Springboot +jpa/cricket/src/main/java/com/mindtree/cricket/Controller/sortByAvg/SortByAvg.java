package com.mindtree.cricket.Controller.sortByAvg;

import java.util.Comparator;

import com.mindtree.cricket.dto.BatsmanDto;

public class SortByAvg implements Comparator<BatsmanDto>{

	@Override
	public  int compare(BatsmanDto b1, BatsmanDto b2) {
		
		double difference = (b1.getStatistic().getStatisticsAvg()-b2.getStatistic().getStatisticsAvg());
		
		if(difference==0) { return 0; }
		else if(difference>0) { return 1; }
		else { return -1; }
	}

}
