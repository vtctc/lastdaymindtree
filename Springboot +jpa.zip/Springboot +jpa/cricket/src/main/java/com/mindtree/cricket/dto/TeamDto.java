package com.mindtree.cricket.dto;

import java.util.List;

public class TeamDto {
	
	private int teamId;
    private String teamName;
    private double teamPricePerMatch;
    
    List<BatsmanDto> batsman;

	public TeamDto() {
		super();
	}

	public TeamDto(int teamId, String teamName, double teamPricePerMatch, List<BatsmanDto> batsman) {
		super();
		this.teamId = teamId;
		this.teamName = teamName;
		this.teamPricePerMatch = teamPricePerMatch;
		this.batsman = batsman;
	}

	public int getTeamId() {
		return teamId;
	}

	public void setTeamId(int teamId) {
		this.teamId = teamId;
	}

	public String getTeamName() {
		return teamName;
	}

	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}

	public double getTeamPricePerMatch() {
		return teamPricePerMatch;
	}

	public void setTeamPricePerMatch(double teamPricePerMatch) {
		this.teamPricePerMatch = teamPricePerMatch;
	}

	public List<BatsmanDto> getBatsman() {
		return batsman;
	}

	public void setBatsman(List<BatsmanDto> batsman) {
		this.batsman = batsman;
	}
    
    



}
