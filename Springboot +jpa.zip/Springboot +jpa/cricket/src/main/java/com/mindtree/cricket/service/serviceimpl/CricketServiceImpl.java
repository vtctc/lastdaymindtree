package com.mindtree.cricket.service.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.cricket.dto.AvgDto;
import com.mindtree.cricket.dto.BatsmanDto;
import com.mindtree.cricket.dto.IncomeDto;
import com.mindtree.cricket.entity.Batsman;
import com.mindtree.cricket.entity.Statistic;
import com.mindtree.cricket.entity.Team;
import com.mindtree.cricket.exception.cricketserviceexception.CricketServiceException;
import com.mindtree.cricket.exception.cricketserviceexception.NoSuchBatsmanIdIsFound;
import com.mindtree.cricket.exception.cricketserviceexception.NoSuchTeamIdIsFound;
import com.mindtree.cricket.repository.BatsmanRepository;
import com.mindtree.cricket.repository.StatisticRepository;
import com.mindtree.cricket.repository.TeamRepository;
import com.mindtree.cricket.service.CricketService;

@Service
public class CricketServiceImpl implements CricketService {

	ModelMapper modelMapper = new ModelMapper();

	@Autowired
	BatsmanRepository batsmanRepository;

	@Autowired
	StatisticRepository statisticRepository;

	@Autowired
	TeamRepository teamRepository;

	@Override
	public AvgDto getAvg(int batsmanId) throws CricketServiceException {

		Optional<Batsman> batsmanOptional = batsmanRepository.findById(batsmanId);
		try {
			batsmanOptional.orElseThrow(() -> new NoSuchBatsmanIdIsFound("no such batsman id is found"));
		} catch (NoSuchBatsmanIdIsFound e) {
			throw new CricketServiceException(e.getMessage(), e);
		}

	    Batsman batsman = batsmanOptional.get();
	    Statistic statistic = new Statistic();
	    
//	    double avg=0;
//	    avg=(batsman.getBatsmanTotalRuns())/(batsman.getBatsmanTotalinnings()-batsman.getBatsmanTotalOut());
//	    statistic=batsman.getStatistic();
//	    statistic.setStatisticsAvg(avg);
//	    statistic.setBatsman(batsman);
//	    batsman.setStatistic(statistic);
//	    batsmanRepository.save(batsman);
//	    
		double avg = statistic.getStatisticsAvg();
		int totalRuns = batsman.getBatsmanTotalRuns();
		int totalIning = batsman.getBatsmanTotalinnings();
		int totalout = batsman.getBatsmanTotalOut();
		avg = (totalRuns / (totalIning - totalout));

		statistic.setBatsman(batsman);
		statistic.setStatisticsAvg(avg);
		batsman.setStatistic(statistic);
		statisticRepository.save(statistic);
	    
	    AvgDto avgDto=new AvgDto();
	    avgDto.setBatsmanName(batsman.getBatsmanName());
	    avgDto.setTeamName(batsman.getTeam().getTeamName());
	    avgDto.setAverage(avg);

		return avgDto;
	}

	@Override
	public IncomeDto getIncome(int batsmanId) throws CricketServiceException {
		Optional<Batsman> batsmanOptional = batsmanRepository.findById(batsmanId);
		try {
			batsmanOptional.orElseThrow(() -> new NoSuchBatsmanIdIsFound("no such batsman id is found"));
		} catch (NoSuchBatsmanIdIsFound e) {
			throw new CricketServiceException(e.getMessage(), e);
		}

		Batsman batsman = batsmanOptional.get();
		
		double pricePerMatch = batsman.getTeam().getTeamPricePerMatch();
		double totainning = batsman.getBatsmanTotalinnings();
		double income = (pricePerMatch * totainning);
		batsman.getStatistic().setStatisticsIncome(income);
		Statistic stats = batsman.getStatistic();
		statisticRepository.saveAndFlush(stats);
		//batsmanRepository.saveAndFlush(batsman);

		IncomeDto incomeDto=new IncomeDto();
		incomeDto.setBatsmanName(batsman.getBatsmanName());
		incomeDto.setTeamNameString(batsman.getTeam().getTeamName());
		incomeDto.setIncome(income);
		
		return incomeDto;
	}

	@Override
	public List<BatsmanDto> getAllBatsman(int teamid) throws CricketServiceException {
		
		Optional<Team> teamOptional = teamRepository.findById(teamid);
		try {
			teamOptional.orElseThrow(() -> new NoSuchTeamIdIsFound("No Such Team Id is Found"));
		} catch (NoSuchTeamIdIsFound e) {
			throw new CricketServiceException(e.getMessage(), e);
		}
		Team team = teamOptional.get();
		List<Batsman> batsmanList=team.getBatsman();
		batsmanList.sort((b1,b2)->{
			int result=(int) (b1.getStatistic().getStatisticsAvg()-b2.getStatistic().getStatisticsAvg());
			if(result>0)
			{
				return -1;
			}
			else {
				return 1;
			}
		});
		List<BatsmanDto> batdto=batsmanList.stream().map(i->modelMapper.map(i, BatsmanDto.class)).collect(Collectors.toList());
		return batdto;
//		for (Batsman batsman : team.getBatsman()) {
//			BatsmanDto batsmanDto = modelMapper.map(batsman, BatsmanDto.class);
//			StatisticDto statsDto = modelMapper.map(.getStatistic(), StatisticDto.class);
//			batsmanDto.setStatistic(statsDto);
//			batsmanList.add(batsmanDto);
//		}
//				Collections.sort(batsmanList,new SortByAvg());
//		return batsmanList;
	}

}
