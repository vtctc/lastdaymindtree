package com.mindtree.cricket.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class StatisticDto {
	
	private int statisticIdl;
	private double statisticsAvg;
	private double statisticsIncome;
	
	@JsonIgnoreProperties("statistic")
	BatsmanDto batsman;

	public StatisticDto() {
		super();
	}

	public StatisticDto(int statisticIdl, double statisticsAvg, double statisticsIncome, BatsmanDto batsman) {
		super();
		this.statisticIdl = statisticIdl;
		this.statisticsAvg = statisticsAvg;
		this.statisticsIncome = statisticsIncome;
		this.batsman = batsman;
	}

	public int getStatisticIdl() {
		return statisticIdl;
	}

	public void setStatisticIdl(int statisticIdl) {
		this.statisticIdl = statisticIdl;
	}

	public double getStatisticsAvg() {
		return statisticsAvg;
	}

	public void setStatisticsAvg(double statisticsAvg) {
		this.statisticsAvg = statisticsAvg;
	}

	public double getStatisticsIncome() {
		return statisticsIncome;
	}

	public void setStatisticsIncome(double statisticsIncome) {
		this.statisticsIncome = statisticsIncome;
	}

	public BatsmanDto getBatsman() {
		return batsman;
	}

	public void setBatsman(BatsmanDto batsman) {
		this.batsman = batsman;
	}
 
	
}

 