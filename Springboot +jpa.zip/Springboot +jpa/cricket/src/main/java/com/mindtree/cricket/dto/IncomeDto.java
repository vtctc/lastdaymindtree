package com.mindtree.cricket.dto;

public class IncomeDto {
	
	private String batsmanName;
	private String teamNameString;
	private double income;
	public IncomeDto() {
		super();
	}
	public IncomeDto(String batsmanName, String teamNameString, double income) {
		super();
		this.batsmanName = batsmanName;
		this.teamNameString = teamNameString;
		this.income = income;
	}
	public String getBatsmanName() {
		return batsmanName;
	}
	public void setBatsmanName(String batsmanName) {
		this.batsmanName = batsmanName;
	}
	public String getTeamNameString() {
		return teamNameString;
	}
	public void setTeamNameString(String teamNameString) {
		this.teamNameString = teamNameString;
	}
	public double getIncome() {
		return income;
	}
	public void setIncome(double income) {
		this.income = income;
	}
	
	

}
