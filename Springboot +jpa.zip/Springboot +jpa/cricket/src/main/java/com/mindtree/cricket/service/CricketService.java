package com.mindtree.cricket.service;

import java.util.List;

import com.mindtree.cricket.dto.AvgDto;
import com.mindtree.cricket.dto.BatsmanDto;
import com.mindtree.cricket.dto.IncomeDto;
import com.mindtree.cricket.exception.cricketserviceexception.CricketServiceException;

public interface CricketService {

	AvgDto getAvg(int batsmanId) throws CricketServiceException;

	IncomeDto getIncome(int batsmanId) throws CricketServiceException;

    List<BatsmanDto> getAllBatsman(int teamid) throws CricketServiceException;

}
