package com.mindtree.cricket.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class BatsmanDto {

	private int batsmanId;
	private String batsmanName;
	private int batsmanTotalRuns;
	private int batsmanTotalinnings;
	private int batsmanTotalOut;

	@JsonIgnoreProperties("batsman")
	TeamDto team;

	@JsonIgnoreProperties("batsman")
	StatisticDto statistic;

	public BatsmanDto() {
		super();
	}

	public BatsmanDto(int batsmanId, String batsmanName, int batsmanTotalRuns, int batsmanTotalinnings,
			int batsmanTotalOut, TeamDto team, StatisticDto statistic) {
		super();
		this.batsmanId = batsmanId;
		this.batsmanName = batsmanName;
		this.batsmanTotalRuns = batsmanTotalRuns;
		this.batsmanTotalinnings = batsmanTotalinnings;
		this.batsmanTotalOut = batsmanTotalOut;
		this.team = team;
		this.statistic = statistic;
	}

	public int getBatsmanId() {
		return batsmanId;
	}

	public void setBatsmanId(int batsmanId) {
		this.batsmanId = batsmanId;
	}

	public String getBatsmanName() {
		return batsmanName;
	}

	public void setBatsmanName(String batsmanName) {
		this.batsmanName = batsmanName;
	}

	public int getBatsmanTotalRuns() {
		return batsmanTotalRuns;
	}

	public void setBatsmanTotalRuns(int batsmanTotalRuns) {
		this.batsmanTotalRuns = batsmanTotalRuns;
	}

	public int getBatsmanTotalinnings() {
		return batsmanTotalinnings;
	}

	public void setBatsmanTotalinnings(int batsmanTotalinnings) {
		this.batsmanTotalinnings = batsmanTotalinnings;
	}

	public int getBatsmanTotalOut() {
		return batsmanTotalOut;
	}

	public void setBatsmanTotalOut(int batsmanTotalOut) {
		this.batsmanTotalOut = batsmanTotalOut;
	}

	public TeamDto getTeam() {
		return team;
	}

	public void setTeam(TeamDto team) {
		this.team = team;
	}

	public StatisticDto getStatistic() {
		return statistic;
	}

	public void setStatistic(StatisticDto statistic) {
		this.statistic = statistic;
	}

}
