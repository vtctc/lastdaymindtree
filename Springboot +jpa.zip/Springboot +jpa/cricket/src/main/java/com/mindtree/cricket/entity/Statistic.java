package com.mindtree.cricket.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Statistic {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int statisticIdl;
	private double statisticsAvg;
	private double statisticsIncome;
	
	@OneToOne(fetch = FetchType.LAZY)
	Batsman batsman;

	public Statistic() {
		super();
	}

	public Statistic(int statisticIdl, double statisticsAvg, double statisticsIncome, Batsman batsman) {
		super();
		this.statisticIdl = statisticIdl;
		this.statisticsAvg = statisticsAvg;
		this.statisticsIncome = statisticsIncome;
		this.batsman = batsman;
	}

	public int getStatisticIdl() {
		return statisticIdl;
	}

	public void setStatisticIdl(int statisticIdl) {
		this.statisticIdl = statisticIdl;
	}

	public double getStatisticsAvg() {
		return statisticsAvg;
	}

	public void setStatisticsAvg(double statisticsAvg) {
		this.statisticsAvg = statisticsAvg;
	}

	public double getStatisticsIncome() {
		return statisticsIncome;
	}

	public void setStatisticsIncome(double statisticsIncome) {
		this.statisticsIncome = statisticsIncome;
	}

	public Batsman getBatsman() {
		return batsman;
	}

	public void setBatsman(Batsman batsman) {
		this.batsman = batsman;
	}
	
	

	 

}
