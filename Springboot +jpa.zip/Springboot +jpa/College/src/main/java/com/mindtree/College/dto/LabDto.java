package com.mindtree.College.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.College.entity.Student;

public class LabDto {
	
	private int labId;
	
	private String labName;
	
	@JsonIgnoreProperties("lab")
    List<StudentDto> student;

	public LabDto() {
		super();
	}

	public LabDto(int labId, String labName, List<StudentDto> student) {
		super();
		this.labId = labId;
		this.labName = labName;
		this.student = student;
	}

	public int getLabId() {
		return labId;
	}

	public void setLabId(int labId) {
		this.labId = labId;
	}

	public String getLabName() {
		return labName;
	}

	public void setLabName(String labName) {
		this.labName = labName;
	}

	public List<StudentDto> getStudent() {
		return student;
	}

	public void setStudent(List<StudentDto> student) {
		this.student = student;
	}

	 
    
	 
}
