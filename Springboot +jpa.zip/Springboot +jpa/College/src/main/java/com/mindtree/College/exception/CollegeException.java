package com.mindtree.College.exception;

public class CollegeException extends Exception{

	public CollegeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CollegeException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public CollegeException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public CollegeException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public CollegeException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	
	

	 
}
