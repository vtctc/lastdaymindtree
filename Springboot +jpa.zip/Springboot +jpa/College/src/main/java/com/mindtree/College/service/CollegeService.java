package com.mindtree.College.service;

import java.util.List;

import com.mindtree.College.dto.LabDto;
import com.mindtree.College.dto.StudentDto;
import com.mindtree.College.entity.Lab;
import com.mindtree.College.exception.serviceexception.CollegeServiceException;

public interface CollegeService {

	String insertIntoLab(LabDto lab);

	LabDto getLab(String studentName) throws CollegeServiceException;

	List<StudentDto> getStudent(int labId) throws CollegeServiceException;
	
    Lab getLab();

}
