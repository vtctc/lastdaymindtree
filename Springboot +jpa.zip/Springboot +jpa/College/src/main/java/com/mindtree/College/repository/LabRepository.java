package com.mindtree.College.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.College.entity.Lab;

@Repository
public interface LabRepository extends JpaRepository<Lab, Integer> {
	
	@Query("select lab from Lab lab where lab.labId=1")
	public Lab getLab();

}
