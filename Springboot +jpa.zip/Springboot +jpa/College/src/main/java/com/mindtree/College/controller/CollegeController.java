package com.mindtree.College.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.College.dto.LabDto;
import com.mindtree.College.dto.StudentDto;
import com.mindtree.College.entity.Lab;
import com.mindtree.College.exception.controllerexception.CollegeControllerException;
import com.mindtree.College.exception.serviceexception.CollegeServiceException;
import com.mindtree.College.service.CollegeService;
 
 
@RestController
public class CollegeController {
	
	
	@Autowired
	CollegeService service;
	
	
	/**
	 * @param lab
	 * @return 
	 */
 
	@PostMapping("/insertLab")
	public ResponseEntity<Map<String, Object>> insertEmployee(@RequestBody LabDto lab) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "insert into lab");
		response.put("Error : ", false);
		response.put("body : ", service.insertIntoLab(lab));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/labDetails/{studentName}")
	public ResponseEntity<Map<String, Object>> labDetails(@PathVariable String studentName) throws CollegeControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get labs");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.getLab(studentName));
		} catch (CollegeServiceException e) {
			 throw new CollegeControllerException(e.getMessage(),e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}
	
	@GetMapping("/studentDetails/{labId}")
	public List<StudentDto> getStudent(@PathVariable int labId) throws CollegeControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "insert into lab");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.getStudent(labId));
		} catch (CollegeServiceException e) {
			 throw new CollegeControllerException(e.getMessage(),e);
		}
		response.put("Http Status : ", HttpStatus.OK);
     	List<StudentDto> studentDto;
		try {
			studentDto = service.getStudent(labId);
		} catch (CollegeServiceException e) {
			 throw new CollegeControllerException();
		}
//		Collections.sort(studentDto);
//		
		return studentDto;

	}
	
	@GetMapping("/getLab")
	public Lab getLab()
	{
		return service.getLab();
	}

	 
}
