package com.mindtree.College.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Lab {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int labId;
	
	private String labName;
	
	@JsonIgnore
	@OneToMany(cascade = CascadeType.PERSIST,fetch = FetchType.LAZY,mappedBy = "lab")
    List<Student> student;

	public Lab() {
		super();
	}

	public Lab(int labId, String labName, List<Student> student) {
		super();
		this.labId = labId;
		this.labName = labName;
		this.student = student;
	}

	public int getLabId() {
		return labId;
	}

	public void setLabId(int labId) {
		this.labId = labId;
	}

	public String getLabName() {
		return labName;
	}

	public void setLabName(String labName) {
		this.labName = labName;
	}

	public List<Student> getStudent() {
		return student;
	}

	public void setStudent(List<Student> student) {
		this.student = student;
	}
	 
	

}
