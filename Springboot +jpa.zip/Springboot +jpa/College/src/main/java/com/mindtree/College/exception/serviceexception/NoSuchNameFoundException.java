package com.mindtree.College.exception.serviceexception;

public class NoSuchNameFoundException extends CollegeServiceException{

	public NoSuchNameFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchNameFoundException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public NoSuchNameFoundException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchNameFoundException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public NoSuchNameFoundException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	 
}
