package com.mindtree.College.service.serviceimpl;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.College.dto.LabDto;
import com.mindtree.College.dto.StudentDto;
import com.mindtree.College.entity.Lab;
import com.mindtree.College.entity.Student;
import com.mindtree.College.exception.serviceexception.CollegeServiceException;
import com.mindtree.College.exception.serviceexception.NoSuchIdExist;
import com.mindtree.College.exception.serviceexception.NoSuchNameFoundException;
import com.mindtree.College.repository.LabRepository;
import com.mindtree.College.repository.StudentRepository;
import com.mindtree.College.service.CollegeService;

@Service
public class CollegeServiceImpl implements CollegeService {

	@Autowired
	LabRepository labRepository;

	@Autowired
	StudentRepository studentRepository;

	ModelMapper modelMapper = new ModelMapper();

	public LabDto convertlabEntityToDto(Lab lab) {
		return modelMapper.map(lab, LabDto.class);
	}

	public StudentDto convertStudentEntityToDto(Student student) {
		return modelMapper.map(student, StudentDto.class);
	}

	@Override
	public String insertIntoLab(LabDto lab) {

		Lab labs = modelMapper.map(lab, Lab.class);

//		for (Student students : labs.getStudent()) {
//			students.setLab(labs);
//		}

		labs.getStudent().forEach(student -> {
			student.setLab(labs);
		});

		labRepository.save(labs);

		return "inserted successfully";
	}

	@Override
	public LabDto getLab(String studentName) throws CollegeServiceException {

		Optional<Student> student = studentRepository.findBystudentName(studentName);

		try {
			student.orElseThrow(() -> new NoSuchNameFoundException("name doesnt exist"));
		} catch (NoSuchNameFoundException e) {
			throw new CollegeServiceException(e.getMessage(), e);
		}

		Lab lab = student.get().getLab();
		LabDto labdto = modelMapper.map(lab, LabDto.class);
		return labdto;

	}

	@Override
	public List<StudentDto> getStudent(int labId) throws CollegeServiceException {

//		Optional<Lab> lab = labRepository.findById(labId);
//		
//		try {
//			lab.orElseThrow(() -> new NoSuchIdExist("no such id exist"));
//			}catch(NoSuchIdExist e) {
//				throw new CollegeServiceException(e.getMessage(),e);
//			}
//		
//
//		List<Student> student = lab.getStudent();
		Lab lab;
		try {
			lab = labRepository.findById(labId).orElseThrow(() -> new NoSuchIdExist("no such id exist"));
		} catch (NoSuchIdExist e) {
			throw new CollegeServiceException(e.getMessage(), e);

		}
		List<Student> student = lab.getStudent();

		List<StudentDto> students = student.stream().map(dt -> convertStudentEntityToDto(dt))
				.collect(Collectors.toList());

		Collections.sort(students);

		return students;
	}

	@Override
	public Lab getLab() {
		 
		Lab labs=labRepository.getLab();
		
		return labs;
	}

}
