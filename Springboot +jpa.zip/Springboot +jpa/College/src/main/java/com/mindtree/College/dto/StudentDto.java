package com.mindtree.College.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.College.entity.Lab;

public class StudentDto implements Comparable<StudentDto> {
	
	
private int studentId;
	
	private String studentName;
	
	private int studentAge;
	
	@JsonIgnoreProperties("student")
	LabDto lab;

	public StudentDto() {
		super();
	}

	public StudentDto(int studentId, String studentName, int studentAge, LabDto lab) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentAge = studentAge;
		this.lab = lab;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public int getStudentAge() {
		return studentAge;
	}

	public void setStudentAge(int studentAge) {
		this.studentAge = studentAge;
	}

	public LabDto getLab() {
		return lab;
	}

	public void setLab(LabDto lab) {
		this.lab = lab;
	}

	@Override
	public int compareTo(StudentDto student) {
		
		if(this.studentAge>student.getStudentAge())
			return -1;
		else
			return 1;
		
	}

	 
	
 

}
