package com.mindtree.building.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Room {
	
	@Id
	private int roomId;
	private String roomName;
	
	@ManyToOne
	private Building building;

	public Room(int roomId, String roomName, Building building) {
		super();
		this.roomId = roomId;
		this.roomName = roomName;
		this.building = building;
	}

	public Room() {
		super();
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public Building getBuilding() {
		return building;
	}

	public void setBuilding(Building building) {
		this.building = building;
	}

	
}
