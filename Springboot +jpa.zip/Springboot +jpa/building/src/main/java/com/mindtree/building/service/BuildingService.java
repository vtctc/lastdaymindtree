package com.mindtree.building.service;

import java.util.List;

import com.mindtree.building.dto.BuildingDto;
import com.mindtree.building.dto.RoomDto;

public interface BuildingService {

	String insertdetails(BuildingDto buildingDto);

	List<RoomDto> insert(int id);

	BuildingDto getBuilding(int id);

	List<BuildingDto> getdetails();

	String deleteBuilding(int id);

}
