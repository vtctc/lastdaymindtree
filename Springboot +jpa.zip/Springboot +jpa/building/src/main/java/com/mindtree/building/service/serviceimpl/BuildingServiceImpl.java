package com.mindtree.building.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.building.dto.BuildingDto;
import com.mindtree.building.dto.RoomDto;
import com.mindtree.building.entity.Building;
import com.mindtree.building.entity.Room;
import com.mindtree.building.repository.BuildingRepository;
import com.mindtree.building.repository.RoomRepository;
import com.mindtree.building.service.BuildingService;

@Service
public class BuildingServiceImpl implements BuildingService {
	
	@Autowired
	BuildingRepository buildingRepos;
	
	@Autowired
	RoomRepository roomRepos;

	@Override
	public String insertdetails(BuildingDto buildingDto) {
		
		List<Room> rooms=new ArrayList<Room>();
		Building build=new Building(buildingDto.getBuildingId(),buildingDto.getBuildingName());
		
     for(RoomDto roomdto:buildingDto.getRoomDto())
     {
    	 
    	 Room room=new Room(roomdto.getRoomId(), roomdto.getRoomName(),build);
    	 rooms.add(room);
     }
     Building building=new Building(buildingDto.getBuildingId(), buildingDto.getBuildingName(), rooms);
   // build.setRoom(rooms);
     
     buildingRepos.save(building);
     roomRepos.saveAll(rooms);		 
	 return "inserted successfully";
	}

	@Override
	public List<RoomDto> insert(int id) {
		   
		Building building =buildingRepos.getOne(id);
		
		List<RoomDto> rooms=new ArrayList<RoomDto>();
		for (Room rum : building.getRoom()) {
			 
			RoomDto roomDto = new RoomDto(rum.getRoomId(), rum.getRoomName(), null);
			rooms.add(roomDto);	
		}
		
		return rooms;
	}

	@Override
	public BuildingDto getBuilding(int id) {
		 
		Room room=roomRepos.getOne(id);
		
		BuildingDto buildingDto=new BuildingDto(room.getBuilding().getBuildingId(),room.getBuilding().getBuildingName(),null);
		 
		return buildingDto;
		
		
		}

	@Override
	public List<BuildingDto> getdetails() {
		 
		List<Building> buildings=new ArrayList<Building>();
		List<Building> building=buildingRepos.findAll();
		
		for(Building building1:building)
		{
			if(building1.getRoom().size()>1)
			{
			buildings.add(building1);
			}
		}
		
	List<BuildingDto> buildingDto=new ArrayList<BuildingDto>();
	
	for (Building building2 : buildings) {
		BuildingDto buildingDtos=new BuildingDto(building2.getBuildingId(),building2.getBuildingName(),null);
		 buildingDto.add(buildingDtos);
		 
		
	}
		return buildingDto;
	}

	@Override
	public String deleteBuilding(int id) {
		 
		List<Building> building=
		
		
		return "deleted successfully";
	}
	 
	
	

}
