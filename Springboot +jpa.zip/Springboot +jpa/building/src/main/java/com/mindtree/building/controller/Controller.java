package com.mindtree.building.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.building.dto.BuildingDto;
import com.mindtree.building.dto.RoomDto;
import com.mindtree.building.service.BuildingService;

@RestController
public class Controller {
	
	@Autowired
	BuildingService buildingServiceobject;
	

	 @PostMapping("/post")
	
	 public String insert(@RequestBody BuildingDto buildingDto)
	 {
		 String s=buildingServiceobject.insertdetails(buildingDto);
		 return s;
	 }
	 

	    @GetMapping("/get/{id}")
	    public List<RoomDto> get(@PathVariable int id)

	    {
	    	List<RoomDto> roomsDto=buildingServiceobject.insert(id);
	    	
	    	return roomsDto;
	    }
		
	 @GetMapping("/getdetail/{id}")
	 public BuildingDto getdetail(@PathVariable int id)
	 {
		 BuildingDto buildingdto=buildingServiceobject.getBuilding(id);
		 
		 return buildingdto;
		 
	 }
	 @GetMapping("/fetchdetails")
	public List<BuildingDto> getdt()
	 {
		List<BuildingDto> buildingDto=buildingServiceobject.getdetails();
		 
		return buildingDto;
	 }
	
	 @DeleteMapping("/delete/{id}")
	 public String del(@PathVariable int id)
	 {
		 
		 String s=buildingServiceobject.deleteBuilding(id);
		 return  s;
		 
	 }
}
