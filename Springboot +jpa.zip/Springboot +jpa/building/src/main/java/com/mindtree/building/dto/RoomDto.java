package com.mindtree.building.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class RoomDto {
	
	private int roomId;
	private String roomName;
	
	private BuildingDto buildingDto;

	public RoomDto(int roomId, String roomName, BuildingDto buildingDto) {
		super();
		this.roomId = roomId;
		this.roomName = roomName;
		this.buildingDto = buildingDto;
	}

	public RoomDto() {
		super();
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public String getRoomName() {
		return roomName;
	}

	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	public BuildingDto getBuildingDto() {
		return buildingDto;
	}

	public void setBuildingDto(BuildingDto buildingDto) {
		this.buildingDto = buildingDto;
	}
	


}
