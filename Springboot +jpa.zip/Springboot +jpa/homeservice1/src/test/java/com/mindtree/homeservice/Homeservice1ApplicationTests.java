package com.mindtree.homeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Homeservice1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
