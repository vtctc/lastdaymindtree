package com.mindtree.homeservice.service;

import com.mindtree.homeservice.dto.RegistrationDto;
import com.mindtree.homeservice.dto.UserDto;

public interface HomeServiceService {

   String insertDataIntoUser(UserDto userDto);
 
   UserDto showUserProfile(int id);

   String updateUserProfile(int id, UserDto userDto);

   String updatePassword(String s, RegistrationDto registrationDto);

   //UserProfileDto showUserProfileByEmailId(String emailId);

}
