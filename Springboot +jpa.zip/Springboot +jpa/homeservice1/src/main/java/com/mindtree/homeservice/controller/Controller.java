package com.mindtree.homeservice.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.homeservice.dto.RegistrationDto;
import com.mindtree.homeservice.dto.UserDto;
import com.mindtree.homeservice.service.HomeServiceService;

@RestController
@CrossOrigin
public class Controller {

	@Autowired
	HomeServiceService service;
 
	@PostMapping("insertUserProfile")
	public ResponseEntity<Map<String, Object>> insertUserData(@RequestBody UserDto userDto) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Headers : ", "insert data into user");
		response.put("Error : ", false);
		response.put("body : ", service.insertDataIntoUser(userDto));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("showUserProfile/{id}")
	public ResponseEntity<Map<String, Object>> showUserDetails(@PathVariable int id) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "user profile details");
		response.put("Error : ", false);
		response.put("body : ", service.showUserProfile(id));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@PutMapping("/updateUserProfile/{id}")
	public ResponseEntity<Map<String, Object>> showUserDetails(@PathVariable int id,
			@RequestBody UserDto userDto) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "user profile updated");
		response.put("Error : ", false);
		response.put("body : ", service.updateUserProfile(id, userDto));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@PutMapping("/updatePassword/{s}")
	public ResponseEntity<Map<String, Object>> updatePassword(@PathVariable String s,
			@RequestBody RegistrationDto registrationDto) {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Headers : ", "user password updated");
		response.put("Error : ", false);
		response.put("body : ", service.updatePassword(s, registrationDto));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}
//	@GetMapping("/showUserProfilebyemailId/{emaildId}")
//	public ResponseEntity<Map<String, Object>> showUserDetailsByEmailId(@PathVariable String emailId) {
//		Map<String, Object> response = new HashMap<String, Object>();
//
//		response.put("Headers : ", "user profile details by emaildId");
//		response.put("Error : ", false);
//		response.put("body : ", service.showUserProfileByEmailId(emailId));
//		response.put("Http Status : ", HttpStatus.OK);
//
//		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
//
//	}


} 