package com.mindtree.homeservice.entity;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="user")
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="user_id")
	private int userId;
	
	@Column(name= "user_first_name")
	private String userFirstName;
	
	
	@Column(name="user_last_name")
	private String userLastName;
	
	
	@Column(name="user_email")
	private String userEmail;
	
	
	@Column(name="user_phone")
	private long userPhone;
	
	@Lob
	@Column(name="user_image")
	private byte[] userPic;
	
	@Column(name="user_gender")
	private String userGender;
	
	@OneToOne(fetch = FetchType.EAGER)
	Address address;
	
	
	@OneToOne(fetch = FetchType.EAGER)
	Registration registration;
	
	

	public User() {
		super();
	}



	public User(int userId, String userFirstName, String userLastName, String userEmail, long userPhone,
			byte[] userPic, String userGender, Address address, Registration registration) {
		super();
		this.userId = userId;
		this.userFirstName = userFirstName;
		this.userLastName = userLastName;
		this.userEmail = userEmail;
		this.userPhone = userPhone;
		this.userPic = userPic;
		this.userGender = userGender;
		this.address = address;
		this.registration = registration;
	}



	public int getUserId() {
		return userId;
	}



	public void setUserId(int userId) {
		this.userId = userId;
	}



	public String getUserFirstName() {
		return userFirstName;
	}



	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}



	public String getUserLastName() {
		return userLastName;
	}



	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}



	public String getUserEmail() {
		return userEmail;
	}



	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}



	public long getUserPhone() {
		return userPhone;
	}



	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}



	public byte[] getUserPic() {
		return userPic;
	}



	public void setUserPic(byte[] userPic) {
		this.userPic = userPic;
	}



	public String getUserGender() {
		return userGender;
	}



	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}



	public Address getAddress() {
		return address;
	}



	public void setAddress(Address address) {
		this.address = address;
	}



	public Registration getRegistration() {
		return registration;
	}



	public void setRegistration(Registration registration) {
		this.registration = registration;
	}



	@Override
	public String toString() {
		return "UserProfile [userId=" + userId + ", userFirstName=" + userFirstName + ", userLastName=" + userLastName
				+ ", userEmail=" + userEmail + ", userPhone=" + userPhone + ", userPic=" + Arrays.toString(userPic)
				+ ", userGender=" + userGender + ", address=" + address + ", registration=" + registration + "]";
	}
	
	
	
	
	
    
     

 
	 

}
 