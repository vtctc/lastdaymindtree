package com.mindtree.homeservice.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class AddressDto {

	private int addressId;

	private int buildingNumber;

	private String city;

	private String landmark;

	private String state;

	private String street;

	private int zip;

	public AddressDto(int addressId, int buildingNumber, String city, String landmark, String state, String street,
			int zip) {
		super();
		this.addressId = addressId;
		this.buildingNumber = buildingNumber;
		this.city = city;
		this.landmark = landmark;
		this.state = state;
		this.street = street;
		this.zip = zip;
	}

	public AddressDto() {
		super();
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public int getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(int buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "AddressDto [addressId=" + addressId + ", buildingNumber=" + buildingNumber + ", city=" + city
				+ ", landmark=" + landmark + ", state=" + state + ", street=" + street + ", zip=" + zip + "]";
	}

}
