package com.mindtree.homeservice.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class UserDto {

	private int userId;

	private String userFirstName;

	private String userLastName;

	private String userEmail;

	private long userPhone;

	private byte[] userPic;

	private String userGender;

	private AddressDto address;

	private RegistrationDto registrationDto;

	public UserDto(int userId, String userFirstName, String userLastName, String userEmail, long userPhone,
			byte[] userPic, String userGender, AddressDto address, RegistrationDto registrationDto) {
		super();
		this.userId = userId;
		this.userFirstName = userFirstName;
		this.userLastName = userLastName;
		this.userEmail = userEmail;
		this.userPhone = userPhone;
		this.userPic = userPic;
		this.userGender = userGender;
		this.address = address;
		this.registrationDto = registrationDto;
	}

	public UserDto() {
		super();
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserFirstName() {
		return userFirstName;
	}

	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}

	public String getUserLastName() {
		return userLastName;
	}

	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public long getUserPhone() {
		return userPhone;
	}

	public void setUserPhone(long userPhone) {
		this.userPhone = userPhone;
	}

	public byte[] getUserPic() {
		return userPic;
	}

	public void setUserPic(byte[] userPic) {
		this.userPic = userPic;
	}

	public String getUserGender() {
		return userGender;
	}

	public void setUserGender(String userGender) {
		this.userGender = userGender;
	}

	public AddressDto getAddress() {
		return address;
	}

	public void setAddress(AddressDto address) {
		this.address = address;
	}

	public RegistrationDto getRegistrationDto() {
		return registrationDto;
	}

	public void setRegistrationDto(RegistrationDto registrationDto) {
		this.registrationDto = registrationDto;
	}

	 	
}																									