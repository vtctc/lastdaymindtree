package com.mindtree.homeservice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="address")
public class Address {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="address_id")
    private int addressId;
	
	
	@Column(name="building_no")
	private int buildingNumber;
	
	
	@Column(name="city")
	private String city;
	
	
	@Column(name="landmark")
	private String landmark;
	
	
	@Column(name="state")
	private String state;
	
	
	@Column(name="street")
	private String street;
	
	
	@Column(name="zip")
	private int zip;

	public Address() {
		super();
	}

	public Address(int addressId, int buildingNumber, String city, String landmark, String state, String street,
			int zip) {
		super();
		this.addressId = addressId;
		this.buildingNumber = buildingNumber;
		this.city = city;
		this.landmark = landmark;
		this.state = state;
		this.street = street;
		this.zip = zip;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public int getBuildingNumber() {
		return buildingNumber;
	}

	public void setBuildingNumber(int buildingNumber) {
		this.buildingNumber = buildingNumber;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", buildingNumber=" + buildingNumber + ", city=" + city
				+ ", landmark=" + landmark + ", state=" + state + ", street=" + street + ", zip=" + zip + "]";
	}

	 
	

}
