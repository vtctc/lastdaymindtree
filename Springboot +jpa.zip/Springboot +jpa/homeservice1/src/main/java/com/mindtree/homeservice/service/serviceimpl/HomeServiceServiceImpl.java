package com.mindtree.homeservice.service.serviceimpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.homeservice.dto.AddressDto;
import com.mindtree.homeservice.dto.RegistrationDto;
import com.mindtree.homeservice.dto.UserDto;
import com.mindtree.homeservice.entity.Address;
import com.mindtree.homeservice.entity.Registration;
import com.mindtree.homeservice.entity.User;
import com.mindtree.homeservice.repository.AddressRepository;
import com.mindtree.homeservice.repository.RegistrationRepository;
import com.mindtree.homeservice.repository.UserRepository;
import com.mindtree.homeservice.service.HomeServiceService;

@Service
public class HomeServiceServiceImpl implements HomeServiceService {

	final String secretKey = "ssshhhhhhhhhhh!!!!";

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RegistrationRepository registrationRepository;

	@Autowired
	private AddressRepository addressRepository;

	ModelMapper modelMapper = new ModelMapper();

	public UserDto convertUserEntityToDto(User userProfile) {

		return modelMapper.map(userProfile, UserDto.class);
	}

	public RegistrationDto convertRegistrationEntityToDto(Registration registration) {

		return modelMapper.map(registration, RegistrationDto.class);
	}

	public AddressDto convertAddressEntityToDto(Address address) {

		return modelMapper.map(address, AddressDto.class);
	}

	@Override
	public String insertDataIntoUser(UserDto userDto) {
		
		User user = modelMapper.map(userDto, User.class);

		addressRepository.save(user.getAddress());

		user.setAddress(user.getAddress());

		userRepository.save(user);

		return "inserted successfully";
	}

	@Override
	public UserDto showUserProfile(int id) {

		User user = userRepository.getOne(id);

		Address address = user.getAddress();

		UserDto userDto = convertUserEntityToDto(user);

		AddressDto addressDto = convertAddressEntityToDto(address);

		userDto.setAddress(addressDto);

		return userDto;
	}

	@Override
	public String updateUserProfile(int id, UserDto userDto) {

		User user = userRepository.getOne(id);

		User user2 = modelMapper.map(userDto, User.class);

		addressRepository.save(user2.getAddress());

		user.setAddress(user2.getAddress());
		user.setUserEmail(user2.getUserEmail());
		user.setUserFirstName(user2.getUserFirstName());
		user.setUserLastName(user2.getUserLastName());
		user.setUserPhone(user2.getUserPhone());
		user.setUserPic(user2.getUserPic());
		user.setUserGender(user2.getUserGender());
		userRepository.save(user);

		return "updated successfully";
	}

	@Override
	public String updatePassword(String s, RegistrationDto registrationDto) {

		Registration registration = registrationRepository.findByuserName(s);

		Registration newRegistrationPassword = modelMapper.map(registrationDto, Registration.class);

		registration.setPassword(newRegistrationPassword.getPassword());
		registrationRepository.save(registration);

		return "updated successfully";
	}

//	@Override
//	public UserProfileDto showUserProfileByEmailId(String emailId) {
//
//		UserProfile userProfile = userProfileRepository.findByuserEmail(emailId);
//
//		Address address = userProfile.getAddress();
//
//		UserProfileDto userprofileDto = convertUserProfileEntityToDto(userProfile);
//
//		AddressDto addressDto = convertAddressEntityToDto(address);
//
//		userprofileDto.setAddress(addressDto);
//
//		return userprofileDto;
//
//	}

}
