package com.mindtree.hospitals1.exception.serviceexception;

public class HospitalNotFoundException extends Hospitals1ServiceException {

	public HospitalNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public HospitalNotFoundException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public HospitalNotFoundException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public HospitalNotFoundException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public HospitalNotFoundException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
