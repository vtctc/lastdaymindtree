package com.mindtree.hospitals1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hospitals1Application {

	public static void main(String[] args) {
		SpringApplication.run(Hospitals1Application.class, args);
	}

}
