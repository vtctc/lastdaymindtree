package com.mindtree.hospitals1.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.hospitals1.dto.HospitalDto;
import com.mindtree.hospitals1.dto.PatientDto;
import com.mindtree.hospitals1.entity.Patient;
import com.mindtree.hospitals1.exception.serviceexception.HospitalNotFoundException;
import com.mindtree.hospitals1.exception.serviceexception.Hospitals1ServiceException;
import com.mindtree.hospitals1.service.Hospitals1Service;

@RestController
public class Hospitals1Controller {

	@Autowired
	Hospitals1Service service;

	@PostMapping("/addHospital")
	public ResponseEntity<Map<String, Object>> addHospial(@RequestBody HospitalDto hospitalDto) throws Hospitals1ServiceException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get highest price bike");
		response.put("Error", false);
		response.put("body", service.addHospital(hospitalDto));
		response.put("Http Status : ", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}
	
	@PostMapping("/addPatient/{hospitalId}")
	public ResponseEntity<Map<String, Object>> addPatientToHospital(@RequestBody PatientDto patientDto, @PathVariable int hospitalId) throws HospitalNotFoundException {
		Map<String, Object> response = new HashMap<String, Object>();
		
		response.put("Headers : ", "get highest price bike");
		response.put("Error", false);
		response.put("body", service.addPatientToHospital(patientDto,hospitalId));
		response.put("Http Status : ", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}
	
	@GetMapping("/getAllPatientByHospitalId/{hospitalId}")
	public ResponseEntity<Map<String, Object>> addHospial(@PathVariable int hospitalId) throws HospitalNotFoundException {
		Map<String, Object> response = new HashMap<String, Object>();
		
		response.put("Headers : ", "get highest price bike");
		response.put("Error", false);
		response.put("body", service.getAllPatientByHospitalId(hospitalId));
		response.put("Http Status : ", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}
	
	@GetMapping("/getAllPatientByHospitalName/{hospitalName}")
	public ResponseEntity<Map<String, Object>> getAllPatientByHospitalName(@PathVariable String hospitalName) throws HospitalNotFoundException {
		Map<String, Object> response = new HashMap<String, Object>();
		
		response.put("Headers : ", "get highest price bike");
		response.put("Error", false);
		response.put("body", service.getAllPatientByHospitalName(hospitalName));
		response.put("Http Status : ", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}
	
	@GetMapping("/getAllPatientForBillingValue")
	public ResponseEntity<Map<String, Object>> getAllPatientForBillingValue() {
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Headers : ", "get highest price bike");
		response.put("Error", false);
		response.put("body", service.getAllPatientForBillingValue());
		response.put("Http Status : ", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}
	
	@GetMapping("/makeAPersonFitById/{patientId}")
	public ResponseEntity<Map<String, Object>> makeAPersonFitById(@PathVariable int patientId) {
		Map<String, Object> response = new HashMap<String, Object>();
		
		response.put("Headers : ", "get highest price bike");
		response.put("Error", false);
		response.put("body", service.makeAPersonFitById(patientId));
		response.put("Http Status : ", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}
	
	@GetMapping("/makeAPersonFitByName/{patientName}")
	public ResponseEntity<Map<String, Object>> makeAPersonFitByName(@PathVariable String patientName) {
		Map<String, Object> response = new HashMap<String, Object>();
		
		response.put("Headers : ", "get highest price bike");
		response.put("Error", false);
		response.put("body", service.makeAPersonFitByName(patientName));
		response.put("Http Status : ", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}
	
}
