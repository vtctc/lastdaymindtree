package com.mindtree.hospitals1.exception.controllerexception;

import com.mindtree.hospitals1.exception.Hospital1Exception;

public class Hospitals1ControllerException extends Hospital1Exception {

	public Hospitals1ControllerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hospitals1ControllerException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public Hospitals1ControllerException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public Hospitals1ControllerException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public Hospitals1ControllerException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	

}
