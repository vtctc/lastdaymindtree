package com.mindtree.hospitals1.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class PatientDto {

	private int patientId;
	private String patientName;
	boolean isfit;
	@JsonIgnore
	HospitalDto hospital;
	@JsonIgnore
	List<DiseaseDto> disease;

	public PatientDto() {
		super();
	}

	public PatientDto(int patientId, String patientName, boolean isfit, HospitalDto hospital,
			List<DiseaseDto> disease) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.isfit = isfit;
		this.hospital = hospital;
		this.disease = disease;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public boolean isIsfit() {
		return isfit;
	}

	public void setIsfit(boolean isfit) {
		this.isfit = isfit;
	}

	public HospitalDto getHospital() {
		return hospital;
	}

	public void setHospital(HospitalDto hospital) {
		this.hospital = hospital;
	}

	public List<DiseaseDto> getDisease() {
		return disease;
	}

	public void setDisease(List<DiseaseDto> disease) {
		this.disease = disease;
	}

}
