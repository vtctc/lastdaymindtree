package com.mindtree.hospitals1.service.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.hibernate.service.spi.ServiceException;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.hospitals1.dto.HospitalDto;
import com.mindtree.hospitals1.dto.PatientDto;
import com.mindtree.hospitals1.entity.Disease;
import com.mindtree.hospitals1.entity.Hospital;
import com.mindtree.hospitals1.entity.Patient;
import com.mindtree.hospitals1.exception.serviceexception.HospitalNotFoundException;
import com.mindtree.hospitals1.exception.serviceexception.Hospitals1ServiceException;
import com.mindtree.hospitals1.repository.DiseaseRepository;
import com.mindtree.hospitals1.repository.HospitalRepository;
import com.mindtree.hospitals1.repository.PatientRepository;
import com.mindtree.hospitals1.service.Hospitals1Service;
import com.mindtree.hospitals1.util.SortPatient;

@Service
public class Hospitals1ServiceImpl implements Hospitals1Service {

	@Autowired
	HospitalRepository hospitalRepository;

	@Autowired
	PatientRepository patientRepository;

	@Autowired
	DiseaseRepository diseaseRepository;

	ModelMapper mapper = new ModelMapper();

	@Override
	public String addHospital(HospitalDto hospitalDto) throws Hospitals1ServiceException {
		try {
			hospitalRepository.save(mapper.map(hospitalDto, Hospital.class));
		} catch (Exception e) {
			throw new Hospitals1ServiceException("Failed to add hospital");
		}
		return "inserted";
	}

	@Override
	public String addPatientToHospital(PatientDto patientDto, int hospitalId) throws HospitalNotFoundException {

		patientDto.setIsfit(false);
		Hospital hospital = null;
		try {
			Patient patient = mapper.map(patientDto, Patient.class);
			hospital = hospitalRepository.findById(hospitalId)
					.orElseThrow(() -> new HospitalNotFoundException("Given Hopital Id is not found"));
			patient.setHospital(hospital);
			patientRepository.save(patient);
		} catch (Exception e) {
			throw new ServiceException("Not able to add patient to hospital");
		}
		return "assigned successfully";
	}

	@Override
	public List<PatientDto> getAllPatientByHospitalId(int hospitalId) throws HospitalNotFoundException {
		return hospitalRepository.findById(hospitalId)
				.orElseThrow(() -> new HospitalNotFoundException("No Such Hospital Found")).getPatient().stream()
				.map(patient -> mapper.map(patient, PatientDto.class)).collect(Collectors.toList());
	}

	@Override
	public List<PatientDto> getAllPatientByHospitalName(String hospitalName) throws HospitalNotFoundException {
		return hospitalRepository.findByhospitalName(hospitalName)
				.orElseThrow(() -> new HospitalNotFoundException("No Such Hospital Found")).getPatient().stream()
				.map(patient -> mapper.map(patient, PatientDto.class)).collect(Collectors.toList());
	}

	@Override
	public List<PatientDto> getAllPatientForBillingValue() {
		List<PatientDto> patientDtos = new ArrayList<PatientDto>();
		List<Patient> patients = patientRepository.findAll();
		for (Patient patient : patients) {
			if (getBillingAmount(patient) > 3000) {
				patientDtos.add(mapper.map(patient, PatientDto.class));
			}
		}
		Collections.sort(patientDtos, new SortPatient());
		return patientDtos;
	}

	@Override
	public String makeAPersonFitById(int patientId) {

		return null;
	}

	@Override
	public String makeAPersonFitByName(String patientName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getBillingAmount(Patient patient) {
		double billingAmount = 0;
		for (Disease disease : patient.getDisease()) {
			billingAmount = billingAmount + disease.getDiseaseCost();
		}
		billingAmount = (0.9) * billingAmount;
		// billingAmount = billingAmount-(0.1)*billingAmount;
		billingAmount = 1.1 * billingAmount;
		return billingAmount;
	}
}
