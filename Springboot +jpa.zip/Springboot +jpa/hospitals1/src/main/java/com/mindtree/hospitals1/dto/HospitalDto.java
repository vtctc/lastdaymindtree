package com.mindtree.hospitals1.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

    public class HospitalDto {
	private int hospitalId;
	private String hospitalName;
	List<PatientDto> patient;

	public HospitalDto() {
		super();
	}

	public HospitalDto(int hospitalId, String hospitalName, List<PatientDto> patient) {
		super();
		this.hospitalId = hospitalId;
		this.hospitalName = hospitalName;
		this.patient = patient;
	}

	public int getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public List<PatientDto> getPatient() {
		return patient;
	}

	public void setPatient(List<PatientDto> patient) {
		this.patient = patient;
	}
	


}
