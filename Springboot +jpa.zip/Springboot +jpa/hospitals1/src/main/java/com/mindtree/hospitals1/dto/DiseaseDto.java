package com.mindtree.hospitals1.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class DiseaseDto {
	
	private int  diseaseId;
	private String diseaseName;
	private String diseaseSevreity;
	private double diseaseCost;
	@JsonIgnoreProperties("disease")
	List<PatientDto> patient;

	public DiseaseDto() {
		super();
	}

	public DiseaseDto(int diseaseId, String diseaseName, String diseaseSevreity, double diseaseCost,
			List<PatientDto> patient) {
		super();
		this.diseaseId = diseaseId;
		this.diseaseName = diseaseName;
		this.diseaseSevreity = diseaseSevreity;
		this.diseaseCost = diseaseCost;
		this.patient = patient;
	}

	public int getDiseaseId() {
		return diseaseId;
	}

	public void setDiseaseId(int diseaseId) {
		this.diseaseId = diseaseId;
	}

	public String getDiseaseName() {
		return diseaseName;
	}

	public void setDiseaseName(String diseaseName) {
		this.diseaseName = diseaseName;
	}

	public String getDiseaseSevreity() {
		return diseaseSevreity;
	}

	public void setDiseaseSevreity(String diseaseSevreity) {
		this.diseaseSevreity = diseaseSevreity;
	}

	public double getDiseaseCost() {
		return diseaseCost;
	}

	public void setDiseaseCost(double diseaseCost) {
		this.diseaseCost = diseaseCost;
	}

	public List<PatientDto> getPatient() {
		return patient;
	}

	public void setPatient(List<PatientDto> patient) {
		this.patient = patient;
	}



	


}
