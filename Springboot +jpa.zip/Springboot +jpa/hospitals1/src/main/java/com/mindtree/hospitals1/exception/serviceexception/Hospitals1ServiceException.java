package com.mindtree.hospitals1.exception.serviceexception;

import com.mindtree.hospitals1.exception.Hospital1Exception;

public class Hospitals1ServiceException extends Hospital1Exception{

	public Hospitals1ServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hospitals1ServiceException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public Hospitals1ServiceException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public Hospitals1ServiceException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public Hospitals1ServiceException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
