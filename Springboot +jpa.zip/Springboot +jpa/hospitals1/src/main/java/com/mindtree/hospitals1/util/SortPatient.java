package com.mindtree.hospitals1.util;

import java.util.Comparator;

import com.mindtree.hospitals1.dto.PatientDto;

public class SortPatient implements Comparator<PatientDto> {

	@Override
	public int compare(PatientDto patient1, PatientDto patient2) {
		return patient1.getPatientId()-patient2.getPatientId();
	}

	

}
