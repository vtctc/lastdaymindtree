package com.mindtree.hospitals1.exception.serviceexception;

public class NoPatientFoundException extends Hospitals1ServiceException {

	public NoPatientFoundException() {
		// TODO Auto-generated constructor stub
	}

	public NoPatientFoundException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public NoPatientFoundException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public NoPatientFoundException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public NoPatientFoundException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
