package com.mindtree.hospitals1.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Patient {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int patientId;
	private String patientName;
	boolean isfit;

	@ManyToOne(fetch = FetchType.EAGER)
	Hospital hospital;

	@ManyToMany(cascade = CascadeType.PERSIST, fetch = FetchType.LAZY, mappedBy = "patient")
	List<Disease> disease;

	public Patient() {
		super();
	}

	public Patient(int patientId, String patientName, boolean isfit, Hospital hospital, List<Disease> disease) {
		super();
		this.patientId = patientId;
		this.patientName = patientName;
		this.isfit = isfit;
		this.hospital = hospital;
		this.disease = disease;
	}

	public int getPatientId() {
		return patientId;
	}

	public void setPatientId(int patientId) {
		this.patientId = patientId;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public boolean isIsfit() {
		return isfit;
	}

	public void setIsfit(boolean isfit) {
		this.isfit = isfit;
	}

	public Hospital getHospital() {
		return hospital;
	}

	public void setHospital(Hospital hospital) {
		this.hospital = hospital;
	}

	public List<Disease> getDisease() {
		return disease;
	}

	public void setDisease(List<Disease> disease) {
		this.disease = disease;
	}

}
