package com.mindtree.hospitals1.exception;

public class Hospital1Exception extends Exception{

	public Hospital1Exception() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Hospital1Exception(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public Hospital1Exception(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public Hospital1Exception(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public Hospital1Exception(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	

}
