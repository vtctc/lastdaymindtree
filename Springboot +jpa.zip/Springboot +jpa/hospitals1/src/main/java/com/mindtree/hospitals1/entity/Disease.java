
package com.mindtree.hospitals1.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Disease {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int  diseaseId;
	private String diseaseName;
	private String diseaseSevreity;
	private double diseaseCost;
	
	@ManyToMany(fetch = FetchType.LAZY)
	List<Patient> patient;

	public Disease() {
		super();
	}

	public Disease(int diseaseId, String diseaseName, String diseaseSevreity, double diseaseCost,
			List<Patient> patient) {
		super();
		this.diseaseId = diseaseId;
		this.diseaseName = diseaseName;
		this.diseaseSevreity = diseaseSevreity;
		this.diseaseCost = diseaseCost;
		this.patient = patient;
	}

	public int getDiseaseId() {
		return diseaseId;
	}

	public void setDiseaseId(int diseaseId) {
		this.diseaseId = diseaseId;
	}

	public String getDiseaseName() {
		return diseaseName;
	}

	public void setDiseaseName(String diseaseName) {
		this.diseaseName = diseaseName;
	}

	public String getDiseaseSevreity() {
		return diseaseSevreity;
	}

	public void setDiseaseSevreity(String diseaseSevreity) {
		this.diseaseSevreity = diseaseSevreity;
	}

	public double getDiseaseCost() {
		return diseaseCost;
	}

	public void setDiseaseCost(double diseaseCost) {
		this.diseaseCost = diseaseCost;
	}

	public List<Patient> getPatient() {
		return patient;
	}

	public void setPatient(List<Patient> patient) {
		this.patient = patient;
	}

	 

}
