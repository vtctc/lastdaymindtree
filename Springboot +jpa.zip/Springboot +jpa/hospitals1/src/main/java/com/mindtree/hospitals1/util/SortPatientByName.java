package com.mindtree.hospitals1.util;

import java.util.Comparator;

import com.mindtree.hospitals1.dto.PatientDto;

public class SortPatientByName implements Comparator<PatientDto> {

	@Override
	public int compare(PatientDto patient1, PatientDto patient2) {
		return patient1.getPatientName().compareTo(patient2.getPatientName());
	}

	

}
