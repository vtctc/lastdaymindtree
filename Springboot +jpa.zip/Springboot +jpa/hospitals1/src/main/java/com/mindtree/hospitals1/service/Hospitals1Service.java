package com.mindtree.hospitals1.service;

import java.util.List;

import com.mindtree.hospitals1.dto.HospitalDto;
import com.mindtree.hospitals1.dto.PatientDto;
import com.mindtree.hospitals1.entity.Patient;
import com.mindtree.hospitals1.exception.serviceexception.HospitalNotFoundException;
import com.mindtree.hospitals1.exception.serviceexception.Hospitals1ServiceException;

public interface Hospitals1Service {

	String addHospital(HospitalDto hospitalDto) throws Hospitals1ServiceException;

	String addPatientToHospital(PatientDto patientDto, int hospitalId) throws HospitalNotFoundException;

	List<PatientDto> getAllPatientByHospitalId(int hospitalId) throws HospitalNotFoundException;

	List<PatientDto> getAllPatientByHospitalName(String hospitalName) throws HospitalNotFoundException;

	List<PatientDto> getAllPatientForBillingValue();

	String makeAPersonFitById(int patientId);

	String makeAPersonFitByName(String patientName);
	
	double getBillingAmount(Patient patient);

}
