package com.mindtree.hospitals1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Hospitals1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
