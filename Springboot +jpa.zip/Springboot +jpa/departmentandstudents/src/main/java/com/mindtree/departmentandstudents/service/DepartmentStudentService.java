package com.mindtree.departmentandstudents.service;

import com.mindtree.departmentandstudents.entity.Department;

public interface DepartmentStudentService {

	void insertDepartment(Department department);

}
