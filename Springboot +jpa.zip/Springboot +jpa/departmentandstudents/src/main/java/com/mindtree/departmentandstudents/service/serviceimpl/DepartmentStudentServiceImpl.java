package com.mindtree.departmentandstudents.service.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.departmentandstudents.entity.Department;
import com.mindtree.departmentandstudents.repository.DepartmentRepository;
import com.mindtree.departmentandstudents.repository.StudentRepository;
import com.mindtree.departmentandstudents.service.DepartmentStudentService;

@Service
public class DepartmentStudentServiceImpl implements DepartmentStudentService {

	@Autowired
	private StudentRepository studentRepository;
	
	@Autowired
	private DepartmentRepository departmentRepository;

	@Override
	public void insertDepartment(Department department) {
		
		departmentRepository.save(department);
	}
	
	
}
