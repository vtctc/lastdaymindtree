package com.mindtree.departmentandstudents.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.mindtree.departmentandstudents.entity.Department;
import com.mindtree.departmentandstudents.service.DepartmentStudentService;

@Controller
public class DepartmentStudentController {

	@Autowired
	private DepartmentStudentService service;
	
	@GetMapping("/")
	public String homePage() {
		
		return "index";
	}
	
	@GetMapping("/department")
	public String departmentForm() {
		
		return "departmentform";
	}
	
	
	@PostMapping("/insertdepartment")
	public String insertDepartment(Department dept) {
		
		service.insertDepartment(dept);
		return "index";
	}
	
	@GetMapping("/student")
	public String studentForm() {
		
		return "studentform";
	}
	
	
	@GetMapping("/display")
	public String displayDepartmentStudents() {
		
		return "display";
	}
}
