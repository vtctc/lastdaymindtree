package com.mindtree.igmanagement.dto;

import java.util.List;

import com.mindtree.igmanagement.entity.Project;

public class AccountDto {
	
	
	private int accountId;

	private String accountName;

	private double revenue;

	List<ProjectDto> project;

	public AccountDto() {
		super();
	}

	public AccountDto(int accountId, String accountName, double revenue, List<ProjectDto> project) {
		super();
		this.accountId = accountId;
		this.accountName = accountName;
		this.revenue = revenue;
		this.project = project;
	}

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public double getRevenue() {
		return revenue;
	}

	public void setRevenue(double revenue) {
		this.revenue = revenue;
	}

	public List<ProjectDto> getProject() {
		return project;
	}

	public void setProject(List<ProjectDto> project) {
		this.project = project;
	}
	
	

}
