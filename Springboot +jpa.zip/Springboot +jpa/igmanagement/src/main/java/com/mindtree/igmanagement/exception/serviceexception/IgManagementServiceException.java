package com.mindtree.igmanagement.exception.serviceexception;

import com.mindtree.igmanagement.exception.IgManagementException;

public class IgManagementServiceException extends IgManagementException{

	public IgManagementServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IgManagementServiceException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public IgManagementServiceException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public IgManagementServiceException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public IgManagementServiceException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
