package com.mindtree.igmanagement.dto;

public class ProjectDto {
	
	private int projectId;

	private String projectName;

	private int projectRevenueCost;

	private double projectCost;

	public ProjectDto() {
		super();
	}

	public ProjectDto(int projectId, String projectName, int projectRevenueCost, double projectCost) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.projectRevenueCost = projectRevenueCost;
		this.projectCost = projectCost;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public int getProjectRevenueCost() {
		return projectRevenueCost;
	}

	public void setProjectRevenueCost(int projectRevenueCost) {
		this.projectRevenueCost = projectRevenueCost;
	}

	public double getProjectCost() {
		return projectCost;
	}

	public void setProjectCost(double projectCost) {
		this.projectCost = projectCost;
	}
	

}
