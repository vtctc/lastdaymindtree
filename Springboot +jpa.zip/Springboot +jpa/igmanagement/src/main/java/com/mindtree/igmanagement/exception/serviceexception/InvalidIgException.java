package com.mindtree.igmanagement.exception.serviceexception;

public class InvalidIgException extends IgManagementServiceException {

	public InvalidIgException() {
		// TODO Auto-generated constructor stub
	}

	public InvalidIgException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public InvalidIgException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public InvalidIgException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public InvalidIgException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
