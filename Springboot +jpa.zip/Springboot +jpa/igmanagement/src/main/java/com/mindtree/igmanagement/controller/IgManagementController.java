package com.mindtree.igmanagement.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.igmanagement.dto.AccountDto;
import com.mindtree.igmanagement.dto.IgDto;
import com.mindtree.igmanagement.exception.IgManagementException;
import com.mindtree.igmanagement.exception.controllerexception.IgManagementControllerException;
import com.mindtree.igmanagement.exception.serviceexception.IgManagementServiceException;
import com.mindtree.igmanagement.service.IgManagementService;

@RestController
public class IgManagementController {

	@Autowired
	IgManagementService service;

	@PostMapping("/insertIg")
	public ResponseEntity<Map<String, Object>> insertEmployee(@RequestBody IgDto ig) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "insert into ig");
		response.put("Error : ", false);
		response.put("body : ", service.insertIntoIg(ig));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	/**
	 * @param account
	 * @return 
	 * @throws IgManagementControllerException when projects cost is more than account revenue
	 */
	@PostMapping("/insertAccount")
	public ResponseEntity<Map<String, Object>> insertEmployee(@RequestBody AccountDto account)
			throws IgManagementControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "insert into account");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.insertIntoAccount(account));
		} catch (IgManagementServiceException e) {
			throw new IgManagementControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}
	
	@PostMapping("/insertAccount/{igName}")
	public ResponseEntity<Map<String, Object>> insertAccount(@RequestBody AccountDto accounts, @PathVariable String igName) throws IgManagementControllerException 
 {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "insert into ig");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.insertIntoAccount(accounts,igName));
		} catch (IgManagementServiceException e) {
			throw new IgManagementControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}
	

}
