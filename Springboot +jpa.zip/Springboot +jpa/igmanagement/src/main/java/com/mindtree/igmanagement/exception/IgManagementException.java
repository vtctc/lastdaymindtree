package com.mindtree.igmanagement.exception;

public class IgManagementException  extends Exception {

	public IgManagementException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IgManagementException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public IgManagementException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public IgManagementException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public IgManagementException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
