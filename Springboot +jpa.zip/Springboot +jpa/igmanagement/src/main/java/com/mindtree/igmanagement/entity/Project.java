package com.mindtree.igmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Project {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int projectId;

	private String projectName;

	private int projectRevenueCost;

	private double projectCost;

	public Project() {
		super();
	}

	public Project(int projectId, String projectName, int projectRevenueCost, double projectCost) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.projectRevenueCost = projectRevenueCost;
		this.projectCost = projectCost;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public int getProjectRevenueCost() {
		return projectRevenueCost;
	}

	public void setProjectRevenueCost(int projectRevenueCost) {
		this.projectRevenueCost = projectRevenueCost;
	}

	public double getProjectCost() {
		return projectCost;
	}

	public void setProjectCost(double projectCost) {
		this.projectCost = projectCost;
	}

}
