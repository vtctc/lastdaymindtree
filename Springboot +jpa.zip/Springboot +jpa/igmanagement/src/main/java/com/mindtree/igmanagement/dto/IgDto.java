package com.mindtree.igmanagement.dto;

import java.util.List;

public class IgDto {
	
	private int igId;

	private String igName;

	List<AccountDto> account;

	public IgDto() {
		super();
	}

	public IgDto(int igId, String igName, List<AccountDto> account) {
		super();
		this.igId = igId;
		this.igName = igName;
		this.account = account;
	}

	public int getIgId() {
		return igId;
	}

	public void setIgId(int igId) {
		this.igId = igId;
	}

	public String getIgName() {
		return igName;
	}

	public void setIgName(String igName) {
		this.igName = igName;
	}

	public List<AccountDto> getAccount() {
		return account;
	}

	public void setAccount(List<AccountDto> account) {
		this.account = account;
	}

}
