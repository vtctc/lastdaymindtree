package com.mindtree.kalingapremierleague;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HomeserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeserviceApplication.class, args);
	}

}
