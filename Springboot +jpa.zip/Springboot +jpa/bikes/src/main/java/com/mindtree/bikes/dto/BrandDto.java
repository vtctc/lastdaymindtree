package com.mindtree.bikes.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class BrandDto {
private int brandId;
	
	private String brandName;
	
	@JsonIgnoreProperties("brand")
	List<DealerDto> dealer;
	
	@JsonIgnoreProperties("brand")
	List<BikeDto> bike;

	public BrandDto() {
		super();
	}

	public BrandDto(int brandId, String brandName, List<DealerDto> dealer, List<BikeDto> bike) {
		super();
		this.brandId = brandId;
		this.brandName = brandName;
		this.dealer = dealer;
		this.bike = bike;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public List<DealerDto> getDealer() {
		return dealer;
	}

	public void setDealer(List<DealerDto> dealer) {
		this.dealer = dealer;
	}

	public List<BikeDto> getBike() {
		return bike;
	}

	public void setBike(List<BikeDto> bike) {
		this.bike = bike;
	}
	

}
