package com.mindtree.bikes.service.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.bikes.dto.BikeBrandDto;
import com.mindtree.bikes.dto.BikeDto;
import com.mindtree.bikes.dto.BrandDto;
import com.mindtree.bikes.dto.InvestmentDto;
import com.mindtree.bikes.entity.Bike;
import com.mindtree.bikes.entity.Brand;
import com.mindtree.bikes.entity.Dealer;
import com.mindtree.bikes.exception.Serviceexception.BikesServiceException;
import com.mindtree.bikes.exception.Serviceexception.NoSuchBrandIsfound;
import com.mindtree.bikes.exception.Serviceexception.NoSuchDealerIsFound;
import com.mindtree.bikes.repository.BikeRepository;
import com.mindtree.bikes.repository.BrandRepository;
import com.mindtree.bikes.repository.DealerRepository;
import com.mindtree.bikes.service.BikesService;

@Service
public class BikesServiceImpl implements BikesService {

	@Autowired
	BikeRepository bikeRepository;

	@Autowired
	BrandRepository brandRepository;

	@Autowired
	DealerRepository dealerRepository;

	ModelMapper modelMapper = new ModelMapper();

	public BikeDto convertBikeEntityToDto(Bike bike) {
		return modelMapper.map(bike, BikeDto.class);
	}

	@Override
	public BrandDto assignDealer(int brandId, int dealerId) throws BikesServiceException {

		Optional<Brand> brandOptional = brandRepository.findById(brandId);
		try {
			brandOptional.orElseThrow(() -> new NoSuchBrandIsfound("No such brand id is present"));
		} catch (NoSuchBrandIsfound e) {
			throw new BikesServiceException(e.getMessage(), e);
		}
		Optional<Dealer> dealerOptional = dealerRepository.findById(dealerId);
		try {
			dealerOptional.orElseThrow(() -> new NoSuchDealerIsFound("No such dealer id is present"));
		} catch (NoSuchDealerIsFound e) {
			throw new BikesServiceException(e.getMessage(), e);
		}

		Brand brand = brandOptional.get();
		Dealer dealer = dealerOptional.get();

		dealer.setBrand(brand);
		dealerRepository.save(dealer);
		brand = brandRepository.getOne(brandId);

		return modelMapper.map(brand, BrandDto.class);
	}

	@Override
	public List<BikeBrandDto> getHighestPriceBike() {

		List<BikeBrandDto> bikeBrandDto = new ArrayList<BikeBrandDto>();
		List<Brand> brand = brandRepository.findAll();
		for (Brand brnd : brand) {
			List<Bike> bikes = brnd.getBike();
			Optional<Bike> highestbikes = bikes.stream()
					.reduce((b1, b2) -> b1.getBikePrice() > b2.getBikePrice() ? b1 : b2);
			Bike bike = highestbikes.get();
			BikeBrandDto bd = new BikeBrandDto();
			bd.setBrandName(brnd.getBrandName());
			
			bd.setBikeName(bike.getBikeName());
			bd.setBikePrice(bike.getBikePrice());
			bikeBrandDto.add(bd);
		}

		return bikeBrandDto;
	}

	@Override
	public List<BikeDto> getAllBikes(int dealerId) throws BikesServiceException {

		Optional<Dealer> dealer = dealerRepository.findById(dealerId);
		try {
			dealer.orElseThrow(() -> new NoSuchDealerIsFound("no such dealer id is found"));
		} catch (NoSuchDealerIsFound e) {
			throw new BikesServiceException(e.getMessage(), e);
		}

		Dealer dealers = dealer.get();
		Brand brand = dealers.getBrand();

		List<Bike> bike = brand.getBike();

		List<BikeDto> bikeDto = bike.stream().map(dt -> convertBikeEntityToDto(dt)).collect(Collectors.toList());
		Collections.sort(bikeDto);
		return bikeDto;

	}

	@Override
	public List<InvestmentDto> getTotalInvestemnt() {

		List<InvestmentDto> investmentDto = new ArrayList<InvestmentDto>();
		List<Brand> brand = brandRepository.findAll();
		for (Brand br : brand) {
			InvestmentDto id = new InvestmentDto();
			double price = 0;
			for (Bike b : br.getBike()) {
				price = price + b.getBikePrice();
			}
			id.setBrandName(br.getBrandName());
			id.setTotalInvestement(price);
			investmentDto.add(id);
		}
		return investmentDto;
	}

}