package com.mindtree.bikes.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Bike {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int bikeId;
	
	private String bikeName;
	
	private String bikeSpecification;
	
	private double bikePrice;
	
	@ManyToOne(fetch = FetchType.EAGER)
	Brand brand;

	public Bike() {
		super();
	}

	public Bike(int bikeId, String bikeName, String bikeSpecification, double bikePrice, Brand brand) {
		super();
		this.bikeId = bikeId;
		this.bikeName = bikeName;
		this.bikeSpecification = bikeSpecification;
		this.bikePrice = bikePrice;
		this.brand = brand;
	}

	public int getBikeId() {
		return bikeId;
	}

	public void setBikeId(int bikeId) {
		this.bikeId = bikeId;
	}

	public String getBikeName() {
		return bikeName;
	}

	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}

	public String getBikeSpecification() {
		return bikeSpecification;
	}

	public void setBikeSpecification(String bikeSpecification) {
		this.bikeSpecification = bikeSpecification;
	}

	public double getBikePrice() {
		return bikePrice;
	}

	public void setBikePrice(double bikePrice) {
		this.bikePrice = bikePrice;
	}

	public Brand getBrand() {
		return brand;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}
	
	
	
	

}
