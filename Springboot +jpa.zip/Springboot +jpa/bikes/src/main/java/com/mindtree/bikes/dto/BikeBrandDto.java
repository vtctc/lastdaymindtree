package com.mindtree.bikes.dto;

public class BikeBrandDto {

	private String brandName;
	
	private String bikeName;
	
	private double bikePrice;

	public BikeBrandDto() {
		super();
	}

	public BikeBrandDto(String brandName, String bikeName, double bikePrice) {
		super();
		this.brandName = brandName;
		this.bikeName = bikeName;
		this.bikePrice = bikePrice;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getBikeName() {
		return bikeName;
	}

	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}

	public double getBikePrice() {
		return bikePrice;
	}

	public void setBikePrice(double bikePrice) {
		this.bikePrice = bikePrice;
	}
	
}
