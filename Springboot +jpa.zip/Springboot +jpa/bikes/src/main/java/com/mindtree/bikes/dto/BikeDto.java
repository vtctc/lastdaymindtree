package com.mindtree.bikes.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class BikeDto implements Comparable<BikeDto>{
	private int bikeId;
	
	private String bikeName;
	
	private String bikeSpecification;
	
	private double bikePrice;
	
	@JsonIgnoreProperties("bike")
	BrandDto brand;

	public BikeDto() {
		super();
	}

	public BikeDto(int bikeId, String bikeName, String bikeSpecification, double bikePrice, BrandDto brand) {
		super();
		this.bikeId = bikeId;
		this.bikeName = bikeName;
		this.bikeSpecification = bikeSpecification;
		this.bikePrice = bikePrice;
		this.brand = brand;
	}

	public int getBikeId() {
		return bikeId;
	}

	public void setBikeId(int bikeId) {
		this.bikeId = bikeId;
	}

	public String getBikeName() {
		return bikeName;
	}

	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}

	public String getBikeSpecification() {
		return bikeSpecification;
	}

	public void setBikeSpecification(String bikeSpecification) {
		this.bikeSpecification = bikeSpecification;
	}

	public double getBikePrice() {
		return bikePrice;
	}

	public void setBikePrice(double bikePrice) {
		this.bikePrice = bikePrice;
	}

	public BrandDto getBrand() {
		return brand;
	}

	public void setBrand(BrandDto brand) {
		this.brand = brand;
	}

	@Override
	public int compareTo(BikeDto b) {
		
		int sum=Double.compare(this.getBikePrice(), b.getBikePrice());
		if(sum>0)
		{
			return -1;
		}else
			return 1;
	}
	

	 
}
