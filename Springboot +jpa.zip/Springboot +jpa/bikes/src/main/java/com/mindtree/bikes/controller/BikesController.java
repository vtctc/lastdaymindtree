package com.mindtree.bikes.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.bikes.dto.DealerDto;
import com.mindtree.bikes.exception.Serviceexception.BikesServiceException;
import com.mindtree.bikes.exception.controllerexception.BikesControllerException;
import com.mindtree.bikes.service.BikesService;

@RestController
public class BikesController {

	@Autowired
	BikesService service;

	@GetMapping("/assignDealer/{brandId}/{dealerId}")
	public ResponseEntity<Map<String, Object>> assignDealer(@PathVariable int brandId, @PathVariable int dealerId)
			throws BikesControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "assign dealer");
		response.put("Error", false);
		try {
			response.put("body", service.assignDealer(brandId, dealerId));
		} catch (BikesServiceException e) {
			throw new BikesControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/getHighestPriceBike")
	public ResponseEntity<Map<String, Object>> getHighestPriceBike() {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get highest price bike");
		response.put("Error", false);

		response.put("body", service.getHighestPriceBike());

		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/getAllBikes/{dealerId}")
	public ResponseEntity<Map<String, Object>> getAllBikes(@PathVariable int dealerId) throws BikesControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get highest price bike");
		response.put("Error", false);

		try {
			response.put("body", service.getAllBikes(dealerId));
		} catch (BikesServiceException e) {
			 throw new BikesControllerException(e.getMessage(), e);
		}

		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/totalInvestment")
	public ResponseEntity<Map<String, Object>> getTotalInvestemnt() {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get highest price bike");
		response.put("Error", false);

		response.put("body", service.getTotalInvestemnt());

		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

}
