package com.mindtree.bikes.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Brand {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int brandId;
	
	private String brandName;
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "brand")
	List<Dealer> dealer;
	
	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "brand")
	List<Bike> bike;

	public Brand() {
		super();
	}

	public Brand(int brandId, String brandName, List<Dealer> dealer, List<Bike> bike) {
		super();
		this.brandId = brandId;
		this.brandName = brandName;
		this.dealer = dealer;
		this.bike = bike;
	}

	public int getBrandId() {
		return brandId;
	}

	public void setBrandId(int brandId) {
		this.brandId = brandId;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public List<Dealer> getDealer() {
		return dealer;
	}

	public void setDealer(List<Dealer> dealer) {
		this.dealer = dealer;
	}

	public List<Bike> getBike() {
		return bike;
	}

	public void setBike(List<Bike> bike) {
		this.bike = bike;
	}
	
	
	

}
