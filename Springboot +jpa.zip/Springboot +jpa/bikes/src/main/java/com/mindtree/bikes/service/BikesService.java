package com.mindtree.bikes.service;

import java.util.List;

import com.mindtree.bikes.dto.BikeBrandDto;
import com.mindtree.bikes.dto.BikeDto;
import com.mindtree.bikes.dto.BrandDto;
import com.mindtree.bikes.dto.DealerDto;
import com.mindtree.bikes.dto.InvestmentDto;
import com.mindtree.bikes.exception.Serviceexception.BikesServiceException;

public interface BikesService {

    BrandDto assignDealer(int brandId, int dealerId) throws BikesServiceException;

	List<BikeBrandDto> getHighestPriceBike();

	List<BikeDto> getAllBikes(int dealerId) throws BikesServiceException;

	List<InvestmentDto> getTotalInvestemnt();

}
