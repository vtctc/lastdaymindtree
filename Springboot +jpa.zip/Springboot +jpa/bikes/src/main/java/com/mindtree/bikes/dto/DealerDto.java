package com.mindtree.bikes.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class DealerDto {
private int dealerId;
	
	private String dealerName;
	
	private String dealerAddress;
	
	@JsonIgnoreProperties("dealer")
	BrandDto brand;

	public DealerDto() {
		super();
	}

	public DealerDto(int dealerId, String dealerName, String dealerAddress, BrandDto brand) {
		super();
		this.dealerId = dealerId;
		this.dealerName = dealerName;
		this.dealerAddress = dealerAddress;
		this.brand = brand;
	}

	public int getDealerId() {
		return dealerId;
	}

	public void setDealerId(int dealerId) {
		this.dealerId = dealerId;
	}

	public String getDealerName() {
		return dealerName;
	}

	public void setDealerName(String dealerName) {
		this.dealerName = dealerName;
	}

	public String getDealerAddress() {
		return dealerAddress;
	}

	public void setDealerAddress(String dealerAddress) {
		this.dealerAddress = dealerAddress;
	}

	public BrandDto getBrand() {
		return brand;
	}

	public void setBrand(BrandDto brand) {
		this.brand = brand;
	}
	
	
	


}
