package com.mindtree.bikes.exception.Serviceexception;

import com.mindtree.bikes.exception.BikesException;

public class BikesServiceException extends BikesException {

	public BikesServiceException() {
		// TODO Auto-generated constructor stub
	}

	public BikesServiceException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BikesServiceException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public BikesServiceException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public BikesServiceException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
