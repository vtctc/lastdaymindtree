package com.mindtree.bikes.dto;

public class InvestmentDto {
	
	private String brandName;
	
	private double totalInvestement;

	public InvestmentDto() {
		super();
	}

	public InvestmentDto(String brandName, double totalInvestement) {
		super();
		this.brandName = brandName;
		this.totalInvestement = totalInvestement;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public double getTotalInvestement() {
		return totalInvestement;
	}

	public void setTotalInvestement(double totalInvestement) {
		this.totalInvestement = totalInvestement;
	}
	
	

}
