package com.mindtree.bikes.exception.controllerexception;

import com.mindtree.bikes.exception.BikesException;

public class BikesControllerException extends BikesException {

	public BikesControllerException() {
		// TODO Auto-generated constructor stub
	}

	public BikesControllerException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BikesControllerException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public BikesControllerException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public BikesControllerException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
