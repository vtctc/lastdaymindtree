package com.mindtree.bikes.exception;

public class BikesException extends Exception {

	public BikesException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BikesException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BikesException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public BikesException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public BikesException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	

}
