package com.mindtree.gooddeed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GooddeedApplicationTests {

	@Test
	void contextLoads() {
	}

}
