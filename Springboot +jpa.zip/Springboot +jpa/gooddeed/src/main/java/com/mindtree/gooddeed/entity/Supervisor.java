package com.mindtree.gooddeed.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Supervisor {

	
	@Id
	private int supervisorId;
	private String supervisorName;
	
	
	@OneToOne
	GoodDeed goodDeed;


	public int getSupervisorId() {
		return supervisorId;
	}


	public void setSupervisorId(int supervisorId) {
		this.supervisorId = supervisorId;
	}


	public String getSupervisorName() {
		return supervisorName;
	}


	public void setSupervisorName(String supervisorName) {
		this.supervisorName = supervisorName;
	}


	public GoodDeed getGoodDeed() {
		return goodDeed;
	}


	public void setGoodDeed(GoodDeed goodDeed) {
		this.goodDeed = goodDeed;
	}


	public Supervisor(int supervisorId, String supervisorName, GoodDeed goodDeed) {
		super();
		this.supervisorId = supervisorId;
		this.supervisorName = supervisorName;
		this.goodDeed = goodDeed;
	}


	public Supervisor() {
		super();
	}
	
	
	
	
}
