package com.mindtree.gooddeed.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.mindtree.gooddeed.entity.CampusMind;
import com.mindtree.gooddeed.entity.Supervisor;
@JsonInclude(Include.NON_NULL)
public class GoodDeedDto {
	

	private int goodDeedId;
	private String goodDeedName;
	
	//@JsonIgnoreProperties("goodDeedDto")
	SupervisorDto supervisorDto;
	
	//@JsonIgnoreProperties(" goodDeedDto")
	List<CampusMindDto> campusMindDto;

	public int getGoodDeedId() {
		return goodDeedId;
	}

	public void setGoodDeedId(int goodDeedId) {
		this.goodDeedId = goodDeedId;
	}

	public String getGoodDeedName() {
		return goodDeedName;
	}

	public void setGoodDeedName(String goodDeedName) {
		this.goodDeedName = goodDeedName;
	}

	public SupervisorDto getSupervisorDto() {
		return supervisorDto;
	}

	public void setSupervisorDto(SupervisorDto supervisorDto) {
		this.supervisorDto = supervisorDto;
	}

	public List<CampusMindDto> getCampusMindDto() {
		return campusMindDto;
	}

	public void setCampusMindDto(List<CampusMindDto> campusMindDto) {
		this.campusMindDto = campusMindDto;
	}

	public GoodDeedDto(int goodDeedId, String goodDeedName, SupervisorDto supervisorDto,
			List<CampusMindDto> campusMindDto) {
		super();
		this.goodDeedId = goodDeedId;
		this.goodDeedName = goodDeedName;
		this.supervisorDto = supervisorDto;
		this.campusMindDto = campusMindDto;
	}

	public GoodDeedDto() {
		super();
	}

	@Override
	public String toString() {
		return "GoodDeedDto [goodDeedId=" + goodDeedId + ", goodDeedName=" + goodDeedName + ", supervisorDto="
				+ supervisorDto + ", campusMindDto=" + campusMindDto + "]";
	}

	
 
	
	

}
