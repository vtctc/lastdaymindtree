package com.mindtree.gooddeed.dto;

 

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class SupervisorDto {


	private int supervisorId;
	private String supervisorName;
	
	//@JsonIgnoreProperties("supervisorDto")
	GoodDeedDto goodDeedDto;


	public int getSupervisorId() {
		return supervisorId;
	}


	public void setSupervisorId(int supervisorId) {
		this.supervisorId = supervisorId;
	}


	public String getSupervisorName() {
		return supervisorName;
	}


	public void setSupervisorName(String supervisorName) {
		this.supervisorName = supervisorName;
	}


	public GoodDeedDto getGoodDeedDto() {
		return goodDeedDto;
	}


	public void setGoodDeedDto(GoodDeedDto goodDeedDto) {
		this.goodDeedDto = goodDeedDto;
	}


	public SupervisorDto(int supervisorId, String supervisorName, GoodDeedDto goodDeedDto) {
		super();
		this.supervisorId = supervisorId;
		this.supervisorName = supervisorName;
		this.goodDeedDto = goodDeedDto;
	}


	public SupervisorDto() {
		super();
	}
	

 
	
}
