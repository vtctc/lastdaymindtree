 package com.mindtree.gooddeed.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.gooddeed.dto.CampusMindDto;
import com.mindtree.gooddeed.dto.GoodDeedDto;
import com.mindtree.gooddeed.dto.SupervisorDto;
import com.mindtree.gooddeed.entity.CampusMind;
import com.mindtree.gooddeed.entity.GoodDeed;
import com.mindtree.gooddeed.entity.Supervisor;
import com.mindtree.gooddeed.repository.CampusMindRepository;
import com.mindtree.gooddeed.repository.GoodDeedRepository;
import com.mindtree.gooddeed.repository.SupervisorRepository;
import com.mindtree.gooddeed.service.GoodDeedService;



@Service
public class GoodDeedServiceImpl implements GoodDeedService{
	
	@Autowired
	CampusMindRepository campusRepo;
	
	
	@Autowired
	GoodDeedRepository goodDeedRepo;
	
	@Autowired
	SupervisorRepository supervisorRepo;

	@Override
	public String assignGoodDeed(CampusMindDto campusMindDto) {
		 
		 
		 System.out.println(campusMindDto.toString());
		 System.out.println(campusMindDto.getGoodDeedDto().toString());
		
		 
		 
		GoodDeed goodDeed=new GoodDeed(campusMindDto.getGoodDeedDto().getGoodDeedId(),campusMindDto.getGoodDeedDto().getGoodDeedName(),null,null);
		Supervisor supervisor=new Supervisor(campusMindDto.getGoodDeedDto().getSupervisorDto().getSupervisorId(),campusMindDto.getGoodDeedDto().getSupervisorDto().getSupervisorName(),goodDeed);
		CampusMind campuse=new CampusMind(campusMindDto.getMid(),campusMindDto.getName(),goodDeed);
		goodDeedRepo.save(goodDeed);
		supervisorRepo.save(supervisor);
		campusRepo.save(campuse);
		
		
		
		return "inserted";
	}

	@Override
	public List<CampusMindDto> getdetails(int id) {
	 
		GoodDeed gooddeed=goodDeedRepo.getOne(id);
		
		List<CampusMindDto> campusdto=new ArrayList<CampusMindDto>();
		for (CampusMind campusMind : gooddeed.getCampusMind()) 
		{
			CampusMindDto campusmindsto=new CampusMindDto();
		    campusmindsto.setMid(campusMind.getMid());
		    campusmindsto.setName(campusMind.getName());
		    campusdto.add(campusmindsto);
		    
		}
		return campusdto;
	}

	@Override
	public List<GoodDeedDto> getdetails() {
		
		 List<GoodDeed> goodD=new  ArrayList<GoodDeed>();
		 List<GoodDeedDto> goodDeeddto=new ArrayList<GoodDeedDto>();
		 
		   goodD=goodDeedRepo.findAll();
		   for (GoodDeed goodDeeds : goodD) {
			   if(goodDeeds.getCampusMind().size()<3)
			   {
				   GoodDeedDto goodeeddto=new GoodDeedDto();
				   goodeeddto.setGoodDeedId(goodDeeds.getGoodDeedId());
				   goodeeddto.setGoodDeedName(goodDeeds.getGoodDeedName());
				   goodDeeddto.add(goodeeddto);
			   }
			 
		}
		 return  goodDeeddto;
	}

	@Override
	public SupervisorDto getdata(int id) {
		
		Supervisor supervisor=supervisorRepo.getOne(id);
		
		List<CampusMindDto> campusMinddto=new ArrayList<CampusMindDto>();
		
		List<CampusMind> campusMind=supervisor.getGoodDeed().getCampusMind();
		
		 for (CampusMind campusMind2 : campusMind) {
			 CampusMindDto campusdto=new CampusMindDto(campusMind2.getMid(),campusMind2.getName(),null);
			 campusMinddto.add(campusdto);
		}
		 GoodDeedDto goodDeeddto=new GoodDeedDto(supervisor.getGoodDeed().getGoodDeedId(),supervisor.getGoodDeed().getGoodDeedName(),null,campusMinddto);
		
		 SupervisorDto supervisordto=new SupervisorDto(supervisor.getSupervisorId(),supervisor.getSupervisorName(),goodDeeddto);
		 
		 return supervisordto;
		
	}

	
	 
	

}
