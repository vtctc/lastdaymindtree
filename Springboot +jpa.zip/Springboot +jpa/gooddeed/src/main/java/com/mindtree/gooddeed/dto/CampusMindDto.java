package com.mindtree.gooddeed.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
@JsonInclude(Include.NON_NULL)
public class CampusMindDto {
	
	private int mid;
	private String name;
	
	
	//@JsonIgnoreProperties("campusMindDto")
	GoodDeedDto goodDeedDto;



	public CampusMindDto(int mid, String name, GoodDeedDto goodDeedDto) {
		super();
		this.mid = mid;
		this.name = name;
		this.goodDeedDto = goodDeedDto;
	}



	public CampusMindDto() {
		super();
	}



	public int getMid() {
		return mid;
	}



	public void setMid(int mid) {
		this.mid = mid;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public GoodDeedDto getGoodDeedDto() {
		return goodDeedDto;
	}



	public void setGoodDeedDto(GoodDeedDto goodDeedDto) {
		this.goodDeedDto = goodDeedDto;
	}



	@Override
	public String toString() {
		return "CampusMindDto [mid=" + mid + ", name=" + name + ", goodDeedDto=" + goodDeedDto + "]";
	}

	
	 

}
