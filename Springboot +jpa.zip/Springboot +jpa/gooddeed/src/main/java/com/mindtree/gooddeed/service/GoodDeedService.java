package com.mindtree.gooddeed.service;

import java.util.List;

import com.mindtree.gooddeed.dto.CampusMindDto;
import com.mindtree.gooddeed.dto.GoodDeedDto;
import com.mindtree.gooddeed.dto.SupervisorDto;
import com.mindtree.gooddeed.entity.Supervisor;

public interface GoodDeedService {

	 

	String assignGoodDeed(CampusMindDto campusMindDto);

	List<CampusMindDto> getdetails(int id);

	List<GoodDeedDto> getdetails();

	SupervisorDto getdata(int id);

}
