package com.mindtree.gooddeed.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.gooddeed.dto.CampusMindDto;
import com.mindtree.gooddeed.dto.GoodDeedDto;
import com.mindtree.gooddeed.dto.SupervisorDto;
import com.mindtree.gooddeed.entity.GoodDeed;
import com.mindtree.gooddeed.entity.Supervisor;
import com.mindtree.gooddeed.service.GoodDeedService;

@RestController
public class Controller {
	
	@Autowired
	GoodDeedService goodDeedService;
	
	 
//	@PostMapping("/assignaGoodDeed/{id}")
//	public void assignGoodDeed(@PathVariable int id,@RequestBody CampusMindDto campusMind )
//	{
//		CampusMind campusmind=goodDeedService.assignToGoodDeed(campusMind);
//		
//		CampusMindDto campusdto=new CampusMindDto();
//		 campusdto.setMid(campusmind.getMid());
//		 campusdto.setName(campusmind.getName());
//		 campusdto.setGoodDeed(campusmind.getGoodDeed());
//		 
		
	@PostMapping("/posting")
	public String assignGoodDeedToCampusMind(@RequestBody CampusMindDto campusMindDto)
	{
		
		System.out.println(campusMindDto.toString());
		 System.out.println(campusMindDto.getGoodDeedDto().toString());
		String s=goodDeedService.assignGoodDeed(campusMindDto);
	
     return s;
		
	}
	
	 @GetMapping("/get/{id}")
	 public List<CampusMindDto> getdetails(@PathVariable int id)
	 {
		 
		 List<CampusMindDto> camp=goodDeedService.getdetails(id);
		return  camp;
		 
		 
	 }
	 
	 @GetMapping("/getdeed")
	 public List<GoodDeedDto> getdetails()
	 {
		 List<GoodDeedDto> goodDeed=goodDeedService.getdetails();
				 return goodDeed;
	 }
	 
	 
	 
	 @GetMapping("/getdetails/{id}")
	 public  SupervisorDto getdata(@PathVariable int id)
	 {
		 SupervisorDto supervisor=goodDeedService.getdata(id);
		 return supervisor;
	 }

}
