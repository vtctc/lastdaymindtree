package com.mindtree.flight.exception.controllerexception;

import com.mindtree.flight.exception.FlightException;

public class FlightControllerException extends FlightException {

	public FlightControllerException() {
		// TODO Auto-generated constructor stub
	}

	public FlightControllerException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public FlightControllerException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public FlightControllerException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public FlightControllerException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
