package com.mindtree.flight.service;

import java.util.List;

import com.mindtree.flight.dto.FlightDto;
import com.mindtree.flight.dto.PassengerDto;
import com.mindtree.flight.exception.serviceException.FlightServiceException;

public interface FlightService {

	String insertPassenger(PassengerDto passenger, int flightId);

	List<FlightDto> getAllFlight();

	List<PassengerDto> getAllPasseger(String flightName) throws FlightServiceException;

}
