package com.mindtree.flight.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class FlightDto {
	
	private int flightId;
	private String flightName;
	
	@JsonIgnoreProperties("flight")
	List<PassengerDto> passenger;

	public FlightDto() {
		super();
	}

	public FlightDto(int flightId, String flightName, List<PassengerDto> passenger) {
		super();
		this.flightId = flightId;
		this.flightName = flightName;
		this.passenger = passenger;
	}

	public int getFlightId() {
		return flightId;
	}

	public void setFlightId(int flightId) {
		this.flightId = flightId;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public List<PassengerDto> getPassenger() {
		return passenger;
	}

	public void setPassenger(List<PassengerDto> passenger) {
		this.passenger = passenger;
	}
	
	

}
