package com.mindtree.flight.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.flight.dto.PassengerDto;
import com.mindtree.flight.exception.controllerexception.FlightControllerException;
import com.mindtree.flight.exception.serviceException.FlightServiceException;
import com.mindtree.flight.service.FlightService;

@CrossOrigin
@RestController
public class FlightController {

	@Autowired
	FlightService service;

	@PostMapping("/insertPassenger/{flightId}")
	public ResponseEntity<Map<String, Object>> insertPassenger(@RequestBody PassengerDto passenger,
			@PathVariable int flightId) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "inserted into passenger");
		response.put("Error : ", false);
		response.put("body ", service.insertPassenger(passenger, flightId));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/getAllFlight")
	public ResponseEntity<Map<String, Object>> getAllFlight() {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all flight");
		response.put("Error : ", false);
		response.put("body", service.getAllFlight());
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/getAllPasseger/{flightName}")
	public ResponseEntity<Map<String, Object>> getAllPasseger(@PathVariable String flightName)
			throws FlightControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all passenger");
		response.put("Error : ", false);
		try {
			response.put("body", service.getAllPasseger(flightName));
		} catch (FlightServiceException e) {
			throw new FlightControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

}
