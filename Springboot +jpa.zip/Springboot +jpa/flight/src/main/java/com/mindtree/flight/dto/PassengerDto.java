package com.mindtree.flight.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.flight.entity.Flight;

public class PassengerDto {
	
	private int passengerId;
	private String passengerName;
	private int passengerAge;
	
	@JsonIgnoreProperties("passenger")
	Flight flight;

	public PassengerDto() {
		super();
	}

	public PassengerDto(int passengerId, String passengerName, int passengerAge, Flight flight) {
		super();
		this.passengerId = passengerId;
		this.passengerName = passengerName;
		this.passengerAge = passengerAge;
		this.flight = flight;
	}

	public int getPassengerId() {
		return passengerId;
	}

	public void setPassengerId(int passengerId) {
		this.passengerId = passengerId;
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getPassengerAge() {
		return passengerAge;
	}

	public void setPassengerAge(int passengerAge) {
		this.passengerAge = passengerAge;
	}

	public Flight getFlight() {
		return flight;
	}

	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	


}
