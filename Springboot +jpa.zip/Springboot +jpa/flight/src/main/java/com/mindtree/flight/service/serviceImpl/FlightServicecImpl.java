package com.mindtree.flight.service.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.flight.dto.FlightDto;
import com.mindtree.flight.dto.PassengerDto;
import com.mindtree.flight.entity.Flight;
import com.mindtree.flight.entity.Passenger;
import com.mindtree.flight.exception.serviceException.FlightServiceException;
import com.mindtree.flight.exception.serviceException.NoSuchFlightExist;
import com.mindtree.flight.repository.FlightRepository;
import com.mindtree.flight.repository.PassengerRepository;
import com.mindtree.flight.service.FlightService;
 
@Service
public class FlightServicecImpl implements FlightService {

	ModelMapper modelMapper = new ModelMapper();

	@Autowired
	private FlightRepository flightRepository;

	@Autowired
	private PassengerRepository passengerRepository;

	@Override
	public String insertPassenger(PassengerDto passenger, int flightId) {

		Flight flight = flightRepository.findById(flightId).get();
		Passenger passengersEntity = modelMapper.map(passenger, Passenger.class);

		List<Passenger> passengerList = new ArrayList<Passenger>();
		passengerList.add(passengersEntity);
		if (flight.getPassenger() == null) {
			flight.setPassenger(passengerList);
		} else {
			flight.getPassenger().add(passengersEntity);
		}
		passengersEntity.setFlight(flight);
		passengerRepository.save(passengersEntity);

		return "inserted successfully";
	}

	@Override
	public List<FlightDto> getAllFlight() {

		List<Flight> flight = flightRepository.findAll();
		List<FlightDto> flights = new ArrayList<FlightDto>();
		flight.forEach(fligh -> flights.add(modelMapper.map(fligh, FlightDto.class)));
		return flights;
	}

	@Override
	public List<PassengerDto> getAllPasseger(String flightName) throws FlightServiceException {

		Optional<Flight> flightOptional = flightRepository.findByflightName(flightName);

		try {
			flightOptional.orElseThrow(() -> new NoSuchFlightExist("No such Flight name exist"));
		} catch (NoSuchFlightExist e) {
			throw new FlightServiceException(e.getMessage(), e);
		}

		Flight flight = flightOptional.get();

		List<Passenger> passengerList = flight.getPassenger();
		List<PassengerDto> passengerDto = passengerList.stream().map(dt -> modelMapper.map(dt, PassengerDto.class))
				.collect(Collectors.toList());

		return passengerDto;
	}

}
