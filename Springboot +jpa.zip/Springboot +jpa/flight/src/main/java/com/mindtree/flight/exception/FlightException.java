package com.mindtree.flight.exception;

public class FlightException extends Exception {

	public FlightException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FlightException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public FlightException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public FlightException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public FlightException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
