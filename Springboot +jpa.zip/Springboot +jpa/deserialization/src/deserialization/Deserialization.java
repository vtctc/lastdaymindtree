package deserialization;

public class Deserialization {

	 
	
}
