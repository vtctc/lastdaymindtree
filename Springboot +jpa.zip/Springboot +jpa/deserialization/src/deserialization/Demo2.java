package deserialization;

import java.io.Serializable;

public class Demo2 implements Serializable {
	
	private int id;
	
	private String name;

	public Demo2() {
		super();
	}

	public Demo2(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	
	

}
