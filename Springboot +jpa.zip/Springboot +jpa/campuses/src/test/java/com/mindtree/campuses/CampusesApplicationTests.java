package com.mindtree.campuses;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusesApplicationTests {

	@Test
	void contextLoads() {
	}

}
