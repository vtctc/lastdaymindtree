package com.mindtree.campuses.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mindtree.campuses.entity.CampusMind;

public interface CampusMindRepost extends JpaRepository<CampusMind, Integer>{

}
