package com.mindtree.campuses.service.serviceimpl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.campuses.entity.CampusMind;
import com.mindtree.campuses.repository.CampusMindRepost;
import com.mindtree.campuses.repository.LaptopRepost;
import com.mindtree.campuses.service.ServiceInterface;
@Service
public class ServiceImpl implements ServiceInterface{
	@Autowired
	CampusMindRepost campMindRept;
	
	@Autowired
	LaptopRepost LtpRept;

	@Override
	public void insertIntoDb(CampusMind camp) {
		 campMindRept.save(camp);
		
	}

	@Override
	public CampusMind getdetails(int mid) {
		
		CampusMind camp=campMindRept.getOne(mid);
		 
		return camp;
	}
	

	
	

}
