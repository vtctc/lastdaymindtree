package com.mindtree.campuses.service;

import com.mindtree.campuses.entity.CampusMind;

public interface ServiceInterface {

	void insertIntoDb(CampusMind camp);

	CampusMind getdetails(int mid);

}
