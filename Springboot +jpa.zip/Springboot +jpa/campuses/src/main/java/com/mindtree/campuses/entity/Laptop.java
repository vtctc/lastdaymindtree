package com.mindtree.campuses.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Laptop {
	@Id
	private int laptopId;
	private String laptopBrand;
	public int getLaptopId() {
		return laptopId;
	}
	public void setLaptopId(int laptopId) {
		this.laptopId = laptopId;
	}
	public String getLaptopBrand() {
		return laptopBrand;
	}
	public void setLaptopBrand(String laptopBrand) {
		this.laptopBrand = laptopBrand;
	}
	public Laptop() {
		super();
	}
	public Laptop(int laptopId, String laptopBrand) {
		super();
		this.laptopId = laptopId;
		this.laptopBrand = laptopBrand;
	}
	
	
	

}
