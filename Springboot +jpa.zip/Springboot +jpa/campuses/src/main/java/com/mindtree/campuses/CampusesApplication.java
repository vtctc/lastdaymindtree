package com.mindtree.campuses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CampusesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CampusesApplication.class, args);
	}

}
