package com.mindtree.campuses.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.campuses.entity.CampusMind;
import com.mindtree.campuses.service.ServiceInterface;

@RestController
public class CampusController {
	
	@Autowired
	ServiceInterface serviceInt;
	
	@PostMapping("/insertdetails")
	public void insertIntoDb(@RequestBody CampusMind Camp )
	{
		serviceInt.insertIntoDb(Camp);
		
	}
	@GetMapping("/getdetails/{mid}")
	public CampusMind getmsg(@PathVariable int mid )
	{  
		CampusMind campid=serviceInt.getdetails(mid);
		return campid;
		
	}
	

}
