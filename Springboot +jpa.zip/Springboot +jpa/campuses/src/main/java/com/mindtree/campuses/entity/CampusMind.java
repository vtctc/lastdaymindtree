package com.mindtree.campuses.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class CampusMind {
	@Id
	private int mId;
	private String mName;
	private String mCity;
	@OneToOne
	Laptop lpt;

	public int getmId() {
		return mId;
	}

	public void setmId(int mId) {
		this.mId = mId;
	}

	public String getmName() {
		return mName;
	}

	public void setmName(String mName) {
		this.mName = mName;
	}

	public String getmCity() {
		return mCity;
	}

	public void setmCity(String mCity) {
		this.mCity = mCity;
	}

	public Laptop getLpt() {
		return lpt;
	}

	public void setLpt(Laptop lpt) {
		this.lpt = lpt;
	}

	public CampusMind(int mId, String mName, String mCity, Laptop lpt) {
		super();
		this.mId = mId;
		this.mName = mName;
		this.mCity = mCity;
		this.lpt = lpt;
	}

	public CampusMind() {
		super();
	}

}
