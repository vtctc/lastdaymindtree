package com.mindtree.hospital.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.hospital.entity.Doctor;
import com.mindtree.hospital.entity.Patient;
import com.mindtree.hospital.repository.DoctorRepository;
import com.mindtree.hospital.repository.PatientRepository;
import com.mindtree.hospital.service.HospitalService;

@Service
public class HospitalServiceImpl implements HospitalService {

	@Autowired
	DoctorRepository doctorRepository;

	@Autowired
	PatientRepository patientRepository;

	@Override
	public String insertIntoPatient(Patient patient, int id) {
		 
		Doctor doctor=doctorRepository.findById(id).get();
		  
		List<Patient> patients=new ArrayList<Patient>();
		
		patients.add(patient);
		
		if(doctor.getPatient()==null)
		{
		   doctor.setPatient(patients);
		}
		else
		{
			doctor.getPatient().add(patient);
		}
		patient.setDoctor(doctor);
		
		patientRepository.save(patient);
		
		return "inserted successfully";
	}

	 

}
