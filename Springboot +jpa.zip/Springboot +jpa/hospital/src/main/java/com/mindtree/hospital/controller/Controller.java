package com.mindtree.hospital.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.hospital.entity.Patient;
import com.mindtree.hospital.service.HospitalService;

@RestController
@CrossOrigin
public class Controller {
	
	
	@Autowired
	HospitalService service;
	 
	
	 @PostMapping("insertPatient/{id}")
	 public String insertPatient(@RequestBody Patient patient,@PathVariable int id)
	 {
		 String submitMessage=service.insertIntoPatient(patient,id);
		 
		 return submitMessage;
	 }
	
	  
}
