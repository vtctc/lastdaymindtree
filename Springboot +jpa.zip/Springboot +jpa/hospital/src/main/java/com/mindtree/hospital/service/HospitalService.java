package com.mindtree.hospital.service;

import java.util.List;

import com.mindtree.hospital.entity.Doctor;
import com.mindtree.hospital.entity.Patient;

public interface HospitalService {

	String insertIntoPatient(Patient patient, int id);
 
}
