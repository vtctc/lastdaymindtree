package com.mindtree.hsptlangular.exception;

public class HsptlAngularException extends Exception {
 
	public HsptlAngularException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public HsptlAngularException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public HsptlAngularException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public HsptlAngularException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
