package com.mindtree.hsptlangular.exception.controllerexception;

import com.mindtree.hsptlangular.exception.HsptlAngularException;

public class HsptlAngularControllerException extends HsptlAngularException {

	public HsptlAngularControllerException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public HsptlAngularControllerException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public HsptlAngularControllerException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public HsptlAngularControllerException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
