package com.mindtree.hsptlangular.service;

import java.util.List;

import com.mindtree.hsptlangular.dto.HospitalDto;
import com.mindtree.hsptlangular.dto.PatientDto;
import com.mindtree.hsptlangular.exception.controllerexception.HsptlAngularControllerException;
import com.mindtree.hsptlangular.exception.sreviceexception.HsptlAngularServiceException;
import com.mindtree.hsptlangular.exception.sreviceexception.NoSuchHospitalIdIsFound;
import com.mindtree.hsptlangular.exception.sreviceexception.NoSuchPatientIdIsFound;

public interface HsptlAngularService {

	PatientDto addPatient(int hospitalId, PatientDto patient) throws HsptlAngularServiceException;

	List<HospitalDto> getHospital();

	PatientDto updatePatient(int patientId, PatientDto patient) throws HsptlAngularServiceException;

	PatientDto deletePatient(int patientId) throws   HsptlAngularServiceException;

	HospitalDto getHospitalbyid(int hospitalid);

}
