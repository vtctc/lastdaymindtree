package com.mindtree.hsptlangular.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.hsptlangular.dto.HospitalDto;
import com.mindtree.hsptlangular.dto.PatientDto;
import com.mindtree.hsptlangular.entity.Hospital;
import com.mindtree.hsptlangular.entity.Patient;
import com.mindtree.hsptlangular.exception.controllerexception.HsptlAngularControllerException;
import com.mindtree.hsptlangular.exception.sreviceexception.HsptlAngularServiceException;
import com.mindtree.hsptlangular.exception.sreviceexception.NoSuchHospitalIdIsFound;
import com.mindtree.hsptlangular.exception.sreviceexception.NoSuchPatientIdIsFound;
import com.mindtree.hsptlangular.repository.HospitalRepository;
import com.mindtree.hsptlangular.repository.PatientRepository;
import com.mindtree.hsptlangular.service.HsptlAngularService;

@Service
public class HsptlAngularServiceImpl implements HsptlAngularService {

	@Autowired
	HospitalRepository hospitalRepository;

	@Autowired
	PatientRepository patientRepository;

	ModelMapper modelMapper = new ModelMapper();

	public HospitalDto convertHospitalEntityToDto(Hospital hospital) {
		return modelMapper.map(hospital, HospitalDto.class);
	}

	public PatientDto convertPatientEntityToDto(Patient patient) {
		return modelMapper.map(patient, PatientDto.class);
	}

	@Override
	public PatientDto addPatient(int hospitalId, PatientDto patient) throws HsptlAngularServiceException {

		Optional<Hospital> hospital = hospitalRepository.findById(hospitalId);
		try {
			hospital.orElseThrow(() -> new NoSuchHospitalIdIsFound("No such hospital id is present"));
		} catch (NoSuchHospitalIdIsFound e) {
			throw new HsptlAngularServiceException(e.getMessage(), e);
		}

		Hospital hospitals = hospital.get();
		Patient patients = modelMapper.map(patient, Patient.class);
		patients.setHospital(hospitals);

		Patient p = patientRepository.save(patients);

		return modelMapper.map(p, PatientDto.class);
	}

	@Override
	public List<HospitalDto> getHospital() {

		List<Hospital> hospitals = hospitalRepository.findAll();

		List<HospitalDto> hospitalDto = new ArrayList<HospitalDto>();
		hospitals.forEach(h -> hospitalDto.add(modelMapper.map(h, HospitalDto.class)));

		return hospitalDto;
	}

	@Override
	public PatientDto updatePatient(int patientId, PatientDto patient) throws HsptlAngularServiceException {

		Optional<Patient> patients = patientRepository.findById(patientId);
		try {
			patients.orElseThrow(() -> new NoSuchHospitalIdIsFound("no such patient id is found"));
		} catch (NoSuchHospitalIdIsFound e) {
			throw new HsptlAngularServiceException(e.getMessage(), e);
		}
		Patient patientss = patients.get();
		Patient pt = modelMapper.map(patient, Patient.class);
		pt.setPatientId(patientId);
		pt.setHospital(patientss.getHospital());
		Patient ptss = patientRepository.save(pt);
		return modelMapper.map(ptss, PatientDto.class);
	}

	@Override
	public PatientDto deletePatient(int patientId) throws HsptlAngularServiceException {

		patientRepository.findById(patientId)
				.orElseThrow(() -> new NoSuchPatientIdIsFound("no such patient id is found"));
		patientRepository.deleteById(patientId);
		return modelMapper.map(patientRepository.findById(patientId), PatientDto.class);
	}

	@Override
	public HospitalDto getHospitalbyid(int hospitalid) {

		Hospital hospital = hospitalRepository.findById(hospitalid).get();

		return modelMapper.map(hospital, HospitalDto.class);
	}

}
