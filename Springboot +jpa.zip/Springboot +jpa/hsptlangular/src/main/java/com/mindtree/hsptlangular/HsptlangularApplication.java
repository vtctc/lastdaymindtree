package com.mindtree.hsptlangular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HsptlangularApplication {

	public static void main(String[] args) {
		SpringApplication.run(HsptlangularApplication.class, args);
	}

}
