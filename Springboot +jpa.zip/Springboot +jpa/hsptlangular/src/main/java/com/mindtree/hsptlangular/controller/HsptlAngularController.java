package com.mindtree.hsptlangular.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.hsptlangular.dto.PatientDto;
import com.mindtree.hsptlangular.exception.controllerexception.HsptlAngularControllerException;
import com.mindtree.hsptlangular.exception.sreviceexception.HsptlAngularServiceException;
import com.mindtree.hsptlangular.service.HsptlAngularService;
@CrossOrigin
@RestController
public class HsptlAngularController {
	
	@Autowired
	HsptlAngularService service;
	

	@PostMapping("/addPatient/{hospitalId}")
	public ResponseEntity<Map<String, Object>> addPatient(@PathVariable int hospitalId,@RequestBody PatientDto patient)  throws HsptlAngularControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		try {
			response.put("Headers : ", "Add patient");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		response.put("Error : ", false);
		try {
			response.put("body : ", service.addPatient(hospitalId,patient));
		} catch (HsptlAngularServiceException e) {
			 throw new HsptlAngularControllerException(e.getMessage(),e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}
	 @GetMapping("/getAllHospitalName")
	    public ResponseEntity<Map<String, Object>> getHospital() {
			Map<String, Object> response = new HashMap<String, Object>();

			response.put("Headers : ", "get all hospital name");
			response.put("Error", false);
			response.put("body", service.getHospital());
			response.put("Http Status : ", HttpStatus.OK);

			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

		}
	 @PutMapping("/updatePatient/{patientId}")
	    public ResponseEntity<Map<String, Object>> updatePatient(@PathVariable int patientId,@RequestBody PatientDto patient) throws HsptlAngularControllerException {
			Map<String, Object> response = new HashMap<String, Object>();

			response.put("Headers : ", "update patient");
			response.put("Error : ", false);
			try {
				response.put("body : ", service.updatePatient(patientId,patient));
			} catch (HsptlAngularServiceException e) {
				throw new HsptlAngularControllerException(e.getMessage(),e);
			}
			response.put("Http Status : ", HttpStatus.OK);

			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

		}
	 @DeleteMapping("/deletePatient/{PatientId}")
	 public ResponseEntity<Map<String, Object>> deletePatient(@PathVariable int PatientId) throws HsptlAngularControllerException {
			Map<String, Object> response = new HashMap<String, Object>();

			response.put("Headers : ", "delete patient");
			response.put("Error : ", false);
			try {
				response.put("body : ", service.deletePatient(PatientId));
			} catch (HsptlAngularServiceException e) {
				throw new HsptlAngularControllerException(e.getMessage(),e);
			}
			response.put("Http Status : ", HttpStatus.OK);

			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

		}
	 @GetMapping("/getHospitalById/{hospitalid}")
	    public ResponseEntity<Map<String, Object>> getHospitalbyid(@PathVariable int hospitalid) {
			Map<String, Object> response = new HashMap<String, Object>();

			response.put("Headers : ", "get all hospital by id");
			response.put("Error", false);
			response.put("body", service.getHospitalbyid(hospitalid));
			response.put("Http Status : ", HttpStatus.OK);

			return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

		}


}
