package com.mindtree.hsptlangular;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HsptlangularApplicationTests {

	@Test
	void contextLoads() {
	}

}
