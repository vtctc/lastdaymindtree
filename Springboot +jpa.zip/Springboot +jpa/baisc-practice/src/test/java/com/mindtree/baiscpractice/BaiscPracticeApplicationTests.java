package com.mindtree.baiscpractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaiscPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
