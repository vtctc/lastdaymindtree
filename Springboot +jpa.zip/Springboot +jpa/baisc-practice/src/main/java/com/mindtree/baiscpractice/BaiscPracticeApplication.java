package com.mindtree.baiscpractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BaiscPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(BaiscPracticeApplication.class, args);
	}

}
