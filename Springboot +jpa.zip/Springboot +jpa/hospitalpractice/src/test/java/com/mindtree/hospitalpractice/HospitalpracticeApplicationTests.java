package com.mindtree.hospitalpractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HospitalpracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
