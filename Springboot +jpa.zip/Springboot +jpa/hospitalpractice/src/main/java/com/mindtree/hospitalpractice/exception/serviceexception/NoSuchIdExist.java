package com.mindtree.hospitalpractice.exception.serviceexception;

public class NoSuchIdExist extends HospitalPracticeServiceException{

	public NoSuchIdExist() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchIdExist(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public NoSuchIdExist(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchIdExist(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public NoSuchIdExist(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
