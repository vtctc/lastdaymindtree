package com.mindtree.hospitalpractice.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.hospitalpractice.dto.DoctorDto;
import com.mindtree.hospitalpractice.dto.PatientDto;
import com.mindtree.hospitalpractice.exception.controllerexception.HospitalPracticeControllerException;
import com.mindtree.hospitalpractice.exception.serviceexception.HospitalPracticeServiceException;
import com.mindtree.hospitalpractice.service.HospitalPracticeService;

@RestController
public class HospitalPracticeController {

	@Autowired
	HospitalPracticeService service;

	@PostMapping("/inserDoctor")
	public ResponseEntity<Map<String, Object>> insertDoctor(@RequestBody DoctorDto doctor) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "insert into Doctor");
		response.put("Error : ", false);
		response.put("body : ", service.insertIntoDoctor(doctor));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@PostMapping("/inserPatient/{doctorId}")
	public ResponseEntity<Map<String, Object>> insertPatient(@RequestBody PatientDto patient,
			@PathVariable int doctorId) throws HospitalPracticeControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "insert into patient");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.insertIntoDoctor(patient, doctorId));
		} catch (HospitalPracticeServiceException e) {
			 throw new HospitalPracticeControllerException(e.getMessage(),e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}
	@GetMapping("/getDoctor/{patientName}")
	public ResponseEntity<Map<String, Object>> getDoctor(@PathVariable String patientName) throws HospitalPracticeControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "insert into Doctor");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.getDoctor(patientName));
		} catch (HospitalPracticeServiceException e) {
			throw new HospitalPracticeControllerException(e.getMessage(),e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}
	
    @GetMapping("/getPatient/{doctorId}")
    public ResponseEntity<Map<String, Object>> getPatient(@PathVariable int doctorId) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all patient");
		response.put("Error : ", false);
		response.put("body : ", service.getAllPatient(doctorId));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}
    
	

}
