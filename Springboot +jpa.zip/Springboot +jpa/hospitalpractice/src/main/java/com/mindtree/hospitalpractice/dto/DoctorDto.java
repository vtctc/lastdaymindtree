package com.mindtree.hospitalpractice.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class DoctorDto {

	private int doctorId;

	private String doctorName;

	private int doctorExperience;

	@JsonIgnoreProperties("doctor")
	List<PatientDto> patient;

	public DoctorDto() {
		super();
	}

	public DoctorDto(int doctorId, String doctorName, int doctorExperience, List<PatientDto> patient) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.doctorExperience = doctorExperience;
		this.patient = patient;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public int getDoctorExperience() {
		return doctorExperience;
	}

	public void setDoctorExperience(int doctorExperience) {
		this.doctorExperience = doctorExperience;
	}

	public List<PatientDto> getPatient() {
		return patient;
	}

	public void setPatient(List<PatientDto> patient) {
		this.patient = patient;
	}

}
