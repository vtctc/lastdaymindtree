package com.mindtree.hospitalpractice.service;

import java.util.List;

import com.mindtree.hospitalpractice.dto.DoctorDto;
import com.mindtree.hospitalpractice.dto.PatientDto;
import com.mindtree.hospitalpractice.exception.serviceexception.HospitalPracticeServiceException;

public interface HospitalPracticeService {

	String insertIntoDoctor(DoctorDto doctor);

	String insertIntoDoctor(PatientDto patient, int doctorId) throws HospitalPracticeServiceException;

	DoctorDto getDoctor(String patientName) throws HospitalPracticeServiceException;

	List<PatientDto> getAllPatient(int doctorId);

}
