package com.mindtree.hospitalpractice.exception.serviceexception;

import com.mindtree.hospitalpractice.exception.HospitalPracticeException;

public class HospitalPracticeServiceException extends HospitalPracticeException {

	public HospitalPracticeServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeServiceException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeServiceException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeServiceException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeServiceException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
