package com.mindtree.hospitalpractice.exception.controllerexception;

import com.mindtree.hospitalpractice.exception.HospitalPracticeException;

public class HospitalPracticeControllerException extends HospitalPracticeException{

	public HospitalPracticeControllerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeControllerException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeControllerException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeControllerException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeControllerException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
