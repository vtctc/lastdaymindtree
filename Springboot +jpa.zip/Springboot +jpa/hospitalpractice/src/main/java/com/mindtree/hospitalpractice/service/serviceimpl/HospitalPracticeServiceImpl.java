package com.mindtree.hospitalpractice.service.serviceimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.hospitalpractice.dto.DoctorDto;
import com.mindtree.hospitalpractice.dto.PatientDto;
import com.mindtree.hospitalpractice.entity.Doctor;
import com.mindtree.hospitalpractice.entity.Patient;
import com.mindtree.hospitalpractice.exception.serviceexception.HospitalPracticeServiceException;
import com.mindtree.hospitalpractice.exception.serviceexception.NoSuchIdExist;
import com.mindtree.hospitalpractice.exception.serviceexception.NoSuchNameExist;
import com.mindtree.hospitalpractice.repository.DoctorRepository;
import com.mindtree.hospitalpractice.repository.PatientRepository;
import com.mindtree.hospitalpractice.service.HospitalPracticeService;


@Service
public class HospitalPracticeServiceImpl implements HospitalPracticeService {

	@Autowired
	DoctorRepository doctorRepository;

	@Autowired
	PatientRepository patientRepository;

	ModelMapper modelMapper = new ModelMapper();

	public DoctorDto convertDoctorEntityToDto(Doctor doctor) {
		return modelMapper.map(doctor, DoctorDto.class);
	}

	public PatientDto convertPatientEntityToDto(Patient patient) {
		return modelMapper.map(patient, PatientDto.class);
	}

	@Override
	public String insertIntoDoctor(DoctorDto doctor) {

		Doctor doctors = modelMapper.map(doctor, Doctor.class);

		doctorRepository.save(doctors);

		return "inserted successfully";
	}

	
	
	/**
	 *Exception: no such doctor id is present
	 */
	@Override
	public String insertIntoDoctor(PatientDto patient, int doctorId) throws HospitalPracticeServiceException {

		Optional<Doctor> doctor = doctorRepository.findById(doctorId);

//		Doctor doctors = doctor.get();

		try {
			doctor.orElseThrow(() -> new NoSuchIdExist("no such doctor id is present"));
		} catch (NoSuchIdExist e) {
			throw new HospitalPracticeServiceException(e.getMessage(), e);
		}
		Doctor doctors = doctor.get();

		Patient patients = modelMapper.map(patient, Patient.class);

		List<Patient> patientss = new ArrayList<Patient>();

		patientss.add(patients);

		if (doctors.getPatient() == null) {
			doctors.setPatient(patientss);
		} else {
			doctors.getPatient().add(patients);
		}

		patients.setDoctor(doctors);

		patientRepository.save(patients);

		return "inserted successfully";
	}

	/**
	 * exception: no such name exist exception 
	 */
	@Override
	public DoctorDto getDoctor(String patientName) throws HospitalPracticeServiceException {

		Optional<Patient> patient = patientRepository.findBypatientName(patientName);

		try {
			patient.orElseThrow(() -> new NoSuchNameExist("no such name exist"));
		} catch (NoSuchNameExist e) {
			throw new HospitalPracticeServiceException(e.getMessage(), e);
		}

		Doctor doctor = patient.get().getDoctor();

		DoctorDto doctorDto = modelMapper.map(doctor, DoctorDto.class);

		return doctorDto;
	}

	/**
	 * use of comparator to sort the patient based on there age
	 */
	@Override
	public List<PatientDto> getAllPatient(int doctorId) {

		Doctor doctor = doctorRepository.findById(doctorId).get();

		List<Patient> patient = doctor.getPatient();

		List<PatientDto> patientDto = patient.stream().map(dt -> convertPatientEntityToDto(dt))
				.collect(Collectors.toList());

		Collections.sort(patientDto, new Comparator<PatientDto>() {

			@Override
			public int compare(PatientDto p1, PatientDto p2) {

				if (p1.getPatientAge() > p2.getPatientAge())
					return 1;
				else
					return -1;
				}
		});
		return patientDto;
 
	}

}
