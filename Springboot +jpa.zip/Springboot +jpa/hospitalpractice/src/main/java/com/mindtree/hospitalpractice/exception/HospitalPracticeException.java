package com.mindtree.hospitalpractice.exception;

public class HospitalPracticeException extends Exception{

	public HospitalPracticeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public HospitalPracticeException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	
	

}
