package com.mindtree.hospitalpractice.exceptionhandler;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.hospitalpractice.controller.HospitalPracticeController;
import com.mindtree.hospitalpractice.exception.controllerexception.HospitalPracticeControllerException;

@RestControllerAdvice(assignableTypes = HospitalPracticeController.class)
public class HospitalPracticeExceptionHandler {

	@ExceptionHandler
	public ResponseEntity<Map<String, Object>> exceptionHandler(HospitalPracticeControllerException c,
			Throwable cause) {
		Map<String, Object> error = new LinkedHashMap<String, Object>();

		error.put("message", "exception occured");
		error.put("error", true);
		error.put("body", c.getMessage());
		error.put("http status", HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<Map<String, Object>>(error, HttpStatus.NOT_FOUND);

	}

}
