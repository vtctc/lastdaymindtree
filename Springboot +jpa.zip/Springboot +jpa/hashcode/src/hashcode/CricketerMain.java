package hashcode;

import java.util.HashSet;
import java.util.Set;

public class CricketerMain {
	
	public static void main(String[] args) {
		
		Set<String> example=new HashSet<String>();
		
		example.add("hello");
		example.add("hello");
		example.add("hi");
		System.out.println(example);
		Cricketer c1=new Cricketer(1, "sayan");
		Cricketer c2=new Cricketer(1, "jack");
		Cricketer c3=new Cricketer(2,"raj");
		
//		if(c1.equals(c2))
//		{
//			return t
//		}
//		
		Set<Cricketer> crick=new HashSet<Cricketer>();
		
		crick.add(c1);
		crick.add(c2);
		crick.add(c3);
		
		System.out.println(crick);
		
	}

}
