package com.mindtree.books.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mindtree.books.entity.Genre;

@Repository
public interface GenreRepository extends JpaRepository<Genre, Integer> {
	
Optional<Genre> findBygenreName(String genreName);

}
