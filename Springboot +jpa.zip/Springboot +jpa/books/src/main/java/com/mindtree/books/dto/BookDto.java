package com.mindtree.books.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class BookDto {
	
	private int bookId;
	private String bookName;
	private double bookPrice;
	
	@JsonIgnoreProperties("book")
	PublisherDto publisher;
	
	@JsonIgnoreProperties("book")
	GenreDto genre;

	public BookDto() {
		super();
	}

	public BookDto(int bookId, String bookName, double bookPrice, PublisherDto publisher, GenreDto genre) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookPrice = bookPrice;
		this.publisher = publisher;
		this.genre = genre;
	}

	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public double getBookPrice() {
		return bookPrice;
	}

	public void setBookPrice(double bookPrice) {
		this.bookPrice = bookPrice;
	}

	public PublisherDto getPublisher() {
		return publisher;
	}

	public void setPublisher(PublisherDto publisher) {
		this.publisher = publisher;
	}

	public GenreDto getGenre() {
		return genre;
	}

	public void setGenre(GenreDto genre) {
		this.genre = genre;
	}
	

}
