package com.mindtree.books.dto;

import java.util.List;

import javax.persistence.FetchType;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.books.entity.Book;

public class GenreDto {
	
	private int genreId;
	private String genreName;

	
	@JsonIgnoreProperties("book")
	List<BookDto> book;

	public GenreDto() {
		super();
	}

	public GenreDto(int genreId, String genreName, List<BookDto> book) {
		super();
		this.genreId = genreId;
		this.genreName = genreName;
		this.book = book;
	}

	public int getGenreId() {
		return genreId;
	}

	public void setGenreId(int genreId) {
		this.genreId = genreId;
	}

	public String getGenreName() {
		return genreName;
	}

	public void setGenreName(String genreName) {
		this.genreName = genreName;
	}

	public List<BookDto> getBook() {
		return book;
	}

	public void setBook(List<BookDto> book) {
		this.book = book;
	}

	 
	

}
