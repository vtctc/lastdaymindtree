package com.mindtree.books.service.serviceimpl;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.books.dto.BookDto;
import com.mindtree.books.entity.Book;
import com.mindtree.books.entity.Genre;
import com.mindtree.books.entity.Publisher;
import com.mindtree.books.exception.serviceexception.BooksServiceException;
import com.mindtree.books.exception.serviceexception.NoSuchGenre;
import com.mindtree.books.exception.serviceexception.NoSuchPublishser;
import com.mindtree.books.repository.BookRepository;
import com.mindtree.books.repository.GenreRepository;
import com.mindtree.books.repository.PublisherRepository;
import com.mindtree.books.service.BooksService;

@Service
public class BookServiceImpl implements BooksService {

	@Autowired
	BookRepository bookRepository;

	@Autowired
	GenreRepository genreRepository;

	@Autowired
	PublisherRepository publisherRepository;//private

	ModelMapper modelMapper = new ModelMapper();

	@Override
	public String addBook(BookDto bookDto, int genreId, int publisherId) throws BooksServiceException {

		Optional<Genre> genreOptional = genreRepository.findById(genreId);
		try {
			genreOptional.orElseThrow(() -> new NoSuchGenre("No Such Genre id is available"));
		} catch (NoSuchGenre e) {
			throw new BooksServiceException(e.getMessage(), e);
		}
		Optional<Publisher> publisherOptional = publisherRepository.findById(publisherId);
		try {
			publisherOptional.orElseThrow(() -> new NoSuchPublishser("No Such Publisher id is available"));
		} catch (NoSuchPublishser e) {
			throw new BooksServiceException(e.getMessage(), e);
		}
		Genre genre = genreOptional.get();
		Publisher publisher = publisherOptional.get();

		Book book = modelMapper.map(bookDto, Book.class);
		book.setGenre(genre);
		book.setPublisher(publisher);
		bookRepository.save(book);

		return "assigned";
	}

	@Override
	public Set<String> getAllPUblisher(String genreName) throws BooksServiceException {

		Optional<Genre> genreOptional = genreRepository.findBygenreName(genreName);
		try {
			genreOptional.orElseThrow(() -> new NoSuchGenre("No Such Genre Name is available"));
		} catch (NoSuchGenre e) {
			throw new BooksServiceException(e.getMessage(), e);
		}

		Genre genre = genreOptional.get();

		Set<String> publishers = new HashSet<String>();
		List<Book> books = bookRepository.findAll();
		for (Book book : books)
			if (book.getGenre().getGenreName().equals(genre.getGenreName()))
				publishers.add(book.getPublisher().getPublisherName());

		return publishers;
	}

	@Override
	public List<BookDto> getAllBoOks(int publisherId) throws BooksServiceException {
		Optional<Publisher> publisherOptional = publisherRepository.findById(publisherId);
		try {
			publisherOptional.orElseThrow(() -> new NoSuchPublishser("No Such Publisher id is available"));
		} catch (NoSuchPublishser e) {
			throw new BooksServiceException(e.getMessage(), e);
		}
		Publisher publisher = publisherOptional.get();

		List<Book> bookList = publisher.getBook();
		bookList.sort((b1, b2) -> {
			int sum = (int) (b1.getBookPrice() - b2.getBookPrice());
			if (sum > 0) {
				return -1;
			} else {
				return 1;
			}
		});

		List<BookDto> bookDto = bookList.stream().map(bookdto -> modelMapper.map(bookdto, BookDto.class))
				.collect(Collectors.toList());
		return bookDto;
	}

}

 