package com.mindtree.books.service;

import java.util.List;
import java.util.Set;

import com.mindtree.books.dto.BookDto;
import com.mindtree.books.dto.PublisherDto;
import com.mindtree.books.exception.serviceexception.BooksServiceException;

public interface BooksService {

	String addBook(BookDto bookDto, int genreId, int publisherId) throws BooksServiceException;

	Set<String> getAllPUblisher(String GenreName) throws BooksServiceException;

	List<BookDto> getAllBoOks(int publisherId) throws BooksServiceException;

}
