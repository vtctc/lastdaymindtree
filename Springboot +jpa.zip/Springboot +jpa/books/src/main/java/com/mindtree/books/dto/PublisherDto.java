package com.mindtree.books.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class PublisherDto {
	
	private int publisherId;
	private String publisherName;
	
	@JsonIgnoreProperties("publisher")
	List<BookDto> book;

	public PublisherDto() {
		super();
	}

	public PublisherDto(int publisherId, String publisherName, List<BookDto> book) {
		super();
		this.publisherId = publisherId;
		this.publisherName = publisherName;
		this.book = book;
	}

	public int getPublisherId() {
		return publisherId;
	}

	public void setPublisherId(int publisherId) {
		this.publisherId = publisherId;
	}

	public String getPublisherName() {
		return publisherName;
	}

	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}

	public List<BookDto> getBook() {
		return book;
	}

	public void setBook(List<BookDto> book) {
		this.book = book;
	}
	
	
	


}
