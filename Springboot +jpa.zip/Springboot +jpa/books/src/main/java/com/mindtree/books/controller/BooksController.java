package com.mindtree.books.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.books.dto.BookDto;
import com.mindtree.books.exception.controllerexception.BooksControllerException;
import com.mindtree.books.exception.serviceexception.BooksServiceException;
import com.mindtree.books.service.BooksService;

@RestController
public class BooksController {

	@Autowired
	BooksService service;

	@PostMapping("/addBook/{genreId}/{publisherId}")
	public ResponseEntity<Map<String, Object>> addBook(@RequestBody BookDto bookDto, @PathVariable int genreId,
			@PathVariable int publisherId) throws BooksControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "add books");
		response.put("Error", false);
		try {
			response.put("body", service.addBook(bookDto, genreId, publisherId));
		} catch (BooksServiceException e) {
			throw new BooksControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}

	@GetMapping("/getAllPUblisher/{genreName}")
	public ResponseEntity<Map<String, Object>> getAllPUblisher(@PathVariable String genreName)
			throws BooksControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all publishers");
		response.put("Error", false);
		try {
			response.put("body", service.getAllPUblisher(genreName));
		} catch (BooksServiceException e) {
			throw new BooksControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}

	@GetMapping("/getAllBoOks/{publisherId}")
	public ResponseEntity<Map<String, Object>> getAllBoOks(@PathVariable int publisherId)
			throws BooksControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all books");
		response.put("Error", false);
		try {
			response.put("body", service.getAllBoOks(publisherId));
		} catch (BooksServiceException e) {
			throw new BooksControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);
		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}
}
