package com.mindtree.books.exception;

public class BooksException extends Exception {

	public BooksException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BooksException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public BooksException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public BooksException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public BooksException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
