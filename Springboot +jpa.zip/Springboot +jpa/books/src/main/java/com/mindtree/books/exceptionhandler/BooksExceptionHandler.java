package com.mindtree.books.exceptionhandler;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.mindtree.books.controller.BooksController;
import com.mindtree.books.exception.controllerexception.BooksControllerException;

@RestControllerAdvice(assignableTypes = BooksController.class)
public class BooksExceptionHandler {

	@ExceptionHandler
	public ResponseEntity<Map<String, Object>> exceptionHandler(BooksControllerException c, Throwable cause) {
		Map<String, Object> error = new LinkedHashMap<String, Object>();

		error.put("message", "exception occured");
		error.put("error", true);
		error.put("body", c.getMessage());
		error.put("http status", HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<Map<String, Object>>(error, HttpStatus.NOT_FOUND);

	}

}
