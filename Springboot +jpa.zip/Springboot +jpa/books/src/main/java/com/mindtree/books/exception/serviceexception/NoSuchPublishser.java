package com.mindtree.books.exception.serviceexception;

public class NoSuchPublishser extends BooksServiceException {

	public NoSuchPublishser() {
		// TODO Auto-generated constructor stub
	}

	public NoSuchPublishser(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public NoSuchPublishser(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public NoSuchPublishser(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public NoSuchPublishser(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
