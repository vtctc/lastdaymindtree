package com.mindtree.books.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Genre {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int genreId;
	private String genreName;

	@OneToMany(fetch = FetchType.LAZY,mappedBy = "genre")
	List<Book> book;

	public Genre() {
		super();
	}

	public Genre(int genreId, String genreName, List<Book> book) {
		super();
		this.genreId = genreId;
		this.genreName = genreName;
		this.book = book;
	}

	public int getGenreId() {
		return genreId;
	}

	public void setGenreId(int genreId) {
		this.genreId = genreId;
	}

	public String getGenreName() {
		return genreName;
	}

	public void setGenreName(String genreName) {
		this.genreName = genreName;
	}

	public List<Book> getBook() {
		return book;
	}

	public void setBook(List<Book> book) {
		this.book = book;
	}

	 
	 
}
