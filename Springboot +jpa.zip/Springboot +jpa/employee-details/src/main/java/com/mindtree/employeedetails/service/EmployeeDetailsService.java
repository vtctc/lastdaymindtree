package com.mindtree.employeedetails.service;

import java.util.ArrayList;
import java.util.List;

import com.mindtree.employeedetails.dto.EmployeeDetailsDto;
import com.mindtree.employeedetails.entity.Employee;

public interface EmployeeDetailsService {

	 String insertIntoEmployee(EmployeeDetailsDto employeedto);

	 List<EmployeeDetailsDto> getAllEmployeeDetails();

	 EmployeeDetailsDto getAllEmployeeById(int id);

	 String updateEmployees(int id, EmployeeDetailsDto employeedto);

	 String deleteEmployees(int id);

	 

	 

}
