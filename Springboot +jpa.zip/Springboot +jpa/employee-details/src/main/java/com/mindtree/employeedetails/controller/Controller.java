package com.mindtree.employeedetails.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.employeedetails.dto.EmployeeDetailsDto;
import com.mindtree.employeedetails.service.EmployeeDetailsService;

@RestController
public class Controller {

	@Autowired
	EmployeeDetailsService service;

	@PostMapping("/insertEmployee")
	public ResponseEntity<Map<String, Object>> insertEmployee(@RequestBody EmployeeDetailsDto employeedto) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "insert details into employee");
		response.put("Error : ", false);
		response.put("body : ", service.insertIntoEmployee(employeedto));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/getAllEmployee")
	public ResponseEntity<Map<String, Object>> getAllEmployee() {

		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all employee details");
		response.put("Error : ", false);
		response.put("body : ", service.getAllEmployeeDetails());
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/getEmployeeById/{id}")
	public ResponseEntity<Map<String, Object>> getAllEmployeeByID(@PathVariable int id) {

		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all employee details by id");
		response.put("Error : ", false);
		response.put("body : ", service.getAllEmployeeById(id));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@PutMapping("/updateEmployee/{id}")
	public ResponseEntity<Map<String, Object>> updateEmployee(@PathVariable int id,
			@RequestBody EmployeeDetailsDto employeedto) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "update employee details");
		response.put("Error : ", false);
		response.put("body : ", service.updateEmployees(id, employeedto));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@DeleteMapping("deleteEmployee/{id}")
	public ResponseEntity<Map<String, Object>> deleteEmployee(@PathVariable int id) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "delete employee details");
		response.put("Error : ", false);
		response.put("body : ", service.deleteEmployees(id));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
	}
}
