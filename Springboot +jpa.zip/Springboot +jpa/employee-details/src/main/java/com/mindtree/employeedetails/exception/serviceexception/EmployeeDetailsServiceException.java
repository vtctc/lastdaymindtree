package com.mindtree.employeedetails.exception.serviceexception;

public class EmployeeDetailsServiceException {

}
