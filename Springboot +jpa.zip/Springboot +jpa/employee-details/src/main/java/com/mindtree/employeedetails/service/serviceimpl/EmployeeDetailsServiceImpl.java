package com.mindtree.employeedetails.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.employeedetails.dto.EmployeeDetailsDto;
import com.mindtree.employeedetails.entity.Employee;
import com.mindtree.employeedetails.repository.EmployeeRepository;
import com.mindtree.employeedetails.service.EmployeeDetailsService;

@Service
public class EmployeeDetailsServiceImpl implements EmployeeDetailsService {

	@Autowired
	EmployeeRepository employeeRepository;

	ModelMapper modelMapper = new ModelMapper();

	public EmployeeDetailsDto convertEmployeeProfileEntityToDto(Employee employee) {

		return modelMapper.map(employee, EmployeeDetailsDto.class);
	}

	@Override
	public String insertIntoEmployee(EmployeeDetailsDto employeeDto) {

		Employee employees = modelMapper.map(employeeDto, Employee.class);

		employeeRepository.save(employees);

		return "inserted successfully";
	}

	@Override
	public List<EmployeeDetailsDto> getAllEmployeeDetails() {

		List<Employee> employees = employeeRepository.findAll();

		List<EmployeeDetailsDto> employeesDto = new ArrayList<EmployeeDetailsDto>();
		employees.forEach(employee -> {
			EmployeeDetailsDto employeeDto = convertEmployeeProfileEntityToDto(employee);
			employeesDto.add(employeeDto);
		});

		return employeesDto;

	}

	@Override
	public EmployeeDetailsDto getAllEmployeeById(int id) {

		Employee employee = employeeRepository.getOne(id);

		EmployeeDetailsDto employeeDetailDto = convertEmployeeProfileEntityToDto(employee);

		return employeeDetailDto;
	}

	@Override
	public String updateEmployees(int id, EmployeeDetailsDto employeeDto) {

		Employee employee = employeeRepository.getOne(id);

		employee.setFirstName(employeeDto.getFirstName());
		employee.setLastName(employeeDto.getLastName());
		employee.setEmailId(employeeDto.getEmailId());

		employeeRepository.save(employee);

		return "updated successfully";
	}

	@Override
	public String deleteEmployees(int id) {

		Employee employee = employeeRepository.getOne(id);

		// EmployeeDetailsDto
		// employeeDetailDto=convertEmployeeProfileEntityToDto(employee);

		employeeRepository.delete(employee);

		return "deleted successfully";
	}

}
