package com.mindtree.employeedetails.exception;

public class EmployeeDetailsException {

}
