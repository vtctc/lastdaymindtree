package com.mindtree.holiday.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class ChannelDto {
	
	private int channelId;
	
	 private String channelName;
	 
	 private double channelPrice;
	 
	 private String channelLanguage;
	 
	 @JsonIgnoreProperties("channel")
	 List<PackagesDto> packages;

	 public ChannelDto() {
		super();
	}

	public ChannelDto(int channelId, String channelName, double channelPrice, String channelLanguage,
			List<PackagesDto> packages) {
		super();
		this.channelId = channelId;
		this.channelName = channelName;
		this.channelPrice = channelPrice;
		this.channelLanguage = channelLanguage;
		this.packages = packages;
	}

	public int getChannelId() {
		return channelId;
	}

	public void setChannelId(int channelId) {
		this.channelId = channelId;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public double getChannelPrice() {
		return channelPrice;
	}

	public void setChannelPrice(double channelPrice) {
		this.channelPrice = channelPrice;
	}

	public String getChannelLanguage() {
		return channelLanguage;
	}

	public void setChannelLanguage(String channelLanguage) {
		this.channelLanguage = channelLanguage;
	}

	public List<PackagesDto> getPackages() {
		return packages;
	}

	public void setPackages(List<PackagesDto> packages) {
		this.packages = packages;
	}
	 
	 
	 
	 

}
