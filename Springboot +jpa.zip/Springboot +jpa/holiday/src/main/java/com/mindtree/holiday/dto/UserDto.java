package com.mindtree.holiday.dto;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class UserDto {

	private int userId;

	private String userName;

	private LocalDate packageStartDate;

	private LocalDate packageEndDate;

	@JsonIgnoreProperties("user")
	PackagesDto packages;

	public UserDto() {
		super();
	}

	public UserDto(int userId, String userName, LocalDate packageStartDate, LocalDate packageEndDate,
			PackagesDto packages) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.packageStartDate = packageStartDate;
		this.packageEndDate = packageEndDate;
		this.packages = packages;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public LocalDate getPackageStartDate() {
		return packageStartDate;
	}

	public void setPackageStartDate(LocalDate packageStartDate) {
		this.packageStartDate = packageStartDate;
	}

	public LocalDate getPackageEndDate() {
		return packageEndDate;
	}

	public void setPackageEndDate(LocalDate packageEndDate) {
		this.packageEndDate = packageEndDate;
	}

	public PackagesDto getPackages() {
		return packages;
	}

	public void setPackages(PackagesDto packages) {
		this.packages = packages;
	}
   
	
	 
	
	
}
