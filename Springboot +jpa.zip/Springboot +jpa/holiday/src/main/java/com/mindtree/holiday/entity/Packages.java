package com.mindtree.holiday.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Packages {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int packageId;
	
	private String packageName;
	
	private double packagePrice;
	
	@OneToMany(cascade = CascadeType.PERSIST,fetch = FetchType.LAZY,mappedBy = "packages")
	List<User> user;

	@ManyToMany(cascade = CascadeType.PERSIST,fetch = FetchType.LAZY,mappedBy = "packages")
	 List<Channel> channel;

	public Packages() {
		super();
	}

	public Packages(int packageId, String packageName, double packagePrice, List<User> user, List<Channel> channel) {
		super();
		this.packageId = packageId;
		this.packageName = packageName;
		this.packagePrice = packagePrice;
		this.user = user;
		this.channel = channel;
	}

	public int getPackageId() {
		return packageId;
	}

	public void setPackageId(int packageId) {
		this.packageId = packageId;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public double getPackagePrice() {
		return packagePrice;
	}

	public void setPackagePrice(double packagePrice) {
		this.packagePrice = packagePrice;
	}

	public List<User> getUser() {
		return user;
	}

	public void setUser(List<User> user) {
		this.user = user;
	}

	public List<Channel> getChannel() {
		return channel;
	}

	public void setChannel(List<Channel> channel) {
		this.channel = channel;
	}
	
	
	

}
