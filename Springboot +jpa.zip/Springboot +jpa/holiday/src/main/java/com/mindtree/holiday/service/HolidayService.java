package com.mindtree.holiday.service;

import java.time.LocalDate;

import com.mindtree.holiday.dto.PackagesDto;
import com.mindtree.holiday.dto.UserDto;
import com.mindtree.holiday.exception.serviceexception.HolidayServiceException;

public interface HolidayService {

	PackagesDto insertIntoPackages(PackagesDto packages);

	UserDto assignPackages(int packageId, int userId, LocalDate startingDate) throws HolidayServiceException;

	int validatePackages(int userId) throws HolidayServiceException;
		 
}
