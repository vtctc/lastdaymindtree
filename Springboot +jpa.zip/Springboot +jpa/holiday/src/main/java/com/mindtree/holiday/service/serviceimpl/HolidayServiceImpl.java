package com.mindtree.holiday.service.serviceimpl;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.holiday.dto.ChannelDto;
import com.mindtree.holiday.dto.PackagesDto;
import com.mindtree.holiday.dto.UserDto;
import com.mindtree.holiday.entity.Channel;
import com.mindtree.holiday.entity.Packages;
import com.mindtree.holiday.entity.User;
import com.mindtree.holiday.exception.serviceexception.HolidayServiceException;
import com.mindtree.holiday.exception.serviceexception.NoSuchPackageIdFound;
import com.mindtree.holiday.exception.serviceexception.PacakgeExpired;
import com.mindtree.holiday.exception.serviceexception.NoSuchUserExist;
import com.mindtree.holiday.repository.ChannelRepository;
import com.mindtree.holiday.repository.PackagesRepository;
import com.mindtree.holiday.repository.UserRepository;
import com.mindtree.holiday.service.HolidayService;

@Service
public class HolidayServiceImpl implements HolidayService {

	@Autowired
	PackagesRepository packagesRepository;

	@Autowired
	ChannelRepository channelRepository;

	@Autowired
	UserRepository userRepository;

	ModelMapper modelMapper = new ModelMapper();

	public PackagesDto convertPackageEntityToDto(Packages packages) {

		return modelMapper.map(packages, PackagesDto.class);

	}

	public ChannelDto convertChannelEntityToDto(Channel channel) {

		return modelMapper.map(channel, ChannelDto.class);

	}

	public UserDto convertUserEntityToDto(User user) {

		return modelMapper.map(user, UserDto.class);

	}

	@Override
	public PackagesDto insertIntoPackages(PackagesDto packages) {

		Packages packagess = modelMapper.map(packages, Packages.class);
		List<Packages> pack = new ArrayList<Packages>();
		pack.add(packagess);

		double price = 0;
		List<Channel> channels = packagess.getChannel();
		List<Channel> channelss = new ArrayList<Channel>();
		for (Channel ch : channels) {
			Channel chl = channelRepository.findById(ch.getChannelId()).get();
			price = price + ch.getChannelPrice();

			if (chl.getPackages() == null) {
				chl.setPackages(pack);
			} else {
				chl.getPackages().add(packagess);

			}
			channelss.add(chl);
		}

		packagess.setPackagePrice(price + price * 0.1);
		packagess.setChannel(channelss);
		Packages packg = packagesRepository.save(packagess);

		return modelMapper.map(packg, PackagesDto.class);
	}

	@Override
	public UserDto assignPackages(int packageId, int userId, LocalDate startingDate) throws HolidayServiceException {
		System.out.println();
		Optional<Packages> packg = packagesRepository.findById(packageId);
		try {
			packg.orElseThrow(() -> new NoSuchPackageIdFound("no such package id is present"));
		} catch (NoSuchPackageIdFound e) {
			throw new HolidayServiceException(e.getMessage(), e);
		}
		Packages p = packg.get();

		User users = userRepository.findById(userId).get();
		System.out.println(users.getUserName());
//		try {
//			user.orElseThrow(() -> new NoSuchUserExist(" no such user id is exist"));
//		} catch (NoSuchUserExist e) {
//			throw new HolidayServiceException(e.getMessage(), e);
//		}

		users.setPackages(p);
		users.setPackageStartDate(startingDate);
		User u = userRepository.save(users);

		return modelMapper.map(u, UserDto.class);
	}

	@Override
	public int validatePackages(int userId) throws HolidayServiceException {

		int result = 0;
		User user = userRepository.findById(userId).get();

		LocalDate startDate = user.getPackageStartDate();
		LocalDate endDate = user.getPackageEndDate();
		LocalDate todayDate = LocalDate.now();

		if (todayDate.isAfter(startDate) && todayDate.isBefore(endDate)) {
			result = Math.abs(todayDate.compareTo(endDate));
			return result;
		} else
			try {
				throw new PacakgeExpired("package expired");

			} catch (PacakgeExpired e) {
				throw new HolidayServiceException(e.getMessage(), e);
			}

	}

}
