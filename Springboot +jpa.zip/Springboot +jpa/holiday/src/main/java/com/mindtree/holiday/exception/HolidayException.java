package com.mindtree.holiday.exception;

public class HolidayException extends Exception{

	public HolidayException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HolidayException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public HolidayException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public HolidayException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public HolidayException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
