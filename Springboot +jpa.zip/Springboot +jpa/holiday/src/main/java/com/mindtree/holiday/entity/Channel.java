package com.mindtree.holiday.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;

@Entity
public class Channel {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	 private int channelId;
	
	 private String channelName;
	 
	 private double channelPrice;
	 
	 private String channelLanguage;
	 
	 @ManyToMany(fetch = FetchType.EAGER)
	 List<Packages> packages;

	public Channel() {
		super();
	}

	public Channel(int channelId, String channelName, double channelPrice, String channelLanguage,
			List<Packages> packages) {
		super();
		this.channelId = channelId;
		this.channelName = channelName;
		this.channelPrice = channelPrice;
		this.channelLanguage = channelLanguage;
		this.packages = packages;
	}

	public int getChannelId() {
		return channelId;
	}

	public void setChannelId(int channelId) {
		this.channelId = channelId;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public double getChannelPrice() {
		return channelPrice;
	}

	public void setChannelPrice(double channelPrice) {
		this.channelPrice = channelPrice;
	}

	public String getChannelLanguage() {
		return channelLanguage;
	}

	public void setChannelLanguage(String channelLanguage) {
		this.channelLanguage = channelLanguage;
	}

	public List<Packages> getPackages() {
		return packages;
	}

	public void setPackages(List<Packages> packages) {
		this.packages = packages;
	}

	 
	 
	 
	
}
