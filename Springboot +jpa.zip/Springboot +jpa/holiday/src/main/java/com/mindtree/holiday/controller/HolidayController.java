package com.mindtree.holiday.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.holiday.dto.PackagesDto;
import com.mindtree.holiday.exception.controllerexception.HolidayControllerException;
import com.mindtree.holiday.exception.serviceexception.HolidayServiceException;
import com.mindtree.holiday.service.HolidayService;

@RestController
public class HolidayController {

	@Autowired
	HolidayService service;

	@PostMapping("/createPackage")
	public ResponseEntity<Map<String, Object>> insertPackage(@RequestBody PackagesDto packages) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "inserted into packages");
		response.put("Error : ", false);
		response.put("body : ", service.insertIntoPackages(packages));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/validatePacakage/{userId}")
	public ResponseEntity<Map<String, Object>> validatePackage(@PathVariable int userId) throws HolidayControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "validate packages");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.validatePackages(userId));
		} catch (HolidayServiceException e) {
			 throw new HolidayControllerException(e.getMessage(),e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@PostMapping("/assignPackage/{packageId}/{userId}/{startingDate}")
	public ResponseEntity<Map<String, Object>> assignPackage(@PathVariable int packageId, @PathVariable int userId,
			@PathVariable String startingDate) throws HolidayControllerException {
		Map<String, Object> response = new HashMap<String, Object>();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d-MM-yyyy");

		// convert String to LocalDate
		LocalDate localDate = LocalDate.parse(startingDate, formatter);
		response.put("Headers : ", "package is assigned");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.assignPackages(packageId, userId, localDate));
		} catch (HolidayServiceException e) {
			throw new HolidayControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

//	@PostMapping("/createPackage")
//	public ResponseEntity<Map<String, Object>> insertPackage(@RequestBody PackagesDto packages) {
//		Map<String, Object> response = new HashMap<String, Object>();
//
//		response.put("Headers : ", "inserted into packages");
//		response.put("Error : ", false);
//		response.put("body : ", service.insertIntoPackages(packages));
//		response.put("Http Status : ", HttpStatus.OK);
//
//		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
//
//	}
//
////	@PostMapping("/assigPackage/{userId}")
////	public ResponseEntity<Map<String, Object>> assignPackage(@RequestBody PackagesDto packages,@PathVariable int userId) throws HolidayControllerException {
////		Map<String, Object> response = new HashMap<String, Object>();
////
////		response.put("Headers : ", "assigning packages");
////		response.put("Error : ", false);
////		try {
////			response.put("body : ", service.assignPackages(packages,userId));
////		} catch (HolidayServiceException e) {
////			 throw new HolidayControllerException(e.getMessage(), e);		}
////		response.put("Http Status : ", HttpStatus.OK);
////
////		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
////
////	}
//	@GetMapping("/validatePackage/{userId}")
//	public ResponseEntity<Map<String, Object>> ValidatePackage(@PathVariable int userId) {
//		Map<String, Object> response = new HashMap<String, Object>();
//
//		response.put("Headers : ", "inserted into packages");
//		response.put("Error : ", false);
//		response.put("body : ", service.validatePackages(userId));
//		response.put("Http Status : ", HttpStatus.OK);
//
//		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);
//
//	}
//	

}
