package com.mindtree.holiday.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.mindtree.holiday.entity.Channel;
import com.mindtree.holiday.entity.User;

public class PackagesDto {
private int packageId;
	
	private String packageName;
	
	private double packagePrice;
	
	@JsonIgnoreProperties("packages")
	List<UserDto> user;
    @JsonIgnoreProperties("packages")
	List<ChannelDto> channel;

	public PackagesDto() {
		super();
	}

	public PackagesDto(int packageId, String packageName, double packagePrice, List<UserDto> user,
			List<ChannelDto> channel) {
		super();
		this.packageId = packageId;
		this.packageName = packageName;
		this.packagePrice = packagePrice;
		this.user = user;
		this.channel = channel;
	}

	public int getPackageId() {
		return packageId;
	}

	public void setPackageId(int packageId) {
		this.packageId = packageId;
	}

	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}

	public double getPackagePrice() {
		return packagePrice;
	}

	public void setPackagePrice(double packagePrice) {
		this.packagePrice = packagePrice;
	}

	public List<UserDto> getUser() {
		return user;
	}

	public void setUser(List<UserDto> user) {
		this.user = user;
	}

	public List<ChannelDto> getChannel() {
		return channel;
	}

	public void setChannel(List<ChannelDto> channel) {
		this.channel = channel;
	}


}
