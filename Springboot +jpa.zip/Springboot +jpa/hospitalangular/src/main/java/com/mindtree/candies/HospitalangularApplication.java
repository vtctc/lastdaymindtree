package com.mindtree.candies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HospitalangularApplication {

	public static void main(String[] args) {
		SpringApplication.run(HospitalangularApplication.class, args);
	}

}
