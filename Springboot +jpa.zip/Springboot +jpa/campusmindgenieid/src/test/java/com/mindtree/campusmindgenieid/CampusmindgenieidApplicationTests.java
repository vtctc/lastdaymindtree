package com.mindtree.campusmindgenieid;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampusmindgenieidApplicationTests {

	@Test
	void contextLoads() {
	}

}
