package dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class CampusMindGenieDto {

	private int campusMindId;
	
	private String mindName;
	
	private String projectName;
	
	@JsonIgnoreProperties("genie")
	private List<GenieDto> genieDto;

	public int getCampusMindId() {
		return campusMindId;
	}

	public void setCampusMindId(int campusMindId) {
		this.campusMindId = campusMindId;
	}

	public String getMindName() {
		return mindName;
	}

	public void setMindName(String mindName) {
		this.mindName = mindName;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public List<GenieDto> getGenieDto() {
		return genieDto;
	}

	public void setGenieDto(List<GenieDto> genieDto) {
		this.genieDto = genieDto;
	}
	
	
	
	
	
}
