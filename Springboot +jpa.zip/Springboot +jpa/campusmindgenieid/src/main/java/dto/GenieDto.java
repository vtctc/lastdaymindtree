package dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.mindtree.campusmindgenieid.entity.CampusMind;

public class GenieDto {

	private int genieId;
	private String genieDescription;
	private boolean genieStatus;
	
	@JsonProperty("campusMind")
    private CampusMind campusMind;


	public int getGenieId() {
		return genieId;
	}


	public void setGenieId(int genieId) {
		this.genieId = genieId;
	}


	public String getGenieDescription() {
		return genieDescription;
	}


	public void setGenieDescription(String genieDescription) {
		this.genieDescription = genieDescription;
	}


	public boolean isGenieStatus() {
		return genieStatus;
	}


	public void setGenieStatus(boolean genieStatus) {
		this.genieStatus = genieStatus;
	}


	public CampusMind getCampusMind() {
		return campusMind;
	}


	public void setCampusMind(CampusMind campusMind) {
		this.campusMind = campusMind;
	}
	 
}
