package com.mindtree.campusmindgenieid.service;

import java.util.List;

import com.mindtree.campusmindgenieid.entity.CampusMind;
import com.mindtree.campusmindgenieid.entity.Genie;

import dto.CampusMindGenieDto;
import dto.GenieDto;

public interface CampusMindGenieIdService {

	CampusMind insertdetails(CampusMind camp);

	//CampusMindGenieDto insertintogenie(int id, List<Genie> genie);

	List<CampusMind> getdetails();

	List<Genie> getdetailbyid(int id);

	List<GenieDto> insertintogenie(int id, List<Genie> genie);

}
