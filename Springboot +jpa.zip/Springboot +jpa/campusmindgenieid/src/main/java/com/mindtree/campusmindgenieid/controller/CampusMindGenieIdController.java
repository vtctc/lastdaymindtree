package com.mindtree.campusmindgenieid.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.apiconfig.ApiResponse;
import com.mindtree.campusmindgenieid.entity.CampusMind;
import com.mindtree.campusmindgenieid.entity.Genie;
import com.mindtree.campusmindgenieid.service.CampusMindGenieIdService;

import dto.CampusMindGenieDto;
import dto.GenieDto;

@RestController
public class CampusMindGenieIdController {
	@Autowired
	CampusMindGenieIdService service;

	@PostMapping("/insertdetails")
	public CampusMindGenieDto insertdetails(@RequestBody CampusMind camp) {

		CampusMind campusMind = service.insertdetails(camp);
		
		CampusMindGenieDto campusdto=new CampusMindGenieDto();
		campusdto.setCampusMindId(campusMind.getMid());
		campusdto.setMindName(campusMind.getName());
		campusdto.setProjectName(campusMind.getProjectName());
		

		return campusdto;

	}

//	@PostMapping("raiseagenie/{id}")
//	public ApiResponse raisegenie(@PathVariable int id, @RequestBody List<Genie> genie) {

//		ApiResponse response = new ApiResponse();
//		CampusMindGenieDto campusMindGenieDto = service.insertintogenie(id, genie);
//		response.setBody(campusMindGenieDto);
//		response.setError(false);
//		response.setSuccess(true);
//		response.setMessage("Inserted message succesfully");
//		
//		//if it's in catch
		//	response.setBody("No Body Available as data is not inserted");
		//response.setError(true);
		//response.setSuccess(false);
		//response.setMessage(e.getMessage());
		

	//	return response;
//	}

    @PostMapping("raiseagenie/{id}")
    	public List<GenieDto> raisegenie(@PathVariable int id,@RequestBody List<Genie> genie)
    	{
    		 List<GenieDto> genieDto=service.insertintogenie(id,genie);
    		
    		return genieDto;
    		
    	}
    	
    	
    


	@GetMapping("/getdetails")
	public List<CampusMind> getmsg() {
		List<CampusMind> campusmind = service.getdetails();
		return campusmind;
	}

	@GetMapping("/getbyid/{id}")
	public List<Genie> getbyid(@PathVariable int id) {
		List<Genie> genie = service.getdetailbyid(id);

		return genie;
	}

}
