package com.mindtree.campusmindgenieid.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class CampusMind {
	
	@Id
	private int mid;
	private String name;
	private String projectName; //camelCase
	
     @OneToMany(cascade = CascadeType.ALL,fetch=FetchType.LAZY,mappedBy ="campusMind")
      private List<Genie> genie;

	public int getMid() {
		return mid;
	}

	public void setMid(int mid) {
		this.mid = mid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public List<Genie> getGenie() {
		return genie;
	}

	public void setGenie(List<Genie> genie) {
		this.genie = genie;
	}

	
     
     
     
     
	
	
	
	
	
	
	

}
