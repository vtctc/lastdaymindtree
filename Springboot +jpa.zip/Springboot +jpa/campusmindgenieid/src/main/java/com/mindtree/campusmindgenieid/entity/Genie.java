package com.mindtree.campusmindgenieid.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class Genie {
	
	@Id
	private int genieId;
	private String genieDescription;
	private boolean genieStatus;
	
	@ManyToOne(fetch=FetchType.LAZY)
    private CampusMind campusMind;

	public int getGenieId() {
		return genieId;
	}

	public void setGenieId(int genieId) {
		this.genieId = genieId;
	}

	public String getGenieDescription() {
		return genieDescription;
	}

	public void setGenieDescription(String genieDescription) {
		this.genieDescription = genieDescription;
	}

	public boolean isGenieStatus() {
		return genieStatus;
	}

	public void setGenieStatus(boolean genieStatus) {
		this.genieStatus = genieStatus;
	}

	public CampusMind getCampusmind() {
		return campusMind;
	}

	public void setCampusmind(CampusMind campusmind) {
		this.campusMind = campusmind;
	}

	public Genie(int genieId, String genieDescription, boolean genieStatus, CampusMind campusmind) {
		 
		this.genieId = genieId;
		this.genieDescription = genieDescription;
		this.genieStatus = genieStatus;
		this.campusMind = campusmind;
	}

	public Genie() {
		 
	}	
	
	
}
