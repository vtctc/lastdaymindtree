package com.mindtree.campusmindgenieid.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.campusmindgenieid.entity.CampusMind;
import com.mindtree.campusmindgenieid.entity.Genie;
import com.mindtree.campusmindgenieid.repository.CampusMindRept;
import com.mindtree.campusmindgenieid.repository.GenieRept;
import com.mindtree.campusmindgenieid.service.CampusMindGenieIdService;

import dto.CampusMindGenieDto;
import dto.GenieDto;

@Service
public class CampusMindGenieIdServiceImpl implements CampusMindGenieIdService {

	@Autowired
	CampusMindRept campusobject; // private //campusRepo //Repository Name- CampusMindRepository

	GenieRept genieobject;

	@Override
	public CampusMind insertdetails(CampusMind camp) {
	
		

		CampusMind campusmind = campusobject.save(camp);

	return campusmind;
	}
//	}

//	@Override
//	public CampusMindGenieDto insertintogenie(int id, List<Genie> genie) {
//
//		CampusMindGenieDto campusMindGenieDto = new CampusMindGenieDto();
//		List<GenieDto> genieDto = new ArrayList<GenieDto>();
//		CampusMind campus = new CampusMind();
//
//		CampusMind cm = campusobject.getOne(id);
////
////		if (this.campusobject.existsById(id)) {
////			for (Genie gen : genie) {
////				GenieDto genieTemp = new GenieDto();
////				gen.setCampusmind(cm);
////				cm.getGenie().add(gen);
////				genieTemp.setGenieDescription(gen.getGenieDescription());
////				genieTemp.setGenieId(gen.getGenieId());
////				genieTemp.setGenieStatus(gen.isGenieStatus());
////				genieDto.add(genieTemp);
////
////			}
////
////			campus = campusobject.save(cm);
////			campusMindGenieDto.setGenieDto(genieDto);
////			campusMindGenieDto.setCampusMindId(campus.getMid());
////			campusMindGenieDto.setProjectName(campus.getProjectName());
////			campusMindGenieDto.setMindName(campus.getName());
////		} else {
//
//		}
//
//		return campusMindGenieDto;
//	}

	@Override
	public List<CampusMind> getdetails() {
		List<CampusMind> camp = campusobject.findAll();
		return camp;
	}

	@Override
	public List<Genie> getdetailbyid(int id) {

		CampusMind camp = campusobject.getOne(id);

		return camp.getGenie();

	}

	@Override
	public List<GenieDto> insertintogenie(int id, List<Genie> genie) {
		List<GenieDto> geniedto=new ArrayList<GenieDto>();
		List<CampusMind> campuses=campusobject.findAll();
	
	    CampusMind campus=campusobject.getOne(id);
		 
		for(CampusMind camp: campuses)
		{
			if(camp.getMid()==id)
			 for(Genie gen: genie)
			 {
				 gen.setCampusmind(campus);
				camp.getGenie().add(gen);
				GenieDto genieDto=new GenieDto();
				genieDto.setGenieId(gen.getGenieId());
				genieDto.setGenieDescription(gen.getGenieDescription());
				genieDto.setGenieStatus(gen.isGenieStatus());
				geniedto.add(genieDto);
			 }
			campus= campusobject.save(camp);
		}
		
		return geniedto;
		
	}
		
}
