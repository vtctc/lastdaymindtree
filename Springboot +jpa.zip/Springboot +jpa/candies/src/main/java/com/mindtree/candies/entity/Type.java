package com.mindtree.candies.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Type {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int typeId;
	
    private String typeName;
    
    @OneToOne(fetch = FetchType.EAGER)
    Candy candy;

	public Type() {
		super();
	}

	public Type(int typeId, String typeName, Candy candy) {
		super();
		this.typeId = typeId;
		this.typeName = typeName;
		this.candy = candy;
	}

	public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Candy getCandy() {
		return candy;
	}

	public void setCandy(Candy candy) {
		this.candy = candy;
	}
    
    
    
    

}
