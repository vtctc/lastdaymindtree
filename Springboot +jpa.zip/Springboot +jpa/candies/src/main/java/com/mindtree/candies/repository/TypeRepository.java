package com.mindtree.candies.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mindtree.candies.entity.Type;

@Repository
public interface TypeRepository extends JpaRepository<Type, Integer> {

//	@Query("select shop_name From Shop  INNER JOIN Candy on Shop.shop_id=Candy.candy_id INNER JOIN Type on Candy.candy_id=Type.type_id where Type.type_name=?")
//	List<Type> findBytypeName(String typeName);

}
