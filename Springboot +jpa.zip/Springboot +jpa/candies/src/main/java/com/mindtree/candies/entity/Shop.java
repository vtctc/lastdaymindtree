package com.mindtree.candies.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity
public class Shop {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int shopId;
	
	private String shopName;
	
	@ManyToMany(fetch = FetchType.LAZY)
	List<Candy> candy;

	public Shop() {
		super();
	}

	public Shop(int shopId, String shopName, List<Candy> candy) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.candy = candy;
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public List<Candy> getCandy() {
		return candy;
	}

	public void setCandy(List<Candy> candy) {
		this.candy = candy;
	}
	
	
	

}
