package com.mindtree.candies.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class ShopDto {
	
private int shopId;
	
	private String shopName;
	
	@JsonIgnoreProperties("shop")
	List<CandyDto> candy;

	public ShopDto() {
		super();
	}

	public int getShopId() {
		return shopId;
	}

	public void setShopId(int shopId) {
		this.shopId = shopId;
	}

	public String getShopName() {
		return shopName;
	}

	public void setShopName(String shopName) {
		this.shopName = shopName;
	}

	public List<CandyDto> getCandy() {
		return candy;
	}

	public void setCandy(List<CandyDto> candy) {
		this.candy = candy;
	}

	public ShopDto(int shopId, String shopName, List<CandyDto> candy) {
		super();
		this.shopId = shopId;
		this.shopName = shopName;
		this.candy = candy;
	}
	
	

}
