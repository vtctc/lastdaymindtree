package com.mindtree.candies.exception.serviceexception;

public class CandyStockLessThanTheRequiredQuantity extends CandiesServiceException {

	public CandyStockLessThanTheRequiredQuantity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CandyStockLessThanTheRequiredQuantity(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public CandyStockLessThanTheRequiredQuantity(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public CandyStockLessThanTheRequiredQuantity(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public CandyStockLessThanTheRequiredQuantity(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
