package com.mindtree.candies.service;

import java.util.List;

import com.mindtree.candies.dto.CandyDto;
import com.mindtree.candies.dto.ShopDto;
import com.mindtree.candies.exception.serviceexception.CandiesServiceException;

public interface CandiesService {

	List<CandyDto> getAllCandies(int shopId) throws CandiesServiceException;

	List<ShopDto> getShopName(int typeId);

	String getCandy(int shopId, int candyId, int quantity) throws CandiesServiceException;

}
