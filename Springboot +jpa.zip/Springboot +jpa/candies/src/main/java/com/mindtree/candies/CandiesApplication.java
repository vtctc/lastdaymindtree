package com.mindtree.candies;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CandiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(CandiesApplication.class, args);
	}

}
