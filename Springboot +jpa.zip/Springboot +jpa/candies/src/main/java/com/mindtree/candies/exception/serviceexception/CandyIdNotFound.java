package com.mindtree.candies.exception.serviceexception;

public class CandyIdNotFound extends CandiesServiceException {

	public CandyIdNotFound() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CandyIdNotFound(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public CandyIdNotFound(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public CandyIdNotFound(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public CandyIdNotFound(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
