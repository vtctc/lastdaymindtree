package com.mindtree.candies.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class CandyDto {
	
private int candyId;
	
	private String candyName;
	
	private double candyPrice;
	
	private int candyAvailableStock;
	@JsonIgnoreProperties("candy")
	List<ShopDto> shop;
	@JsonIgnoreProperties("candy")
	TypeDto type;

	public CandyDto() {
		super();
	}

	public CandyDto(int candyId, String candyName, double candyPrice, int candyAvailableStock, List<ShopDto> shop,
			TypeDto type) {
		super();
		this.candyId = candyId;
		this.candyName = candyName;
		this.candyPrice = candyPrice;
		this.candyAvailableStock = candyAvailableStock;
		this.shop = shop;
		this.type = type;
	}

	public int getCandyId() {
		return candyId;
	}

	public void setCandyId(int candyId) {
		this.candyId = candyId;
	}

	public String getCandyName() {
		return candyName;
	}

	public void setCandyName(String candyName) {
		this.candyName = candyName;
	}

	public double getCandyPrice() {
		return candyPrice;
	}

	public void setCandyPrice(double candyPrice) {
		this.candyPrice = candyPrice;
	}

	public int getCandyAvailableStock() {
		return candyAvailableStock;
	}

	public void setCandyAvailableStock(int candyAvailableStock) {
		this.candyAvailableStock = candyAvailableStock;
	}

	public List<ShopDto> getShop() {
		return shop;
	}

	public void setShop(List<ShopDto> shop) {
		this.shop = shop;
	}

	public TypeDto getType() {
		return type;
	}

	public void setType(TypeDto type) {
		this.type = type;
	}
	
	
	


}
