package com.mindtree.candies.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.candies.exception.controllerexception.CandiesControllerException;
import com.mindtree.candies.exception.serviceexception.CandiesServiceException;
import com.mindtree.candies.service.CandiesService;

@RestController
public class CandiesController {

	@Autowired
	CandiesService service;

	@GetMapping("/getAllCandies/{shopId}")
	public ResponseEntity<Map<String, Object>> getAllCandies(@PathVariable int shopId)
			throws CandiesControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "get all candies");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.getAllCandies(shopId));
		} catch (CandiesServiceException e) {
			throw new CandiesControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/getCandy/{shopId}/{candyId}/{quantity}")
	public ResponseEntity<Map<String, Object>> getCandy(@PathVariable int shopId, @PathVariable int candyId,
			@PathVariable int quantity) throws CandiesControllerException {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "getCandy");
		response.put("Error : ", false);
		try {
			response.put("body : ", service.getCandy(shopId, candyId, quantity));
		} catch (CandiesServiceException e) {
			throw new CandiesControllerException(e.getMessage(), e);
		}
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}

	@GetMapping("/getShopName/{typeId}")
	public ResponseEntity<Map<String, Object>> getShop(@PathVariable int typeId) {
		Map<String, Object> response = new HashMap<String, Object>();

		response.put("Headers : ", "getCandy");
		response.put("Error : ", false);
		response.put("body : ", service.getShopName(typeId));
		response.put("Http Status : ", HttpStatus.OK);

		return new ResponseEntity<Map<String, Object>>(response, HttpStatus.OK);

	}
}
