package com.mindtree.candies.service.serviceimpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.candies.dto.CandyDto;
import com.mindtree.candies.dto.ShopDto;
import com.mindtree.candies.dto.TypeDto;
import com.mindtree.candies.entity.Candy;
import com.mindtree.candies.entity.Shop;
import com.mindtree.candies.entity.Type;
import com.mindtree.candies.exception.serviceexception.CandiesServiceException;
import com.mindtree.candies.exception.serviceexception.CandyIdNotFound;
import com.mindtree.candies.exception.serviceexception.CandyNotInGivenShop;
import com.mindtree.candies.exception.serviceexception.CandyStockLessThanTheRequiredQuantity;
import com.mindtree.candies.exception.serviceexception.ShopIdDoesNotExist;
import com.mindtree.candies.repository.CandyRepository;
import com.mindtree.candies.repository.ShopRepository;
import com.mindtree.candies.repository.TypeRepository;
import com.mindtree.candies.service.CandiesService;

@Service
public class CandiesServiceImpl implements CandiesService {

	@Autowired
	CandyRepository candyRepository;

	@Autowired
	ShopRepository shopRepository;

	@Autowired
	TypeRepository typeRepository;

	ModelMapper modelMapper = new ModelMapper();

	public CandyDto convertCandyEntityToDto(Candy candy) {
		return modelMapper.map(candy, CandyDto.class);
	}

	public ShopDto convertShopEntityToDto(Shop shop) {
		return modelMapper.map(shop, ShopDto.class);
	}

	public TypeDto converTypeEntityToDto(Type type) {
		return modelMapper.map(type, TypeDto.class);
	}

	@Override
	public List<CandyDto> getAllCandies(int shopId) throws CandiesServiceException {

		Optional<Shop> shop = shopRepository.findById(shopId);
		try {
			shop.orElseThrow(() -> new ShopIdDoesNotExist("no such id is present"));
		} catch (ShopIdDoesNotExist e) {
			throw new CandiesServiceException(e.getMessage(), e);
		}

		Shop shops = shop.get();

		List<Candy> candies = shops.getCandy();

		List<CandyDto> candyDto = candies.stream().map(candy -> convertCandyEntityToDto(candy))
				.collect(Collectors.toList());

		return candyDto;
	}

	@Override
	public List<ShopDto> getShopName(int typeId) {

		Optional<Type> type = typeRepository.findById(typeId);

		Type types = type.get();

		Candy candy = types.getCandy();

		List<Shop> shops = candy.getShop();

		List<ShopDto> shopDto = shops.stream().map(s -> convertShopEntityToDto(s)).collect((Collectors.toList()));

		return shopDto;
	}

	@Override
	public String getCandy(int shopId, int candyId, int quantity) throws CandiesServiceException {

		Optional<Shop> shop = shopRepository.findById(shopId);
		try {
			shop.orElseThrow(() -> new ShopIdDoesNotExist("shop id is not exist"));

		} catch (ShopIdDoesNotExist e) {
			throw new CandiesServiceException(e.getMessage(), e);
		}
		Shop shops = shop.get();

		Optional<Candy> candy = candyRepository.findById(candyId);
		try {
			candy.orElseThrow(() -> new CandyIdNotFound("candy id is not found"));

		} catch (CandyIdNotFound e) {
			throw new CandiesServiceException(e.getMessage(), e);
		}
		Candy candys = candy.get();
		int flag = 0;
		List<Candy> can = shops.getCandy();
		for (Candy c : can) {
			if (c.getCandyId() == candys.getCandyId()) {
				flag = 1;
			}
		}
		if (flag == 0) {
			throw new CandyNotInGivenShop("candy is not in given shop");
		}
		if (quantity > candys.getCandyAvailableStock()) {
			throw new CandyStockLessThanTheRequiredQuantity("candy stock less then the required quantity");
		}
		float bill = 0;

		bill = (float) (quantity * candys.getCandyPrice() + 0.12f * candys.getCandyPrice()
				+ 0.02f * candys.getCandyPrice());

		return "bill generated successfully and total bill is " + bill;
	}

}
