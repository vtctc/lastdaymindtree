package com.mindtree.candies.exception.controllerexception;

import com.mindtree.candies.exception.CandiesException;

public class CandiesControllerException extends CandiesException {

	public CandiesControllerException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CandiesControllerException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public CandiesControllerException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public CandiesControllerException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public CandiesControllerException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
