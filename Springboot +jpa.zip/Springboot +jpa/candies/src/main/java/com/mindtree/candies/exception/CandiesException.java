package com.mindtree.candies.exception;

public class CandiesException extends Exception {

	public CandiesException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CandiesException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public CandiesException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public CandiesException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public CandiesException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}
	
	

}
