package com.mindtree.candies.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

@Entity
public class Candy {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int candyId;
	
	private String candyName;
	
	private double candyPrice;
	
	private int candyAvailableStock;
	
	@ManyToMany(cascade = CascadeType.PERSIST,fetch = FetchType.LAZY,mappedBy = "candy")
	List<Shop> shop;
	
	
	@OneToOne(fetch = FetchType.EAGER,mappedBy = "candy")
	Type type;


	public Candy() {
		super();
	}


	public Candy(int candyId, String candyName, double candyPrice, int candyAvailableStock, List<Shop> shop,
			Type type) {
		super();
		this.candyId = candyId;
		this.candyName = candyName;
		this.candyPrice = candyPrice;
		this.candyAvailableStock = candyAvailableStock;
		this.shop = shop;
		this.type = type;
	}


	public int getCandyId() {
		return candyId;
	}


	public void setCandyId(int candyId) {
		this.candyId = candyId;
	}


	public String getCandyName() {
		return candyName;
	}


	public void setCandyName(String candyName) {
		this.candyName = candyName;
	}


	public double getCandyPrice() {
		return candyPrice;
	}


	public void setCandyPrice(double candyPrice) {
		this.candyPrice = candyPrice;
	}


	public int getCandyAvailableStock() {
		return candyAvailableStock;
	}


	public void setCandyAvailableStock(int candyAvailableStock) {
		this.candyAvailableStock = candyAvailableStock;
	}


	public List<Shop> getShop() {
		return shop;
	}


	public void setShop(List<Shop> shop) {
		this.shop = shop;
	}


	public Type getType() {
		return type;
	}


	public void setType(Type type) {
		this.type = type;
	}
	
	
	

}
