package com.mindtree.candies.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

public class TypeDto {
	
private int typeId;
	
    private String typeName;
    
    @JsonIgnoreProperties("type")
    CandyDto candy;

	public TypeDto() {
		super();
	}

	public TypeDto(int typeId, String typeName, CandyDto candy) {
		super();
		this.typeId = typeId;
		this.typeName = typeName;
		this.candy = candy;
	}

	public int getTypeId() {
		return typeId;
	}

	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public CandyDto getCandy() {
		return candy;
	}

	public void setCandy(CandyDto candy) {
		this.candy = candy;
	}
    


}
