package com.mindtree.employeemvc.exception.serviceexception;

import com.mindtree.employeemvc.exception.EmployeeException;

public class EmployeeServiceException extends EmployeeException {

	public EmployeeServiceException() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeServiceException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public EmployeeServiceException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public EmployeeServiceException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public EmployeeServiceException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
