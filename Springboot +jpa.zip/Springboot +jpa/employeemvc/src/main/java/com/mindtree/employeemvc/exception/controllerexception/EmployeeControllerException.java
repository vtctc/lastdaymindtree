package com.mindtree.employeemvc.exception.controllerexception;

import com.mindtree.employeemvc.exception.EmployeeException;

public class EmployeeControllerException extends EmployeeException {

	public EmployeeControllerException() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeControllerException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public EmployeeControllerException(String description, Throwable cause) {
		super(description, cause);
		// TODO Auto-generated constructor stub
	}

	public EmployeeControllerException(String description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

	public EmployeeControllerException(Throwable description) {
		super(description);
		// TODO Auto-generated constructor stub
	}

}
