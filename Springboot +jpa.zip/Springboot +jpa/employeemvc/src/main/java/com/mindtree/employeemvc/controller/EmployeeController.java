package com.mindtree.employeemvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mindtree.employeemvc.entity.Employee;
import com.mindtree.employeemvc.exception.controllerexception.EmployeeControllerException;
import com.mindtree.employeemvc.exception.serviceexception.EmployeeServiceException;
import com.mindtree.employeemvc.service.EmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private EmployeeService service;
	
	@GetMapping("/")
	public String homePage() {
		
		return "index";
	}
	
	@GetMapping("/insert")
	public String employeeForm() {
		
		return "employeeform";
	}
	
	@PostMapping("/addemployee")
	public String addEmployee(Employee employee) {
		
		service.insertEmployee(employee);
		
		return "employeeform";
	}
	
	@GetMapping("/display")
	public String displayForm() {
		
		return "displayuser";
	}
	
	@PostMapping("/displayemployee")
	public String displayUser(@RequestParam  String employeeName,Model model) throws EmployeeControllerException {
		
		Employee employee;
		try {
			employee = service.getEmployee(employeeName);
		} catch (EmployeeServiceException e) {
		throw new EmployeeControllerException(e.getMessage(),e);
		}
		model.addAttribute("employee", employee);
		return "displayuser";
	}
	
	@GetMapping("/displayall")
	public String allEmployees(Model model) {
		
		List<Employee> employees = service.getAllEmployees();
		model.addAttribute("employees", employees);
		return "displayallusers";
	}
}
