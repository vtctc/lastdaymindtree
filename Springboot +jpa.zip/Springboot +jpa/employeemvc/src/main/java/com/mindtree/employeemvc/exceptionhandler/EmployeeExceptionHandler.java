package com.mindtree.employeemvc.exceptionhandler;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.mindtree.employeemvc.controller.EmployeeController;
import com.mindtree.employeemvc.exception.controllerexception.EmployeeControllerException;

@ControllerAdvice(assignableTypes = {EmployeeController.class})
public class EmployeeExceptionHandler {
	
	@ExceptionHandler
	public String exceptionHandler(EmployeeControllerException c, Model model) {
		
		Map<String,Object> error = new LinkedHashMap<String, Object>();
		error.put("message", c.getMessage());
		error.put("timestamp",new Date());
		error.put("httpstatus", HttpStatus.NOT_FOUND.value());
		
		model.addAttribute("error",error);
		return "errorpage";
	}

	

}
