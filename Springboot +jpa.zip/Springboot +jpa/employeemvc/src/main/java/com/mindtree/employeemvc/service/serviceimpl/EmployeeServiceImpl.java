package com.mindtree.employeemvc.service.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.employeemvc.entity.Employee;
import com.mindtree.employeemvc.exception.serviceexception.EmployeeServiceException;
import com.mindtree.employeemvc.exception.serviceexception.NoSuchStudentException;
import com.mindtree.employeemvc.repository.EmployeeRepository;
import com.mindtree.employeemvc.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public void insertEmployee(Employee employee) {
		
		employeeRepository.save(employee);
		
	}

	@Override
	public Employee getEmployee(String employeeName) throws EmployeeServiceException {
		
		Optional<Employee> employee = employeeRepository.findByemployeeName(employeeName);
		
		try {
			employee.orElseThrow(()->new NoSuchStudentException("No Such Employee"));
		} catch (NoSuchStudentException e) {
			throw new EmployeeServiceException(e.getMessage(),e);
		}
		
		return employee.get();
	}

	@Override
	public List<Employee> getAllEmployees() {
		
		return employeeRepository.findAll();
	}
}
