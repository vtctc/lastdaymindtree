package com.mindtree.employeemvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.mindtree.employeemvc.entity.Employee;
import com.mindtree.employeemvc.exception.serviceexception.EmployeeServiceException;

@Service
public interface EmployeeService {

	void insertEmployee(Employee employee);

	Employee getEmployee(String employeeName) throws EmployeeServiceException;

	List<Employee> getAllEmployees();

}
