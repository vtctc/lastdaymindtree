package com.mindtree.employeemvc.exception;

public class EmployeeException extends Exception {

	public EmployeeException() {
		super();
	}

	public EmployeeException(String description, Throwable cause, boolean arg2, boolean arg3) {
		super(description, cause, arg2, arg3);
	}

	public EmployeeException(String description, Throwable cause) {
		super(description, cause);
	}

	public EmployeeException(String description) {
		super(description);
	}

	public EmployeeException(Throwable description) {
		super(description);
	}

}
