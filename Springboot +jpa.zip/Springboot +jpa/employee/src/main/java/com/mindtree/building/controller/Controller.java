package com.mindtree.building.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.building.entity.Employee;
import com.mindtree.building.service.EmployeeServiceInterface;

@RestController
@CrossOrigin(origins = "*")
public class Controller {

	@Autowired
	EmployeeServiceInterface serviceObject;

	@GetMapping("/hello")
	public List<String> sayHello() {
		List<String> myList = new ArrayList<String>();
		myList.add("ayush");
		myList.add("bajaj");
		myList.add("shailendra");
		myList.add("prada");
		myList.add("ram sai");
		myList.add("eshwar");
		return myList;
	}

	@PostMapping("/insert")
	public Employee addemployee(@RequestBody Employee employee) {
		System.err.println(employee);
		serviceObject.adddetails(employee);
		return employee;
	}

}
