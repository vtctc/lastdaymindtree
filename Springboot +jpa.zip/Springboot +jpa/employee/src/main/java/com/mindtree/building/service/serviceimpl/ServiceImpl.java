package com.mindtree.building.service.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.building.entity.Employee;
import com.mindtree.building.repository.EmployeeRepository;
import com.mindtree.building.service.EmployeeServiceInterface;

@Service
public class ServiceImpl implements EmployeeServiceInterface{

	@Autowired
	EmployeeRepository Repos;
	
	@Override
	public void adddetails(Employee employee) {
		
		Repos.save(employee);
	}

}
