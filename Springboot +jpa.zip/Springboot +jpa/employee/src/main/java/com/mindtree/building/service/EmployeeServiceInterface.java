package com.mindtree.building.service;

import com.mindtree.building.entity.Employee;

public interface EmployeeServiceInterface {

	void adddetails(Employee employee);

}
