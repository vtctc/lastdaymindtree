import { Component, OnInit } from '@angular/core';
import { CityServiceService } from '../city-service.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  constructor(private serviceObject:CityServiceService) { }
cityList:any;
exception:any;
  ngOnInit() {
    this.serviceObject.getCity().subscribe(abc=>this.cityList=abc,error=>this.exception=error);
  }

}
