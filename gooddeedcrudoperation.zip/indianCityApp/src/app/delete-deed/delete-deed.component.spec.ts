import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteDeedComponent } from './delete-deed.component';

describe('DeleteDeedComponent', () => {
  let component: DeleteDeedComponent;
  let fixture: ComponentFixture<DeleteDeedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeleteDeedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteDeedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
