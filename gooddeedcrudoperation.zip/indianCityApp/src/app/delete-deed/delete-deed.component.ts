import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CityServiceService } from '../city-service.service';
@Component({
  selector: 'app-delete-deed',
  templateUrl: './delete-deed.component.html',
  styleUrls: ['./delete-deed.component.css']
})
export class DeleteDeedComponent implements OnInit {

  constructor(private serviceobject: CityServiceService) { }
  error: any;
  result: any;
  goodDeedList: any;
    ngOnInit() {
      this.serviceobject.getAllDeed().subscribe(data => this.goodDeedList = data);
    }
  
  formforDelete = new FormGroup({
    gName: new FormControl('')
  })
  
  onSubmit() {
    this.serviceobject.deleteDeed(this.formforDelete.value.gName).subscribe(data=>{
      this.result=data.Body;
      this.error=null;
    },error=>{
      this.error=error.error.BODY;
      this.result=null;
    });
  }

}
