import { CampusMind } from './campus-mind';

export class GoodDeed {
    goodDeedId:number;
    goodDeedName:String;
    campusMinds:CampusMind[];
}
