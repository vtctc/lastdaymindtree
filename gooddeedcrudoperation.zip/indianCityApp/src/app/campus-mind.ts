export class CampusMind {
    mName:String;
}
