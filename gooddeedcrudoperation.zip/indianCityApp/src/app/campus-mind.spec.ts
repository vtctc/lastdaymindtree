import { CampusMind } from './campus-mind';

describe('CampusMind', () => {
  it('should create an instance', () => {
    expect(new CampusMind()).toBeTruthy();
  });
});
