import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { GoodDeed } from './good-deed';
import { CampusMind } from './campus-mind';

@Injectable({
  providedIn: 'root'
})
export class CityServiceService {

  constructor(private http:HttpClient) { }
  getCity():any
  {
    return this.http.get("https://indian-cities-api-nocbegfhqg.now.sh/cities");
  }
  insertGoodDeed(goodDeed:GoodDeed):any
  {
    return this.http.post("http://localhost:8080/insertgooddeed",goodDeed);
  }
  insertCampusMind(campusmind:CampusMind,goodDeedId:number):any
  {
    return this.http.post("http://localhost:8080/insertcampusMind/"+goodDeedId,campusmind);
  }
  getAllCampusMindBYId(goodDeedId:number):any
  {
    return this.http.get("http://localhost:8080/getAllCampusMind/"+goodDeedId);
  }
  getAllDeed():any
  {
    return this.http.get("http://localhost:8080/getGoodDeed");
  }
  deleteDeed(goodDeedId:number):any
  {
    return this.http.delete("http://localhost:8080/deleteTheGoodded/"+goodDeedId);
  }
  updateDeed(goodDeedId:number,goodeedName:String):any
  {
    return this.http.put("http://localhost:8080/updateTheGooddeed/"+goodDeedId+"/"+goodeedName,goodDeedId);
  }
}
