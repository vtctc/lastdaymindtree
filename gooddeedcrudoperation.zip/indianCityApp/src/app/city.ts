export class City {
    City: String;
    State: String;
    District: String;
}
