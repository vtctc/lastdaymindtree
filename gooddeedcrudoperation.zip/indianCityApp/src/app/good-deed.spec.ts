import { GoodDeed } from './good-deed';

describe('GoodDeed', () => {
  it('should create an instance', () => {
    expect(new GoodDeed()).toBeTruthy();
  });
});
