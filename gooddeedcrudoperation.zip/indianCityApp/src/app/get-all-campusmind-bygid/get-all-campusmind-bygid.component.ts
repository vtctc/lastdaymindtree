import { Component, OnInit } from '@angular/core';
import { CityServiceService } from '../city-service.service';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-get-all-campusmind-bygid',
  templateUrl: './get-all-campusmind-bygid.component.html',
  styleUrls: ['./get-all-campusmind-bygid.component.css']
})
export class GetAllCampusmindBYGIdComponent implements OnInit {

  constructor(private serviceobject: CityServiceService) { }
  error: any;
  result: any;
  ngOnInit() {
  }
  findByIdCampusMind = new FormGroup({
    gId: new FormControl('')
  })
  onSubmit() {
    this.serviceobject.getAllCampusMindBYId(this.findByIdCampusMind.value.gId).subscribe(data=>{
      this.result=data.Body;
      this.error=null;
    },error=>{
      this.error=error.error.BODY;
      this.result=null;
    });
  }
}
