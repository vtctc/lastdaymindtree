import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetAllCampusmindBYGIdComponent } from './get-all-campusmind-bygid.component';

describe('GetAllCampusmindBYGIdComponent', () => {
  let component: GetAllCampusmindBYGIdComponent;
  let fixture: ComponentFixture<GetAllCampusmindBYGIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetAllCampusmindBYGIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetAllCampusmindBYGIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
