import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertgooddeedComponent } from './insertgooddeed.component';

describe('InsertgooddeedComponent', () => {
  let component: InsertgooddeedComponent;
  let fixture: ComponentFixture<InsertgooddeedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsertgooddeedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsertgooddeedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
