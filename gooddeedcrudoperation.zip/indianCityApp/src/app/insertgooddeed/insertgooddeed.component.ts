import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CityServiceService } from '../city-service.service';
import { GoodDeed } from '../good-deed';
@Component({
  selector: 'app-insertgooddeed',
  templateUrl: './insertgooddeed.component.html',
  styleUrls: ['./insertgooddeed.component.css']
})
export class InsertgooddeedComponent implements OnInit {

  constructor(private serviceobject:CityServiceService) { }
  deed: GoodDeed;
  result:any;
  ngOnInit() {
  }
  GoodDeedForm = new FormGroup({
    gName: new FormControl('')
  })
  onSubmit()
  {
    this.deed=new GoodDeed();
    this.deed.goodDeedName=this.GoodDeedForm.value.gName;
    this.serviceobject.insertGoodDeed(this.deed).subscribe(data=>this.result=data);
  }
}

