import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DisplayComponent } from './display/display.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';
import { InsertgooddeedComponent } from './insertgooddeed/insertgooddeed.component';
import { InsertcampusmindComponent } from './insertcampusmind/insertcampusmind.component';
import { GetAllCampusmindBYGIdComponent } from './get-all-campusmind-bygid/get-all-campusmind-bygid.component';
import { UpdateDeedComponent } from './update-deed/update-deed.component';
import { DeleteDeedComponent } from './delete-deed/delete-deed.component';

@NgModule({
  declarations: [
    AppComponent,
    DisplayComponent,
    InsertgooddeedComponent,
    InsertcampusmindComponent,
    GetAllCampusmindBYGIdComponent,
    UpdateDeedComponent,
    DeleteDeedComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],

  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
