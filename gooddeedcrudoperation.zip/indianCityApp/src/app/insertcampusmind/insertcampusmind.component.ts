import { Component, OnInit } from '@angular/core';
import { CityServiceService } from '../city-service.service';
import { FormGroup, FormControl } from '@angular/forms';
import { CampusMind } from '../campus-mind';
@Component({
  selector: 'app-insertcampusmind',
  templateUrl: './insertcampusmind.component.html',
  styleUrls: ['./insertcampusmind.component.css']
})
export class InsertcampusmindComponent implements OnInit {

  constructor(private serviceObject: CityServiceService) { }
  result1: any;
  goodDeedList: any;
  ngOnInit() {
    this.serviceObject.getAllDeed().subscribe(data => this.goodDeedList = data);
  }
  campusMind: any;
  campusMindForm = new FormGroup({
    gName: new FormControl(''),
    cName: new FormControl('')
  })
  onSubmit() {
    this.campusMind = new CampusMind();
    this.campusMind.mName = this.campusMindForm.value.cName;
    this.serviceObject.insertCampusMind(this.campusMind, this.campusMindForm.value.gName).subscribe(data => this.result1 = data);
  }
}
