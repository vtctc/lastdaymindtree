import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertcampusmindComponent } from './insertcampusmind.component';

describe('InsertcampusmindComponent', () => {
  let component: InsertcampusmindComponent;
  let fixture: ComponentFixture<InsertcampusmindComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsertcampusmindComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsertcampusmindComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
