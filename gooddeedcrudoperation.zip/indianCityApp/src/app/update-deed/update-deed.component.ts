import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { CityServiceService } from '../city-service.service';
@Component({
  selector: 'app-update-deed',
  templateUrl: './update-deed.component.html',
  styleUrls: ['./update-deed.component.css']
})
export class UpdateDeedComponent implements OnInit {

  constructor(private serviceobject: CityServiceService) { }
  error: any;
  result: any;
  goodDeedList: any;
    ngOnInit() {
      this.serviceobject.getAllDeed().subscribe(data => this.goodDeedList = data);
    }
  
    formforUpdate = new FormGroup({
      gName: new FormControl(''),
    updatedGName: new FormControl('')
  })
  
  onSubmit() {
    this.serviceobject.updateDeed(this.formforUpdate.value.gName,this.formforUpdate.value.updatedGName).subscribe(data=>{
      this.result=data.Body;
      this.error=null;
    },error=>{
      this.error=error.error.BODY;
      this.result=null;
    });
  }

}
