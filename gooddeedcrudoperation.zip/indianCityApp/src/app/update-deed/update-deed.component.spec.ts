import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateDeedComponent } from './update-deed.component';

describe('UpdateDeedComponent', () => {
  let component: UpdateDeedComponent;
  let fixture: ComponentFixture<UpdateDeedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateDeedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateDeedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
