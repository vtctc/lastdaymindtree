import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayComponent } from './display/display.component';
import { InsertgooddeedComponent } from './insertgooddeed/insertgooddeed.component';
import { InsertcampusmindComponent } from './insertcampusmind/insertcampusmind.component';
import { GetAllCampusmindBYGIdComponent } from './get-all-campusmind-bygid/get-all-campusmind-bygid.component';
import { DeleteDeedComponent } from './delete-deed/delete-deed.component';
import { UpdateDeedComponent } from './update-deed/update-deed.component';


const routes: Routes = [{ path: 'display', component: DisplayComponent },
{path:'gooddeed',component:InsertgooddeedComponent},
{path:'campusmind',component:InsertcampusmindComponent},
{path:'getAllcampusmind',component:GetAllCampusmindBYGIdComponent},
{path:'deletegooddeed',component:DeleteDeedComponent},
{path:'updategooddeed',component:UpdateDeedComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
