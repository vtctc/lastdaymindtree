package com.mindtree.kalingachainofcafe.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.kalingachainofcafe.dto.CafeDto;
import com.mindtree.kalingachainofcafe.dto.CafeManagerDto;
import com.mindtree.kalingachainofcafe.entity.Cafe;
import com.mindtree.kalingachainofcafe.service.KalingaChainOfCafeService;

@RestController
public class Controller {
	
	@Autowired
	KalingaChainOfCafeService kalingaService;
	 
	@PostMapping("/insert")
	public String insert(@RequestBody CafeDto cafeDto)
	{
		System.out.println(cafeDto.toString());
		String s= kalingaService.addCafeWithManager(cafeDto);
		return s;
	}
	
//	@GetMapping("/getall")
//	public List<CafeDto> getall(){
//		List<Cafe> cafe = kalingaService.getall();
//		List<CafeDto> cafedtolist = new ArrayList<CafeDto>();
//		CafeDto cafedto = new CafeDto();
//		for (Cafe cafe2 : cafe) {
//			cafedto.setCafeId(cafe2.getCafeId());
//			cafedto.setCafeName(cafe2.getCafeName());
//			cafedto.setCafeRevenue(cafe2.getCafeRevenue());
//			CafeManagerDto cafemanager = new CafeManagerDto();
//			cafemanager.setManagerId(cafe2.getCafeManager().getManagerId());
//			cafemanager.setManagerName(cafe2.getCafeManager().getManagerName());
//			cafedto.setCafeManager(cafemanager);
//			cafedtolist.add(cafedto);
//		}
//		
//		return cafedtolist;
//		
//		
//	}
   @GetMapping("/getall/{id}")
   public List<CafeDto> getall(@PathVariable int id)
   {
	   List<CafeDto> cafeDto=kalingaService.getdata(id);
	   return cafeDto;
   }
	
   @GetMapping("/getdetails/{revenue}")
   public List<CafeDto> getdetails(@PathVariable float revenue)
   {
	   List<CafeDto> cafeDto=kalingaService.getdetails(revenue);
	   return cafeDto;
   }
	
}
