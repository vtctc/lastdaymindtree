package com.mindtree.kalingachainofcafe.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@Entity
public class CafeManager {
	
	@Id
	private int managerId;
	
	private String managerName;
	
	private float managerSalary;
	

	@OneToMany(cascade = CascadeType.ALL,fetch = FetchType.LAZY,mappedBy = "cafeManager")
	//@JoinColumn(name="managerId")
	private List<Cafe> cafe;


	public int getManagerId() {
		return managerId;
	}


	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}


	public String getManagerName() {
		return managerName;
	}


	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}


	public float getManagerSalary() {
		return managerSalary;
	}


	public void setManagerSalary(float managerSalary) {
		this.managerSalary = managerSalary;
	}


	public List<Cafe> getCafe() {
		return cafe;
	}


	public void setCafe(List<Cafe> cafe) {
		this.cafe = cafe;
	}


	public CafeManager(int managerId, String managerName, float managerSalary, List<Cafe> cafe) {
		super();
		this.managerId = managerId;
		this.managerName = managerName;
		this.managerSalary = managerSalary;
		this.cafe = cafe;
	}


	public CafeManager() {
		super();
	}
	
	
	
}
