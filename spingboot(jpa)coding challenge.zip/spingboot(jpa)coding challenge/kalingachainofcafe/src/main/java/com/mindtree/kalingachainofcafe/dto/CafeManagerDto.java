package com.mindtree.kalingachainofcafe.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CafeManagerDto {
	
	
	private int managerId;
	
	private String managerName;
	
	private float managerSalary;
	

	private List<CafeDto> cafeDto;


	public CafeManagerDto() {
		super();
		 
	}


	public CafeManagerDto(int managerId, String managerName, float managerSalary, List<CafeDto> cafeDto) {
		this.managerId = managerId;
		this.managerName = managerName;
		this.managerSalary = managerSalary;
		this.cafeDto = cafeDto;
	}


	public int getManagerId() {
		return managerId;
	}


	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}


	public String getManagerName() {
		return managerName;
	}


	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}


	public float getManagerSalary() {
		return managerSalary;
	}


	public void setManagerSalary(float managerSalary) {
		this.managerSalary = managerSalary;
	}


	public List<CafeDto> getCafe() {
		return cafeDto;
	}


	public void setCafe(List<CafeDto> cafeDto) {
		this.cafeDto = cafeDto;
	}



}
