package com.mindtree.kalingachainofcafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KalingachainofcafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(KalingachainofcafeApplication.class, args);
	}

}
