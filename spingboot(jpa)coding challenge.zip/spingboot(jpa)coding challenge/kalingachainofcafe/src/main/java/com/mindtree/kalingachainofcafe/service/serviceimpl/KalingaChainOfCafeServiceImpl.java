package com.mindtree.kalingachainofcafe.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.kalingachainofcafe.dto.CafeDto;
import com.mindtree.kalingachainofcafe.dto.CafeManagerDto;
import com.mindtree.kalingachainofcafe.entity.Cafe;
import com.mindtree.kalingachainofcafe.entity.CafeManager;
import com.mindtree.kalingachainofcafe.repository.CafeManagerRepository;
import com.mindtree.kalingachainofcafe.repository.CafeRepository;
import com.mindtree.kalingachainofcafe.service.KalingaChainOfCafeService;

@Service
public class KalingaChainOfCafeServiceImpl implements KalingaChainOfCafeService{
	
	@Autowired
	CafeManagerRepository cafeManagerRepos;
	
	@Autowired
	CafeRepository cafeRepos;

	@Override
	public String addCafeWithManager(CafeDto cafeDto) {

      CafeManager cafeManager=new CafeManager(cafeDto.getCafeManager().getManagerId(),cafeDto.getCafeManager().getManagerName(),cafeDto.getCafeManager().getManagerSalary(),null);		
      Cafe cafe=new Cafe(cafeDto.getCafeId(),cafeDto.getCafeName(),cafeDto.getCafeRevenue(),cafeManager);
		
      cafeManagerRepos.save(cafeManager);
      cafeRepos.save(cafe);
      
		return "inserted successfully";
	}

	@Override
	public List<CafeDto> getdata(int id) {
		 
		 List<CafeDto> cafeDto=new ArrayList<CafeDto>();
		 
		 if(this.cafeManagerRepos.existsById(id))
		 {
		     CafeManager cafeManager=cafeManagerRepos.getOne(id);
		     
		      for(Cafe cafe:cafeManager.getCafe())
		      {
		    	  CafeDto cafedto=new CafeDto(cafe.getCafeId(),cafe.getCafeName(),cafe.getCafeRevenue(),null);
		    	  cafeDto.add(cafedto);	      
		      }
		}
		return cafeDto;
}

	@Override
	public List<CafeDto> getdetails(float revenue) {
		
		List<CafeDto> cafedto=new ArrayList<CafeDto>();
		
		List<Cafe> cafes=cafeRepos.findAll();
		
		for(Cafe cafe:cafes)
		{
			if(cafe.getCafeRevenue()>revenue)	{
				CafeManagerDto cafemanagerDto=new CafeManagerDto(cafe.getCafeManager().getManagerId(),cafe.getCafeManager().getManagerName(),cafe.getCafeManager().getManagerSalary(),null);
		         CafeDto cafeDto=new CafeDto(cafe.getCafeId(),cafe.getCafeName(),cafe.getCafeRevenue(),cafemanagerDto);
			     cafedto.add(cafeDto);
			}
		}
		return cafedto;
	}
	
	 
}
	
		 
		 
		 
		 
		 
		 
		 //@Override
	//public List<Cafe> getall() {
		
	//	return cafeRepos.findAll();
//	}

	 
	
	 


