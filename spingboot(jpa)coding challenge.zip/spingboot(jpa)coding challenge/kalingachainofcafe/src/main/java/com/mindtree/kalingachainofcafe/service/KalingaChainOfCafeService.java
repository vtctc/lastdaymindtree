package com.mindtree.kalingachainofcafe.service;

import java.util.List;

import com.mindtree.kalingachainofcafe.dto.CafeDto;
import com.mindtree.kalingachainofcafe.dto.CafeManagerDto;
import com.mindtree.kalingachainofcafe.entity.Cafe;

public interface KalingaChainOfCafeService {

	String addCafeWithManager(CafeDto cafeDto);
	
	//List<Cafe> getall();

	List<CafeDto> getdata(int id);

	List<CafeDto> getdetails(float revenue);

}
