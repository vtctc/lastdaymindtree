package com.mindtree.kalingachainofcafe.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;


@Entity
public class Cafe {
		
		@Id
		private int cafeId;
		
		private String cafeName;
		
		private float cafeRevenue;
		
		@OneToOne(fetch = FetchType.LAZY)
		private CafeManager cafeManager;

		public int getCafeId() {
			return cafeId;
		}

		public void setCafeId(int cafeId) {
			this.cafeId = cafeId;
		}

		public String getCafeName() {
			return cafeName;
		}

		public void setCafeName(String cafeName) {
			this.cafeName = cafeName;
		}

		public float getCafeRevenue() {
			return cafeRevenue;
		}

		public void setCafeRevenue(float cafeRevenue) {
			this.cafeRevenue = cafeRevenue;
		}

		public CafeManager getCafeManager() {
			return cafeManager;
		}

		public void setCafeManager(CafeManager cafeManager) {
			this.cafeManager = cafeManager;
		}

		public Cafe(int cafeId, String cafeName, float cafeRevenue, CafeManager cafeManager) {
			this.cafeId = cafeId;
			this.cafeName = cafeName;
			this.cafeRevenue = cafeRevenue;
			this.cafeManager = cafeManager;
		}

		public Cafe() {
		}

		 
		

}
