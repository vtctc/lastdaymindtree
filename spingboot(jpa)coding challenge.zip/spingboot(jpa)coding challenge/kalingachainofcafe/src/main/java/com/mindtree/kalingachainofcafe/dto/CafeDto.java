package com.mindtree.kalingachainofcafe.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class CafeDto {
	
 
	private int cafeId;
	
	private String cafeName;
	
	private float cafeRevenue;
	
	private CafeManagerDto cafeManagerDto;

	public CafeDto() {
		super();
		 
	}

	public CafeDto(int cafeId, String cafeName, float cafeRevenue, CafeManagerDto cafeManagerDto) {
		this.cafeId = cafeId;
		this.cafeName = cafeName;
		this.cafeRevenue = cafeRevenue;
		this.cafeManagerDto = cafeManagerDto;
	}

	public int getCafeId() {
		return cafeId;
	}

	public void setCafeId(int cafeId) {
		this.cafeId = cafeId;
	}

	public String getCafeName() {
		return cafeName;
	}

	public void setCafeName(String cafeName) {
		this.cafeName = cafeName;
	}

	public float getCafeRevenue() {
		return cafeRevenue;
	}

	public void setCafeRevenue(float cafeRevenue) {
		this.cafeRevenue = cafeRevenue;
	}

	public CafeManagerDto getCafeManager() {
		return cafeManagerDto;
	}

	

	@Override
	public String toString() {
		return "CafeDto [cafeId=" + cafeId + ", cafeName=" + cafeName + ", cafeRevenue=" + cafeRevenue
				+ ", cafeManager=" + cafeManagerDto + "]";
	}

	public CafeManagerDto getCafeManagerDto() {
		return cafeManagerDto;
	}

	public void setCafeManagerDto(CafeManagerDto cafeManagerDto) {
		this.cafeManagerDto = cafeManagerDto;
	}

	
	

}
