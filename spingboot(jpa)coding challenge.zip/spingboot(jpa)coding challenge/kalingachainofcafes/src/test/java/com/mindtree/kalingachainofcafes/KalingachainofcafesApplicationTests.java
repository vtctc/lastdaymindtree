package com.mindtree.kalingachainofcafes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KalingachainofcafesApplicationTests {

	@Test
	void contextLoads() {
	}

}
