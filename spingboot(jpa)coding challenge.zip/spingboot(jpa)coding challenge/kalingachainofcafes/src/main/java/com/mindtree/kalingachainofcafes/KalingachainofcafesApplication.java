package com.mindtree.kalingachainofcafes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KalingachainofcafesApplication {

	public static void main(String[] args) {
		SpringApplication.run(KalingachainofcafesApplication.class, args);
	}

}
