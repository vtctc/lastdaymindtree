#include<iostream>
#include<string>
using namespace std;
class Employee
{  
   public:
   	int empid;
   	string name;
   	string design;
   	string dept;
   	void setter(int e,string n)
   	  { 
		 empid=e;
		 name=n;
   	   }
   	 void getter()
   	   {
   	 	
			cout<<"enter empid= "<<empid<<endl;
			cout<<" enter name="<<name<<endl;;
	   }
   	
   	display()
   	{
   		cout<<"empid="<<empid<<endl;
   		cout<<"name ="<<name<<endl;
   		cout<<"design="<<design<<endl;
   		cout<<"dept="<<dept<<endl;
	   }
   	Employee()
   	{ empid=1;
   	  name="hello";
   	  design=" eng ";
   	  dept="cs";
   	}
   	Employee(int empid,string name,string design,string dept)
   	{ 
   	  this->empid=empid;
   	  this->name=name;
   	  this->design=design;
   	  this->dept=dept;
   	}
};
int main()
{ Employee E1,E3;
  E1.display();
  Employee E2(1,"waqar","doctor","opd");
  E2.display();
  E3.setter(100,"adu");
  E3.getter();
 	return 0;
}
