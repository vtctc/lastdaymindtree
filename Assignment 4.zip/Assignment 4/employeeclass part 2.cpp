#include<iostream.h>
using namespace std;
class Employee
{
	public:
	     int empid;
   	     string empname;
   	     string empdesign;
   	     string empdept;
   	     getter()
   	     {
   	     	cout<<empname<<" ";
   	     	cout<<empdesign<<" ";
   	     	cout<<empdept<<" ";
   	     	
		}
		void setter(string empname,string empdesign,string empdept)
		{
			if(setEmpName(empname))
			{
				empname=empname;
			}
             if(empDesign(empdesign))
            {
            	empdesign=empdesign;
			 }  
			 if(empDept(empdept))
			 {
			 	empdept=empdept;
			  }            
		}
   	    bool setEmpName(empname)
		 {  if(empname!=NULL)
   	         {
   	         	cout<<" name entered "<<endl;
   	         	return true
   	         else
   	         cout<<"enter the name"<<endl;
				return false;
   	     }
   	    bool empDesign(empdesign)
		{  if(design=="Devloper")||(design=="Tester")||(design=="Lead")||(design=="Manager"))
   	         cout<<empdesign;
   	         exit(0);
   	         else
   	         cout<<"error";
   	     }
   	    void empDept(empdept)
			 {
			 if((empdept=="TTH")||(empdept=="RCM")||(empdept=="Digital")||(empdept=="Devlops"))
   	          cout<<empdept;
   	          exit(0);
   	          
   	          else
   	          cout<<"error";
   	        }
};
int main()
{ string empname,empdesign,empdept;
 cout<<"enter the empname"<<endl;
 cin>>empname;
 cout<<"enter the empdesign"<<endl;
 cin>>empdesign;
 cout<<" enter the empdep" <<endl;
 cin>>empdept;
 setter(empname,empdesign,emdept);
 getter();
 return 0;
}
 
}



