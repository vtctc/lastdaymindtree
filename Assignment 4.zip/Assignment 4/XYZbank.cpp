#include<iostream>
#include<string>
class XYZbank
{
	private:
		 int id;
		 string name;
		 string address;
		 string Atype;
		 float balance;
	public:
		
	
	
}
