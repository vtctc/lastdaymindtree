#include<iostream>
#include<string>
using namespace std;
class bookStore
{  private:
	string booktitle;
	float bookprice;
	int  ypublication;
	string aname;
	public:
		
	 void set(string Booktitle,float Bookprice,int Ypublication,string Aname)
	{ 
	   aname=Aname;
	   booktitle=Booktitle;
	   bookprice=Bookprice;
	   ypublication=Ypublication;
	}
	
	string getaname()
	{
		return aname;
	}
	string getbooktitle()
	{
		return booktitle;
	}
	float getbookprice()
	{
	     return bookprice;
	}
	int getypublication()
	{
	    return ypublication;
    }   
};
int main()
{
	bookStore b1,b2,b3;
	b1.set("Robinson",15.50,1719,"Daniel Dafoe");
	b2.set("Heart of Darkness",12.80,1902," joseph conrad");
	b3.set("Beach Music",9.50,1996,"pat corroy");
    cout<<b1.getaname()<<" "<<b1.getbooktitle()<<" "<<b1.getbookprice()<<" "<<b1.getypublication()<<endl;
	cout<<b2.getaname()<<" "<<b2.getbooktitle()<<" "<<b2.getbookprice()<<" "<<b2.getypublication()<<endl;
	cout<<b3.getaname()<<" "<<b3.getbooktitle()<<b3.getbookprice()<<" "<<b3.getypublication()<<endl;
	
	return 0;
	
}
