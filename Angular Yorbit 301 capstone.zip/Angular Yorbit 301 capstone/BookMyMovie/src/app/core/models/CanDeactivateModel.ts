import { Observable } from 'rxjs';

export interface CanDeactivateModel {
    isDirty(): boolean;
    //canDeactivate: () => boolean | Observable<boolean>;
}