import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, getTestBed, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { Store, StoreModule } from '@ngrx/store';
import { MockStore, provideMockStore } from '@ngrx/store/testing';
import { User } from '../../models/user.model';
import { UserState } from '../../store/reducers/userDetails.reducer';
import { AuthGuard } from './authguard.service';


describe('AuthGuardService', () => {
    let injector: TestBed;
    let guard: AuthGuard;
    let uservalid: User;
    const userInvalid = null;
    uservalid = {
        id: '1',
        name: 'Sayan',
        email: 'abc',
        image: 'fhfj',
        token: 'hsjj',
        role: 'jaja',
        preference: null,
        rating: null
    };
    let store: MockStore<{ user: UserState }>;
    const initialState = { user: uservalid };
    const dummyState = { user: userInvalid };
    const routeMock: any = { snapshot: {} };
    const routeStateMock: any = { snapshot: {}, url: '/cookies' };
    const routerMock = { navigate: jasmine.createSpy('navigate') };

    beforeEach(async(() => {
        TestBed.configureTestingModule({

            imports: [HttpClientTestingModule, StoreModule.forRoot({})],
            declarations: [
            ],
            providers: [AuthGuard, { provide: Router, useValue: routerMock }, provideMockStore({ initialState })],

        }).compileComponents();
    }));

    beforeEach(() => {
        injector = getTestBed();
        guard = injector.get(AuthGuard);
        store = injector.get(Store);
    });

    afterEach(() => {
        store.complete();
    });

    it('should redirect an unauthenticated user to the home page', () => {

        store.setState({ user: dummyState });

        expect(guard.canActivate(routeMock, routeStateMock)).toBe(false);

        expect(routerMock.navigate).toHaveBeenCalledWith(['/home']);
    });

    it('should allow the authenticated user to access app', () => {

        store.setState({ user: initialState });
        expect(guard.userDetails).toEqual(uservalid);
        expect(guard.canActivate(routeMock, routeStateMock)).toBe(true);

    });
});
