import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  Router,
  CanDeactivate,
  UrlTree
} from '@angular/router';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import * as UserState from '../../../../app/reducers/index';
import { User } from 'src/app/core/models/user.model';
import { CanDeactivateModel } from '../../models/CanDeactivateModel';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminguardService implements CanActivate, CanDeactivate<CanDeactivateModel> {
  isTyped:boolean=false;
  setIsTyped(value:boolean)
  {
    this.isTyped=value;
  }
  getisTyped()
  {
    return this.isTyped;
  }
  userDetails: User;
  constructor(private router: Router, private store: Store<UserState.State>) {}
  canDeactivate(
    component: CanDeactivateModel,
    currentRoute: ActivatedRouteSnapshot,
    currentState: RouterStateSnapshot,
    nextState?: RouterStateSnapshot
  ): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    // if (component.canDeactivate) {
    //   return true;
    // } else {
    //   return confirm('sure you want to leave this page ?');
    // }
    //*********//// */
    if(this.isTyped)
    {
      console.log("Hello "+this.isTyped);
      
      let abc=confirm('Are you sure you want to leave this page ?');
      if(abc)
      {
        this.isTyped=false;
      }
      else
      {
        this.isTyped=true;
      }
      return abc;
      //return confirm('sure you want to leave this page ?');
    }
    else
    {
      return true;
    }
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    this.store.select(UserState.userSelector).subscribe(result => {
      this.userDetails = result;
      console.log('userDetails auth check', this.userDetails);
    });
    const authValid = this.userDetails;
    if (authValid && authValid.id !== '' && authValid.role === 'Admin') {
      return true;
    }
    // not logged in so redirect to login page with the return url
    this.router.navigate(['/home']);
    return false;
  }
}
