export interface Movie {
    title: string;
    popularity: string;
    id: number;
    release_date: string;
    poster_path: string;
    overview: string;
  }


