import { ActionReducer, ActionReducerMap, createFeatureSelector, createSelector, MetaReducer } from '@ngrx/store';
import { environment } from '../../environments/environment';
import { MoviesState, moviesReducer, initialMovieState } from '../home/store/reducers/home.reducer';
import { UserState, userReducer, initialUserState } from '../core/store/reducers/userDetails.reducer';
import { BookingState, bookingReducer } from '../shared/store/reducers/booking.reducer';
export interface State {
    movies: MoviesState;
    user: UserState;
    booking: BookingState
}

// export const initialState: State = {
//     movies: initialMovieState
// };
export const reducers: ActionReducerMap<State> = {
    movies: moviesReducer,
    user: userReducer,
    booking: bookingReducer
};

export const metaReducers: MetaReducer<State>[] = !environment.production ? [] : [];

export const getMovieState = createFeatureSelector<MoviesState>('movies');
export const nowPlayingMoviesSelector = createSelector(getMovieState, (state: MoviesState) => state.nowPlayingMovies);
export const upcomingMovieSelector = createSelector(getMovieState, (state: MoviesState) => state.upcomingMovies);
export const theaterList = createSelector(getMovieState, (state: MoviesState) => state.setTheaters);

export const getUserState = createFeatureSelector<UserState>('user');
export const userSelector = createSelector(getUserState, (state: UserState) => state.user);
export const getBookingState = createFeatureSelector<BookingState>('booking');
export const bookingSelector = createSelector(getBookingState, (state: BookingState) => state.booking);
