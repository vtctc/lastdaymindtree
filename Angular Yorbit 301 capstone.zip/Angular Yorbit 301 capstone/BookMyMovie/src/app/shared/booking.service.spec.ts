import { fakeAsync, TestBed ,inject, tick} from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { BookingService } from './booking.service';
import { Booking } from './models/booking.model';

describe('BookingService', () => {
  beforeEach(() =>
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BookingService]
    })
  );

  it('should be created', () => {
    const service: BookingService = TestBed.get(BookingService);
    expect(service).toBeTruthy();
  });
  it(
    'should perform login correctly',
    fakeAsync(
      inject(
        [BookingService, HttpTestingController],
        (bookingService: BookingService, httpMock: HttpTestingController) => {

          // Set up
          const url = 'http://localhost:3000/bookingDetails';
          // const responseObject = {
          //   success: true,
          //   message: 'login was successful'
          // };
          const booking:Booking = {
            uid: "abc",
            theater: "abc",
            movie_name: "kapali",
            seats: ["a","b"],
            total_amount: "800",
            booking_type: "booking"
          };
          let response = null;
          // End Setup

          bookingService.createBooking(booking).subscribe(
            (receivedResponse: any) => {
              response = receivedResponse;
            },
            (error: any) => {}
          );

          const requestWrapper = httpMock.expectOne({url: 'http://localhost:3000/bookingDetails'});

          tick();

          expect(requestWrapper.request.method).toEqual('POST');
        }
      )
    )
  );
  it(
    'should get all bookings',
    fakeAsync(
      inject(
        [BookingService, HttpTestingController],
        (bookingService: BookingService, httpMock: HttpTestingController) => {

          // Set up
          const url = 'http://localhost:3000/bookingDetails';
          // const responseObject = {
          //   success: true,
          //   message: 'login was successful'
          // };
          const bookings:Booking[] = [{
            uid: "abc",
            theater: "abc",
            movie_name: "kapali",
            seats: ["a","b"],
            total_amount: "800",
            booking_type: "booking"
          }];
          let response = null;
          // End Setup

          bookingService.getAllBookings().subscribe(booking => {
            expect(booking).toEqual(bookings);
          });
      
          const req = httpMock.expectOne({url: 'http://localhost:3000/bookingDetails'});
          expect(req.request.method).toBe("GET");
          req.flush(bookings);
        }
      )
    )
  );
});
