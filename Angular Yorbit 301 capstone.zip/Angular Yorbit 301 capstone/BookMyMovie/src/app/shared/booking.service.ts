import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import { BookingLogged } from './store/actions/booking.action';
import { Booking } from './models/booking.model';
import { HttpClient } from '@angular/common/http';
import { JSON_SERVER_URLS } from '../shared/config';
import { environment } from '../../environments/environment';

const BOOKING_URL = environment.JSONSERVER + JSON_SERVER_URLS.BOOKING_DETAILS;
@Injectable({
  providedIn: 'root'
})
export class BookingService {

  constructor( private http:HttpClient) { }

  createBooking(payload: Booking) {
    return this.http.post(BOOKING_URL, payload);
  }
  getAllBookings() {
    return this.http.get(BOOKING_URL);
  }
  deleteBookingById(bookingId: number) {
    return this.http.delete(BOOKING_URL +"/"+bookingId);
  }
}
