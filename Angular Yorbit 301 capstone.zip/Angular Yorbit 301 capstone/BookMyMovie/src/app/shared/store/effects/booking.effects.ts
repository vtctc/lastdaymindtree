import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { map, mergeMap, catchError } from 'rxjs/operators';
import { BookingService } from '../../booking.service';
import { Booking } from '../../models/booking.model';
import * as bookingActions from '../actions/booking.action';
@Injectable()
export class BookingEffects {
  booking: Booking;
  constructor(private bookingService: BookingService, private actions$: Actions) {}
  @Effect()
  createBooking$: Observable<Action> = this.actions$.pipe(
    ofType<bookingActions.CreateBooking>(bookingActions.BookingLogged.CREATE_BOOKING),
    map((action: bookingActions.CreateBooking) => action.payload),
    mergeMap((booking: Booking) =>
      this.bookingService.createBooking(booking).pipe(
        map((newBooking: Booking) => new bookingActions.CreateBookingSuccess(newBooking)),
        catchError(err => of(new bookingActions.CreateBookingFail(err)))
      )
    )
  );
}
