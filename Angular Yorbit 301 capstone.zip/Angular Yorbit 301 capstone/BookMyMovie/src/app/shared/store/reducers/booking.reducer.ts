import { Booking } from '../../models/booking.model';
import { BookingDetailsActionTypes, BookingLogged } from '../actions/booking.action';
import { EntityState, EntityAdapter, createEntityAdapter } from '@ngrx/entity';
export interface BookingState {
  booking: Booking;
}
export const customerAdapter: EntityAdapter<Booking> = createEntityAdapter<Booking>();
export const initialBookingState: BookingState = {
  booking: {
    uid: '',
    theater: '',
    movie_name: '',
    seats: [],
    total_amount: '',
    booking_type:''
  },
};
export const initialState = customerAdapter.getInitialState(initialBookingState);
export function bookingReducer(state = initialBookingState, action: BookingDetailsActionTypes) {
  switch (action.type) {
    case BookingLogged.SET_BOOKING: {
      let newBookingState = { ...state.booking };
      newBookingState = action.payload;
      return {
        ...state,
        booking: newBookingState
      };
    }
    case BookingLogged.CREATE_BOOKING_SUCCESS: {
      let newBookingState = { ...state.booking };
      newBookingState = action.payload;
      console.log(newBookingState);
      return {
        ...state,
        booking: newBookingState
      };
      //return customerAdapter.addOne(action.payload, initialState);
    }
    case BookingLogged.CREATE_BOOKING_FAIL: {
        return {
            ...state,
            error: action.payload
          };
    }

    default:
      return state;
  }
}
