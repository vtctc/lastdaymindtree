import { Action } from '@ngrx/store';
import { Booking } from '../../models/booking.model';

export enum BookingLogged {
  SET_BOOKING = '[ Booking ] Booking set',
  CREATE_BOOKING_SUCCESS = '[Booking] Create Booking Success',
  CREATE_BOOKING_FAIL = '[Booking] Create Booking Fail',
  CREATE_BOOKING = "[BOOKING] Create Booking",
  GET_ALL_BOOKINGS = '[Booking] Got Booking'
}
export class SetBooking implements Action {
  readonly type = BookingLogged.SET_BOOKING;

  constructor(public payload: Booking) {}
}
export class CreateBooking implements Action {
    readonly type = BookingLogged.CREATE_BOOKING;
  
    constructor(public payload: Booking) {}
  }
export class CreateBookingSuccess implements Action {
  readonly type = BookingLogged.CREATE_BOOKING_SUCCESS;

  constructor(public payload: Booking) {}
}
export class CreateBookingFail implements Action {
  readonly type = BookingLogged.CREATE_BOOKING_FAIL;

  constructor(public payload: string) {}
}
export type BookingDetailsActionTypes = SetBooking | CreateBookingSuccess | CreateBookingFail | CreateBooking;
