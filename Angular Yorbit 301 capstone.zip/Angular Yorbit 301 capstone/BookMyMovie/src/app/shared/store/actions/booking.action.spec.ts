import { async, TestBed } from '@angular/core/testing';
import { Booking } from '../../models/booking.model';
import { BookingLogged, CreateBooking, CreateBookingFail, CreateBookingSuccess, SetBooking } from './booking.action';

describe('Home-Filter pipe', () => {

    let setBooking;
    let createBooking;
    let createBookingSuccess;
    let createBookingFail;
    const booking:Booking = {
        uid: "abc",
        theater: "abc",
        movie_name: "kapali",
        seats: ["a","b"],
        total_amount: "800",
        booking_type: "booking"
      };

    beforeEach(() => {
        setBooking = new SetBooking(booking);
        createBooking=new CreateBooking(booking);
        createBookingSuccess=new CreateBookingSuccess(booking);
        createBookingFail=new CreateBookingFail("failure");
    });
    it('checking set booking ', () => {
        expect(BookingLogged.SET_BOOKING).toBe('[ Booking ] Booking set');
    });
    it('checking create booking ', () => {
        expect(BookingLogged.CREATE_BOOKING).toBe("[BOOKING] Create Booking");
    });
    it('checking create booking success', () => {
        expect(BookingLogged.CREATE_BOOKING_SUCCESS).toBe('[Booking] Create Booking Success');
    });
    it('checking create booking failure', () => {
        expect(BookingLogged.CREATE_BOOKING_FAIL).toBe('[Booking] Create Booking Fail');
    });
});


