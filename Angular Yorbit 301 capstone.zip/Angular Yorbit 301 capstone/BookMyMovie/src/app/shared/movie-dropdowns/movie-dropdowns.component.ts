import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { HomeService } from 'src/app/home/services/home.service';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-movie-dropdowns',
  templateUrl: './movie-dropdowns.component.html',
  styleUrls: ['./movie-dropdowns.component.scss']
})
export class MovieDropdownsComponent implements OnInit {
  genresList: any = [];
  @Input() userPreference;
  @Input() layout;
  @Input() languageList;
  @Output() languageChange$: EventEmitter<any>;
  @Output() genreChange$: EventEmitter<any>;
  @Output() distanceChange$: EventEmitter<any>;
  languageSelected = false;
  genreSelected = false;
  genreObj = { value: '' };
  distanceSelected: number;
  languageSelector: FormControl;
  generSelector: FormControl;
  languageany: string;
  genreany: string;
  constructor(private homeService: HomeService) {
    this.languageChange$ = new EventEmitter();
    this.genreChange$ = new EventEmitter();
    this.distanceChange$ = new EventEmitter();
    this.languageSelector = new FormControl();
    this.generSelector = new FormControl();
  }

  ngOnInit() {
    console.log(this.userPreference);
    if (this.userPreference.language == 'hi') {
      this.languageany = 'Hindi';
    } else if (this.userPreference.language == 'en') {
      this.languageany = 'English';
    } else if (this.userPreference.language == 'ja') {
      this.languageany = 'Japanese';
    } else if (this.userPreference.language == 'zh') {
      this.languageany = 'Chinese';
    }
    //genre
    if(this.userPreference.genre.length > 0) {
      if(this.userPreference.genre=="28")
      {
        this.genreany='Action';
      }
      else if(this.userPreference.genre=="12")
      {
        this.genreany='Adventure';
      }
      else if(this.userPreference.genre=="16")
      {
        this.genreany='Animation';
      }
      else if(this.userPreference.genre=="35")
      {
        this.genreany='Comedy';
      }
      else if(this.userPreference.genre=="80")
      {
        this.genreany='Crime';
      }
      else if(this.userPreference.genre=="99")
      {
        this.genreany='Documentary';
      }
      else if(this.userPreference.genre=="18")
      {
        this.genreany='Drama';
      }
      else if(this.userPreference.genre=="10751")
      {
        this.genreany='Family';
      }
      else if(this.userPreference.genre=="14")
      {
        this.genreany='Fantasy';
      }
      else if(this.userPreference.genre=="36")
      {
        this.genreany='History';
      }
      else if(this.userPreference.genre=="27")
      {
        this.genreany='Horror';
      }
      else if(this.userPreference.genre=="10402")
      {
        this.genreany='Music';
      }
      else if(this.userPreference.genre=="9648")
      {
        this.genreany='Mystery';
      }
      else if(this.userPreference.genre=="10749")
      {
        this.genreany='Romance';
      }
      else if(this.userPreference.genre=="878")
      {
        this.genreany='Science Fiction';
      }
      else if(this.userPreference.genre=="10770")
      {
        this.genreany='TV Movie';
      }
      else if(this.userPreference.genre=="53")
      {
        this.genreany='Thriller';
      }
      else if(this.userPreference.genre=="10752")
      {
        this.genreany='War';
      }
      else if(this.userPreference.genre=="37")
      {
        this.genreany='Western';
      }
    }
    this.genresList = this.homeService.getGenres();
    this.languageSelector.valueChanges.subscribe((value) => {
      console.log(value);
      
      this.languageSelected = value ? true : false;
      this.languageChange$.emit(value);
    });
    this.generSelector.valueChanges.subscribe((value) => {
      this.genreSelected = value ? true : false;
      this.genreObj.value = value;
      this.genreObj = Object.assign({}, this.genreObj);
      this.genreChange$.emit(this.genreObj);
    });
  }
}
