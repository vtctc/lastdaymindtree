import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-ratings',
  templateUrl: './ratings.component.html',
  styleUrls: ['./ratings.component.scss']
})
export class RatingsComponent implements OnInit {

  @Input() movieDescription;
  rating=new Array(5);
  constructor() { 
  }

  ngOnInit() {​​​​​
    const activeCount = Math.floor(this.movieDescription);
    for (let i = 0; i < 5; i++) {​​​​​
      // this.rating[i] = i <= this.vote_average ? true : false;
      this.rating[i] = 'star_border';
      if (i < activeCount) {​​​​​
        this.rating[i] = 'star_rate';
      }​​​​​
      if (this.movieDescription > i && this.movieDescription < (i + 1)) {​​​​​
        this.rating[i] = 'star_half';
      }​​​​​
    }​​​​​
  }​​​​​
}
