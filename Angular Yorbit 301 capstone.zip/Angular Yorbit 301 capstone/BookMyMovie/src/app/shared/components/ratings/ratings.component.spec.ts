import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MaterialModule } from 'src/app/material.module';

import { RatingsComponent } from './ratings.component';

describe('RatingsComponent', () => {
  let label: HTMLElement;
  let mat_icon:HTMLElement
  let component: RatingsComponent;
  let fixture: ComponentFixture<RatingsComponent>;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[MaterialModule],
      declarations: [ RatingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    label=fixture.nativeElement.querySelector('label');
  });
  it('check rating displaying correctly', () => {
    component.movieDescription={'movieDescription':4.2}
    expect(component.rating[4]).toBe('star_border');
  })
  it('check movieDescription value emitted correctly', () =>{
    component.movieDescription={'movieDescription':8.2}
    expect(component.movieDescription.movieDescription).toBe(8.2);
  })
  it('should assert value for label tag', () =>{
    component.movieDescription={'movieDescription':4.2};
    fixture.detectChanges();
    expect(label.textContent).toContain(component.movieDescription)
  })
  it('check rating array', () =>{
    component.movieDescription={'movieDescription':2.5};
    fixture.detectChanges();
    const q1=fixture.nativeElement.querySelector('mat-icon');
    expect(q1.textContent).toContain('star_border');
    // expect(component.rating).toEqual(['star_rate','star_rate','star_half','star_border','star_border']);
  })
  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
