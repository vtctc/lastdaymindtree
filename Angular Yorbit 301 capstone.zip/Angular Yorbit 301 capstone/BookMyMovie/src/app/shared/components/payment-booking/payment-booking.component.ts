import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { ConfirmationModalComponent } from '../../components/modals/confirmation-modal/confirmation-modal.component';
import { CardDetails } from '../../models/card-details';
import { CardValidator } from '../../models/card-validator';
import { ICardDetails } from '../../models/i-card-details';
import { PaymentCardService } from '../../payment-card.service';
@Component({
  selector: 'app-payment-booking',
  templateUrl: './payment-booking.component.html',
  styleUrls: ['./payment-booking.component.scss']
})
export class PaymentBookingComponent implements OnInit {
  firstParam;
  secondParam;
  thirdParam;
  fourthParam;
  fiveParam;
  sixthParam;
  public ccForm: FormGroup;
  /**
   * List of months
   */
  public months: Array<string> = [];
  /**
   * List of years
   */
  public years: Array<number> = [];
  /**
   * Validation message for missing payment card number
   */
  @Input()
  public ccNumMissingTxt? = 'Card number is required';
  /**
   * Validation message for too short payment card number
   */
  @Input()
  public ccNumTooShortTxt? = 'Card number is too short';
  /**
   * Validation message for too long payment card number
   */
  @Input()
  public ccNumTooLongTxt? = 'Card number is too long';
  /**
   * Validation message for payment card number that contains characters other than digits
   */
  @Input()
  public ccNumContainsLettersTxt? = 'Card number can contain digits only';
  /**
   * Validation message for invalid payment card  number (Luhn's validation)
   */
  @Input()
  public ccNumChecksumInvalidTxt? = 'Provided card number is invalid';
  /**
   * Validation message for missing card holder name
   */
  @Input()
  public cardHolderMissingTxt? = 'Card holder name is required';
  /**
   * Validation message for too long card holder name
   */
  @Input()
  public cardHolderTooLongTxt? = 'Card holder name is too long';
  /**
   * Validation message for missing expiration month
   */
  @Input()
  public expirationMonthMissingTxt? = 'Expiration month is required';
  /**
   * Validation message for missing expiration year
   */
  @Input()
  public expirationYearMissingTxt? = 'Expiration year is required';
  /**
   * Validation message for missing CCV number
   */
  @Input()
  public ccvMissingTxt? = 'CCV number is required';
  /**
   * Validation message for too short CCV number
   */
  @Input()
  public ccvNumTooShortTxt? = 'CCV number is too short';
  /**
   * Validation message for too long CCV number
   */
  @Input()
  public ccvNumTooLongTxt? = 'CCV number is too long';
  /**
   * Validation message for incorrect CCV number containing characters other than digits
   */
  @Input()
  public ccvContainsLettersTxt? = 'CCV number can contain digits only';
  /**
   * Validation message for expired card
   */
  @Input()
  public cardExpiredTxt? = 'Card has expired';
  /**
   * Switch validation of the payment card number
   */
  @Input()
  public validateCCNum? = true;
  /**
   * Switch validation of the payment card holder
   */
  @Input()
  public validateCardHolder? = true;
  /**
   * Switch validation of the payment card expiration month
   */
  @Input()
  public validateExpirationMonth? = true;
  /**
   * Switch validation of the payment card expiration year
   */
  @Input()
  public validateExpirationYear? = true;
  /**
   * Switch validation of the payment card expiration
   */
  @Input()
  public validateCardExpiration? = true;
  /**
   * Switch validation of the payment card CCV number
   */
  @Input()
  public validateCCV? = true;
  /**
   * EventEmitter for payment card object
   */
  @Output()
  public formSaved: EventEmitter<ICardDetails> = new EventEmitter<CardDetails>();
  constructor(private _ccService: PaymentCardService, private _fb: FormBuilder, public dialog: MatDialog, private route: ActivatedRoute) {
    this.firstParam = this.route.snapshot.params.movieTitle;
    this.secondParam = this.route.snapshot.params.theatre;
    this.thirdParam = this.route.snapshot.params.time;
    this.fourthParam = this.route.snapshot.params.seat;
    this.fiveParam = this.route.snapshot.params.total;
    this.sixthParam = this.route.snapshot.params.bookingType;
  }
  public ngOnInit(): void {
    this.buildForm();
    this.assignDateValues();
  }
  /**
   * Populate months and years
   */
  private assignDateValues(): void {
    this.months = PaymentCardService.getMonths();
    this.years = PaymentCardService.getYears();
  }
  /**
   * Build reactive form
   */
  private buildForm(): void {
    this.ccForm = this._fb.group(
      {
        cardNumber: [
          '',
          Validators.compose([
            Validators.required,
            Validators.minLength(12),
            Validators.maxLength(19),
            CardValidator.numbersOnly,
            CardValidator.checksum,
          ]),
        ],
        cardHolder: ['', Validators.compose([Validators.required, Validators.maxLength(22)])],
        expirationMonth: ['', Validators.required],
        expirationYear: ['', Validators.required],
        ccv: [
          '',
          Validators.compose([
            Validators.required,
            Validators.minLength(3),
            Validators.maxLength(4),
            CardValidator.numbersOnly,
          ]),
        ],
      },
      {
        validator: CardValidator.expiration,
      }
    );
  }
  /**
   * Returns payment card type based on payment card number
   */
  public getCardType(ccNum: string): string | null {
    console.log(PaymentCardService.getCardType(ccNum));

    return PaymentCardService.getCardType(ccNum);
  }
  /**
   * Callback function that emits payment card details after user clicks submit, or press enter
   */
  openConfirmDialog() {
    // if (this.paymentBookingForm.valid) {
    //   const dialogRef = this.dialog.open(ConfirmationModalComponent, {
    //     disableClose: true,
    //     data: {
    //       name: this.firstParam, theater: this.secondParam,
    //       time: this.thirdParam, seat: this.fourthParam, total: this.fiveParam,
    //       bookingType: this.sixthParam
    //     }
    //   });
    // }
    // else
    // {
    //   console.log("hello");
      
    // }
    const dialogRef = this.dialog.open(ConfirmationModalComponent, {
      disableClose: true,
      data: {
        name: this.firstParam, theater: this.secondParam,
        time: this.thirdParam, seat: this.fourthParam, total: this.fiveParam,
        bookingType: this.sixthParam
      }
    });
  }
}


