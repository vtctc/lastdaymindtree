import { ChangeDetectionStrategy, Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { getBookingState } from 'src/app/reducers';
import { Booking } from 'src/app/shared/models/booking.model';
import { BookingState } from 'src/app/shared/store/reducers/booking.reducer';
import * as bookingActions from '../../../store/actions/booking.action';
 
@Component({
  selector: 'app-confirmation-modal',
  templateUrl: './confirmation-modal.component.html',
  styleUrls: ['./confirmation-modal.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConfirmationModalComponent implements OnInit {
 
  newBooking: Booking;
  booking$: Observable<any>;
 
  constructor(private dialogRef: MatDialogRef<ConfirmationModalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private router: Router, private store: Store<BookingState>) {
    console.log('confirmation booking', data);
 
  }
 
  ngOnInit() {
 
    const seats: string[] = this.data.seat.split(',');
    let sessionItem=sessionStorage.getItem('authDetails');
    const uid=sessionItem.split(',');
    console.log(uid[0].substring(7,uid[0].length-1));
    let abc=""+uid[0].substring(7,uid[0].length-1)
    this.newBooking = {
      'uid': abc,
      'theater': this.data.theater,
      'movie_name': this.data.name,
      'seats': seats,
      'total_amount': this.data.total,
      'booking_type': this.data.bookingType
    }
    this.store.dispatch(new bookingActions.CreateBooking(this.newBooking));
 
    this.store.select(getBookingState).subscribe(state => console.log(state));
 
  }
 
  onCloseConfirm() {
    this.dialogRef.close('Confirm');
    this.router.navigate(['/home']);
  }
}