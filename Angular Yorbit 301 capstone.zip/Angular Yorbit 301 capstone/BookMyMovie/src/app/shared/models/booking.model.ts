export interface Booking {
  uid: string;
  theater: string;
  movie_name: string;
  seats: string[];
  total_amount: string;
  booking_type: string;
}
