export interface ICardDetails {
    cardNumber: string;
    cardHolder: string;
    expirationMonth: string;
    expirationYear: string;
    ccv: number;
  }
  