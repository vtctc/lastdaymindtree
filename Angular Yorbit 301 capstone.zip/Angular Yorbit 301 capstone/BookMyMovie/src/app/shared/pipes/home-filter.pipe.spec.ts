import { async, TestBed } from '@angular/core/testing';
import { HomeFilterPipe } from './home-filter.pipe';

describe('Home-Filter pipe', () => {

    let filterPipe;
    let movieList = [{ mid: 1, original_language: 'en', genre_ids: [10, 20] },
    { mid: 2, original_language: 'hi', genre_ids: [10, 20, 30] },
    { mid: 3, original_language: 'en', genre_ids: [10] }];
    let genreInput;
    let languagePref;

    beforeEach(() => {
        filterPipe = new HomeFilterPipe();

    });

    it('component is created ', () => {
        expect(filterPipe).toBeTruthy();
    });


    it('when language is selected', () => {
        genreInput = '';
        languagePref = 'hi';
        expect(filterPipe.transform(movieList, genreInput, languagePref)).toBeTruthy();
        expect(filterPipe.transform(movieList, genreInput, languagePref)).
            toContain({ mid: 2, original_language: 'hi', genre_ids: [10, 20, 30] });

    });

    it('when genre is selected', () => {
        genreInput = '10';
        languagePref = '';
        console.log(genreInput);
        console.log(movieList);
        expect(filterPipe.transform(movieList, genreInput, languagePref)).toBeTruthy();
        expect(filterPipe.transform(movieList, genreInput, languagePref)).
            toContain({ mid: 3, original_language: 'en', genre_ids: [10] });

    });


    it('when genre and language both are not selected', () => {

        genreInput = '';
        languagePref = '';

        expect(filterPipe.transform(movieList, genreInput, languagePref)).toBeTruthy();
        expect(filterPipe.transform(movieList, genreInput, languagePref)).toBe(movieList);

    });


    it('when genre and language both is selected', () => {
        genreInput = '10';
        languagePref = 'en';
        console.log(genreInput);
        console.log(movieList);
        expect(filterPipe.transform(movieList, genreInput, languagePref)).toBeTruthy();
        expect(filterPipe.transform(movieList, genreInput, languagePref)).
            toContain({ mid: 1, original_language: 'en', genre_ids: [10, 20] });

    });

});


