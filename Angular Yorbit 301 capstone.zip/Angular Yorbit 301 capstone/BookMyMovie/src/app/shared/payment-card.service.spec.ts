import { TestBed } from '@angular/core/testing';

import { PaymentCardService } from './payment-card.service';

describe('PaymentCardService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PaymentCardService = TestBed.get(PaymentCardService);
    expect(service).toBeTruthy();
  });
});
