import { Component, OnInit, Output, EventEmitter, TemplateRef, ViewChild, AfterViewInit } from '@angular/core';
import { HomeService } from '../home/services/home.service';
import { LoginService } from '../core/services/login.service';
import { MatTableDataSource } from '@angular/material/table';
import { Store } from '@ngrx/store';
import * as UserState from '../reducers/index';
import { SetUser } from 'src/app/core/store/action/userDetails.action';
import { User } from 'src/app/core/models/user.model';
import { MatDialog } from '@angular/material';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { FormBuilder, Validators } from '@angular/forms';
// import { UserState } from "src/app/core/store/reducers/userDetails.reducer";
import * as MovieState from '../reducers/index';
import { BookingService } from '../shared/booking.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit, AfterViewInit {
  genresList: any = [];
  theaterList: any = [];
  name;
  dataDeleted:number=0;
  bookingsList: any;
  filteredBookingsList: any;
  userdatas;
  dataSource;
  displayedColumns: string[] = ['BookingId', 'Theatre Name', 'Movie Name', 'Amount', 'Booking Type', 'Cancel'];
  userDetails: User;
  // @ViewChild(MatPaginator) paginator: MatPaginator;
  actualPaginator: MatPaginator;
  @ViewChild(MatPaginator, ) 
  set paginator(value: MatPaginator) {
    this.actualPaginator=value;
    // this.dataSource.paginator = value
  }
  
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('successDialog') successDialog: TemplateRef<any>;
  languageList = [
    { name: 'English', value: 'en' },
    { name: 'Hindi', value: 'hi' },
    { name: 'Tamil', value: 'ta' },
    { name: 'Kannada', value: 'kn' }
  ];

  newPreference = this.fb.group({
    lang: ['', Validators.required],
    generes: ['', Validators.required],
    theaters: ['', Validators.required]
  });

  constructor(
    private homeService: HomeService,
    private loginService: LoginService,
    private fb: FormBuilder,
    private bookingService: BookingService,
    private store: Store<UserState.State>,
    private matDialog: MatDialog
  ) {}

  // after clicking submit button adding preference option is here
  public submitPreferences() {
    let currentSeesion;
    currentSeesion = JSON.parse(sessionStorage.getItem('authDetails'));
    this.homeService.setPreference(this.newPreference.value, currentSeesion['id']);
    this.matDialog.open(this.successDialog);
  }

  ngOnInit() {
    this.filteredBookingsList = [];
    // this.bookingService.getAllBookings().subscribe(data => {
    //   this.bookingsList=data;
    //   console.log(this.bookingsList);
    //   let authDetails=sessionStorage.getItem('authDetails');
    //   let authDetailsConverted=JSON.parse(authDetails);
    //   console.log(authDetailsConverted);
    //   for (const booking of this.bookingsList) {
    //     if(authDetailsConverted.id==booking.uid) {
    //       this.filteredBookingsList.push(booking);
    //     }
    //   }
    //   this.dataSource = new MatTableDataSource(this.filteredBookingsList);
    //   console.log(this.dataSource);

    //   console.log(this.paginator);
    //   console.log(this.sort);

    //   this.dataSource.paginator = this.paginator;
    //   this.dataSource.sort = this.sort;
    //   console.log(this.filteredBookingsList);

    // })
    this.store.select(UserState.userSelector).subscribe(result => {
      this.userDetails = result;
    });
    this.genresList = this.homeService.getGenres();
    this.loginService.getUserData().subscribe(data => (this.name = data.users[0].name));
    this.store.select(MovieState.theaterList).subscribe(result => {
      this.theaterList = Object.values(result);
      console.log('updated', result, this.theaterList);
    });
  }
  ngAfterViewInit() {
    this.dataSource = new MatTableDataSource(this.filteredBookingsList);
    this.bookingService.getAllBookings().subscribe(data => {
      this.bookingsList = data;
      console.log(this.bookingsList);
      let authDetails = sessionStorage.getItem('authDetails');
      let authDetailsConverted = JSON.parse(authDetails);
      console.log(authDetailsConverted);
      for (const booking of this.bookingsList) {
        if (authDetailsConverted.id == booking.uid) {
          this.filteredBookingsList.push(booking);
        }
      }
      this.dataSource = new MatTableDataSource(this.filteredBookingsList);
      
      this.dataSource.paginator = this.actualPaginator;
      console.log(this.dataSource);
      console.log(this.filteredBookingsList);
      console.log(this.actualPaginator);
    });
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
  sucess() {
    this.newPreference.reset();
    this.matDialog.closeAll();
  }
  cancelBooking(element) {
    console.log(element);
    this.bookingService.deleteBookingById(element).subscribe(data => {
      console.log(data); 
      window.location.reload();   
    })
  }
}
