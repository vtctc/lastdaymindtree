import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ValidThruPipe } from './valid-thru.pipe';
import { PaymentCardNumberPipe } from './payment-card-number.pipe';

@NgModule({
  declarations: [ValidThruPipe, PaymentCardNumberPipe],
  imports: [
    CommonModule
  ],
  exports: [ValidThruPipe, PaymentCardNumberPipe],
})
export class PipesModule { }
