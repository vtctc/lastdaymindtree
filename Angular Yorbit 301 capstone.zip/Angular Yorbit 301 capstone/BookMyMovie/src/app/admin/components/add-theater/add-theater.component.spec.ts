import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { MatDialog, MatDialogModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { provideMockStore } from '@ngrx/store/testing';
import { AdminguardService } from 'src/app/core/auth/service/adminguard.service';
import { AdminService } from '../../services/admin.service';
import { AddTheaterComponent } from './add-theater.component';


describe('AddTheaterComponent', () => {
    let component: AddTheaterComponent;
    let fixture: ComponentFixture<AddTheaterComponent>;
    let adminguard: AdminguardService;
    let adminService: AdminService;
    let matDailog: MatDialog;
    let de: DebugElement
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                ReactiveFormsModule,
                MatDialogModule,
                RouterModule.forRoot([]),
                HttpClientTestingModule,
                BrowserAnimationsModule
            ],
            declarations: [AddTheaterComponent],
            providers: [AdminguardService, AdminService, provideMockStore({})],
            schemas: [CUSTOM_ELEMENTS_SCHEMA]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AddTheaterComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        adminguard = TestBed.get(AdminguardService);
        adminService = TestBed.get(AdminService);
        matDailog = TestBed.get(MatDialog);
        spyOn(matDailog, 'open');
        spyOn(adminService, 'newTheater');
        de = fixture.debugElement;

    });

    it('component is created ', () => {
        expect(AddTheaterComponent).toBeTruthy();
    });

    it('check all negative and positive scenario of forms ', () => {
        const tid = component.newTheater.controls['tid'];
        tid.setValue('');
        expect(tid.errors['required']).toBeTruthy();
        const tname = component.newTheater.controls['name'];
        tname.setValue('Max');
        expect(tname.errors).toBeNull();
        const city = component.newTheater.controls['city'];
        city.setValue('delhi6');
        expect(city.errors['requiredPattern']).toBeFalsy();
        const capacity = component.newTheater.controls['capacity'];
        capacity.setValue('7');
        expect(capacity.errors['min']).toBeTruthy();
        capacity.setValue('70');
        expect(capacity.errors['max']).toBeTruthy();
    });

    it('to open onSubmit method', () => {
        newFunction(component);
        expect(component.newTheater.valid).toBeTruthy();
        component.onSubmit();
        expect(adminService.newTheater).toHaveBeenCalled();
        expect(matDailog.open).toHaveBeenCalled();

    });


    it('for input method', () => {
        spyOn(adminguard, 'setIsTyped');
        component.isInput();
        expect(adminguard.setIsTyped).toHaveBeenCalled();
    });

    // it('for ngonlick', () => {
    //     spyOn(component, 'onSubmit')
    //     newFunction(component);
    //     component.newTheater.valid
    //     const btn = de.query(By.css('#btnSubmit'));

    //     btn.triggerEventHandler('click', null);
    //     fixture.detectChanges();
    //     // expect(matDailog.open).toHaveBeenCalled();
    //     fixture.whenStable().then(() => {
    //         expect(component.onSubmit).toHaveBeenCalled()
    //     })
    // });

    it('for dialogOk method', () => {
        spyOn(matDailog, 'closeAll');
        component.dialogOk();
        expect(component.newTheater.reset).toBeDefined();
        expect(matDailog.closeAll).toHaveBeenCalled();
    });



});
function newFunction(component: AddTheaterComponent) {
    component.newTheater.controls['tid'].setValue('12');
    component.newTheater.controls['name'].setValue('Max');
    component.newTheater.controls['city'].setValue('delhi');
    component.newTheater.controls['latitude'].setValue('45727.2');
    component.newTheater.controls['longtitude'].setValue('34.2628y2');
    component.newTheater.controls['capacity'].setValue('35');
}

