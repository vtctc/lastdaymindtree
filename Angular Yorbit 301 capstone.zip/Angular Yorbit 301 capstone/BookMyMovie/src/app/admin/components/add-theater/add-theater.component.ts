import { Component, EventEmitter, OnInit, Output, TemplateRef, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { Store } from '@ngrx/store';
import { debounceTime, tap } from 'rxjs/operators';
import { AdminguardService } from 'src/app/core/auth/service/adminguard.service';
import * as MovieState from '../../../reducers/index';
import { AdminService } from '../../services/admin.service';


@Component({
  selector: 'app-add-theater',
  templateUrl: './add-theater.component.html',
  styleUrls: ['./add-theater.component.scss']
})
export class AddTheaterComponent implements OnInit {

  theaterList = [];

  empty = false;
  newTheater = this.fb.group({
    tid: ['', Validators.required],
    name: ['', [Validators.required, Validators.pattern('[a-zA-Z ]*')]],
    city: ['', [Validators.required, Validators.pattern('[a-zA-Z ]*')]],
    // gLocation: ['', Validators.required],
    latitude: ['', Validators.required],
    longtitude: ['', Validators.required],
    capacity: ['', [Validators.required, Validators.max(50), Validators.min(30), Validators.pattern('[0-9]*')]]
  });



  @Output() addTheater = new EventEmitter();
  @ViewChild('successDialog') successDialog: TemplateRef<any>;

  constructor(private fb: FormBuilder, private matDialog: MatDialog,
    private adminGuardService: AdminguardService, private adminService: AdminService, private store: Store<MovieState.State>) {
  }

  ngOnInit() {
    this.empty = true;
    this.store.select(MovieState.theaterList).subscribe(result => {
      this.theaterList = Object.values(result);
      console.log(this.theaterList);
    });

    this.tid.valueChanges
      .pipe(
        debounceTime(500),
        tap(tid => {
          if (tid !== '' && !this.tid.invalid) {
            this.tid.markAsPending();
          } else {
            this.empty = true;
            this.tid.setErrors({ 'invalid': true });

          }
        })
      )
      .subscribe(tid => {
        console.log(tid);
        let flag = 0;
        for (const theater of this.theaterList) {
          if (theater.tid === tid) {
            flag = 1;
            break;
          }
        }
        if (flag === 1) {
          this.empty = false;
          this.tid.markAsPending({ onlySelf: false });
          this.tid.setErrors({ notUnique: true });
        } else {

          this.empty = false;
          this.tid.markAsPending({ onlySelf: false });
          this.tid.setErrors(null);
        }
        if (tid === '') {

          this.empty = true;
          this.tid.setErrors({ 'invalid': true });
        }
      });

  }

  get tid() {
    return this.newTheater.get('tid') as FormControl;
  }



  onSubmit() {
    if (this.newTheater.valid) {
      this.adminGuardService.setIsTyped(false);
      // this.addTheater.emit(this.newTheater.value);
      const theatreData = this.newTheater.value;
      theatreData.movies = [];
      this.adminService.newTheater(theatreData);
      this.matDialog.open(this.successDialog);
    }
  }
  isInput() {
    this.adminGuardService.setIsTyped(true);
  }
  dialogOk() {
    this.newTheater.reset();
    this.matDialog.closeAll();
  }

}
