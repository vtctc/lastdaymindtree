import { Component, OnInit, Input, ViewChild, TemplateRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import { theaterList } from 'src/app/reducers';
import { AdminService } from '../../services/admin.service';
import { MatDialog } from '@angular/material';
import { Store } from '@ngrx/store';
import * as MovieState from '../../../reducers/index';
import { AdminguardService } from 'src/app/core/auth/service/adminguard.service';
@Component({
  selector: 'app-change-show',
  templateUrl: './change-show.component.html',
  styleUrls: ['./change-show.component.scss']
})
export class ChangeShowComponent implements OnInit {
  @Input() theaterList;
  movieInput: FormControl;
  selectTheater: FormControl;
  movieResult;
  selectedTheater;
  nowShowing = [];
  nowPlaying = [];
  selectedmovie:any;
  isTheaterSelected:boolean=false;
  resetDialog=0;
  @ViewChild('successDialog') successDialog: TemplateRef<any>;

  constructor(private adminService: AdminService, private matDialog: MatDialog, private store: Store<MovieState.State>, private adminguardService:AdminguardService) {
    this.movieInput = new FormControl();
    this.selectTheater = new FormControl();
  }

  ngOnInit() {
    this.store.select(MovieState.theaterList).subscribe(result => {
      this.theaterList = Object.values(result);
      console.log(theaterList);     
    });
    this.movieInput.valueChanges.subscribe(value => {
      if(this.resetDialog==0)
      {
        this.adminguardService.setIsTyped(true);
      }
      if (value) {
        this.adminService.searchMovie(value).subscribe(movies => {
          this.movieResult = movies['results'];
        });
      }
    });
    this.selectTheater.valueChanges.subscribe(value => {
      if(this.resetDialog==0)
      {
        this.adminguardService.setIsTyped(true);
      }
      this.isTheaterSelected=true;
      this.selectedTheater = value;
      this.nowShowing = [];
    });
  }
  addMovie(movie) {
    this.nowShowing.push(movie.name);
    //this.nowPlaying.push(movie.id);
    this.selectedmovie=movie.id;
  }
  save() {
    // this.matDialog.open(this.successDialog);
    this.adminguardService.setIsTyped(false);
    console.log(this.adminguardService.getisTyped());
    
    // this.adminService.saveNowPlaying(this.nowPlaying, this.selectTheater['tid']);
    //this.adminService.saveNowPlaying(this.selectedmovie, this.selectedTheater.tid);
    this.matDialog.open(this.successDialog);
  }
  cancel() {
    this.nowShowing = [];
  }
  dialogOk() {
    this.resetDialog=1;
    this.nowShowing = [];
    this.movieInput.reset();
    this.selectTheater.reset();
    this.matDialog.closeAll();
    this.movieResult = [];
  }
}
