import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminComponent } from './containers/admin/admin.component';
import { AdminguardService } from '../core/auth/service/adminguard.service';
import { ChangeShowComponent } from './components/change-show/change-show.component';
import { AddTheaterComponent } from './components/add-theater/add-theater.component';

// const routes: Routes = [
//     {
//         path: '',
//         component: AdminComponent,
//         canActivate: [AdminguardService]
//     }
// ];
const routes: Routes = [
    {
        path: '',
        component: AdminComponent,
        canActivate: [AdminguardService],
        canDeactivate: [AdminguardService],
        children: [
            {
                path: '', redirectTo: 'add-movie', pathMatch: 'full'
 
            },
            {
                path: 'add-movie',
                component: ChangeShowComponent,
                canDeactivate: [AdminguardService],
            },
            {
                path: 'add-theater',
                component: AddTheaterComponent,
                canDeactivate: [AdminguardService],
            }
        ]
 
    }
];
@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class AdminRoutingModule { }
