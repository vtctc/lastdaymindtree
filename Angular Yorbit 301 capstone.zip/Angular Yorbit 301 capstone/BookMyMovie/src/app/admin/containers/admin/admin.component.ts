import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { Store, State } from '@ngrx/store';
import * as MovieState from '../../../reducers/index';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
  theaterList;
  //navLinks: { label: string; link: string; index: number; }[];
  navLinks: any[];
  activeLinkIndex = -1;
  constructor(private adminService: AdminService, private store: Store<MovieState.State>, private router: Router) {
    this.navLinks = [
      {
        label: 'AddMovie',
        link: './add-movie',
        index: 0
      }, {
        label: 'AddTheater',
        link: './add-theater',
        index: 1
      }
    ];
  }

  // ngOnInit() {
  //   this.store.select(MovieState.theaterList).subscribe(result => {
  //     this.theaterList = Object.values(result);
  //   });
  // }
  ngOnInit() {
 
    this.router.events.subscribe((res) => {
      this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.link === '.' + this.router.url));
    });
 
    this.store.select(MovieState.theaterList).subscribe(result => {
      this.theaterList = Object.values(result);
    });
  }
  addTheater(formData) {
    formData.movies=[];
    console.log(formData);
    
    this.adminService.newTheater(formData);
  }
}
