import { async, TestBed } from '@angular/core/testing';
import { CreateBookingSuccess } from 'src/app/shared/store/actions/booking.action';
import { Movie } from '../../models/movie.model';
import { EMovieActionTypes, SetCastAndCrew, SetNowPlayingMovies, SetTheaters } from './home.action';
import { SetUpcomingMovies } from './home.action';
describe('Home-Filter pipe', () => {

    let setNowPlayingMovies;
    let setUpcomingMovies;
    let setCastAndCrew;
    let setTheaters;
    const booking:Movie[] = [{
        "title": "Abc",
        "id": 1,
        "casts": null,
        "crews": null,
        "popularity": "4.5",
        "poster_path": "",
        "release_date": "",
        "original_language": "Hindi",
        "overview": "",
        "genre_ids": null,
        "vote_average": 4.5,
        "vote_count": 136
    }];

    beforeEach(() => {
        setNowPlayingMovies = new SetNowPlayingMovies(booking);
        setUpcomingMovies= new SetUpcomingMovies(booking);
        setCastAndCrew=new SetCastAndCrew(booking);
        setTheaters=new SetTheaters("failure");
    });
    it('checking set booking ', () => {
        expect(EMovieActionTypes.SET_NOW_PLAYING_MOVIES).toBe('[ Movie ] Set now playing movies');
    });
    it('checking create booking ', () => {
        expect(EMovieActionTypes.SET_UPCOMING_MOVIES).toBe('[ Movie ] Set up coming movies');
    });
    it('checking create booking success', () => {
        expect(EMovieActionTypes.SET_CAST_AND_CREW).toBe('[ Movie ] Set Credits');
    });
    it('checking create booking failure', () => {
        expect(EMovieActionTypes.SET_THEATERS).toBe('[ Theaters ] Set Theaters');
    });
});


